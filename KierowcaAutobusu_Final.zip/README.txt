AUTOBUS - PROTOTYP GODOT 4

Nowe funkcje:
- Pauza pod ESC; ESC wznawia rozgrywke.
- Swiat, ruch aut i zegar zatrzymuja sie podczas pauzy oraz wyboru ulepszenia.
- Efekty obrazu: delikatny bloom swiatel, winieta i wstrzas ekranu po kolizji.
- Powiekszona mapa z nowa dzielnica na wschodzie.
- Minimapka pokazuje autobus, przystanki i kolejny cel.
- System pieniedzy zastapiono czasem: przystanki dodaja sekundy, a czas widac w HUD.

Sterowanie: strzalki/WASD, ESC - pauza, 1/2/3 - wybor ulepszenia.
Wymaga Godot 4.2 lub nowszego.
