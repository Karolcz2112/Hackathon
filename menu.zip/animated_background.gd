extends Control

var phase := 0.0

func _process(delta: float) -> void:
	phase += delta * 0.18
	queue_redraw()

func _draw() -> void:
	var size := get_viewport_rect().size
	var c1 := Vector2(size.x * (0.18 + 0.05 * sin(phase)), size.y * (0.28 + 0.08 * cos(phase * 0.8)))
	var c2 := Vector2(size.x * (0.82 + 0.04 * cos(phase * 0.7)), size.y * (0.78 + 0.06 * sin(phase)))
	draw_circle(c1, 240.0, Color(0.25, 0.38, 0.9, 0.12))
	draw_circle(c2, 290.0, Color(0.05, 0.72, 0.68, 0.10))
	for i in range(36):
		var x := fposmod(float(i * 173) + phase * (13.0 + float(i % 5) * 3.0), size.x)
		var y := fposmod(float(i * 97) - phase * (8.0 + float(i % 7) * 2.0), size.y)
		draw_circle(Vector2(x, y), 1.3 if i % 3 else 2.0, Color(0.75, 0.85, 1.0, 0.22))
