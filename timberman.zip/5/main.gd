extends Node2D
## RADIOSTACJA GLIWICE - drwal w stylu Timbermana. Cała grafika i dźwięk generowane kodem.
## Sterowanie: lewa/prawa połowa ekranu, strzałki, A/D, spacja (zmiana strony).
 
const W := 480.0
const H := 800.0
const CX := 240.0
const SEG_H := 96.0
const NUM_SEGS := 11
const PLAYER_Y := 660.0          # środek segmentu 0 (na wysokości gracza)
const GY := 708.0                # poziom ziemi
const TW_TOP := 46.0             # szerokość wieży u góry ekranu
const TW_BOT := 76.0             # szerokość wieży przy ziemi
const ARM_LEN := 150.0
const PLAYER_DX := 78.0
const CHOP_DUR := 0.2
const TOWER_M := 111             # tyle metrów ma prawdziwa Radiostacja
const SAVE_PATH := "user://rekord.cfg"
 
enum State { WAIT, PLAY, DEAD, CLEAR, SHOP }

const MODES: Array[Dictionary] = [
	{"id": "radio", "name": "Radiostacja", "detail": "111 m • wieża z modrzewia", "target": 111, "color": Color("#ffd84d")},
	{"id": "townhall", "name": "Ratusz", "detail": "45 m • papierowa makieta", "target": 45, "color": Color("#72d6a0")},
	{"id": "campus", "name": "Politechnika", "detail": "70 m • kartonowy kampus", "target": 70, "color": Color("#73b7ff")},
	{"id": "endless", "name": "Bez końca", "detail": "bez limitu • pobij rekord", "target": 0, "color": Color("#ff9b77")},
]
const CHARACTERS: Array[Dictionary] = [
	{"id": "drwal", "name": "Drwal z Piasta", "cost": 0, "shirt": Color("#c0392b"), "hat": Color("#1d4ed8"), "detail": "Flanelowa koszula, klubowa czapka i niezawodna siekiera.", "perk": "Bez dodatkowych zasad — klasyczny Timber."},
	{"id": "radiowiec", "name": "Radiowiec", "cost": 8, "shirt": Color("#416b58"), "hat": Color("#d99b35"), "detail": "Zielona kurtka, słuchawki i mikrofon z odzysku.", "perk": "Nadajnik: energia spada o 20% wolniej."},
	{"id": "inzynier", "name": "Inżynierka", "cost": 18, "shirt": Color("#397ca5"), "hat": Color("#f2c230"), "detail": "Kask, gogle i projekt makiety zawsze pod ręką.", "perk": "Skaner: szansa na pieroga rośnie z 14% do 24%."},
	{"id": "botanik", "name": "Botanik", "cost": 30, "shirt": Color("#4f8b47"), "hat": Color("#d7b66d"), "detail": "Szeroki słomkowy kapelusz i liść z Palmiarni.", "perk": "Ziołowy napar: pieróg odnawia 40% energii."},
	{"id": "kibic", "name": "Kibic Piasta", "cost": 42, "shirt": Color("#1d4ed8"), "hat": Color("#f7f7f2"), "detail": "Niebiesko-czerwony szalik powiewa za nim na wietrze.", "perk": "Doping: każde cięcie dodaje 2,5% energii."},
	{"id": "kucharz", "name": "Mistrz Pierogów", "cost": 60, "shirt": Color("#f2eee2"), "hat": Color("#fffaf0"), "detail": "Kucharz w czapce, który zawsze ma miejsce na dokładkę.", "perk": "Dokładka: każdy zebrany pieróg daje 2 sztuki."},
	{"id": "astronom", "name": "Astronom z Trynku", "cost": 76, "shirt": Color("#35375f"), "hat": Color("#c5b8ff"), "detail": "Granatowy płaszcz, gwiezdny kaptur i luneta.", "perk": "Gwiezdna tarcza raz na rundę ratuje przed anteną."},
	{"id": "fotograf", "name": "Fotograf Starówki", "cost": 94, "shirt": Color("#a54e35"), "hat": Color("#26272a"), "detail": "Skórzana torba i aparat gotowy na kadr.", "perk": "Pamiątki: za każde 10 m dostajesz 1 pieroga."},
	{"id": "motorniczy", "name": "Motorniczy", "cost": 112, "shirt": Color("#d5a91d"), "hat": Color("#23477a"), "detail": "Kurtka w barwach tramwaju, kasownik i konduktorska czapka.", "perk": "Jazda próbna: zaczyna rundę z +25% energii."},
]
const GLIWICE_FACTS: Array[String] = [
	"Radiostacja ma 111 m i jest zbudowana z modrzewia.",
	"Politechnika Śląska powstała w Gliwicach w 1945 roku.",
	"Przez Gliwice przepływa rzeka Kłodnica.",
	"Ratusz gliwicki stoi na Rynku.",
	"Piast Gliwice założono w 1945 roku.",
]
 
const DISTRICTS := ["Zatorze", "Wójtowa Wieś", "Szobiszowice", "Sośnica", "Trynek", "Łabędy", "Bojków", "Ostropa", "Śródmieście", "Czechowice", "Żerniki", "Brzezinka"]
 
# --- stan gry
var segs: Array[int] = []        # 0 = pusto, 1 = antena z lewej, 2 = antena z prawej
var seg_ids: Array[int] = []
var bonus: Array[int] = []       # 0 = brak, 1 = pieróg z lewej, 2 = pieróg z prawej
var next_id: int = 0
var state: State = State.WAIT
var side: int = 0
var score: int = 0
var best: int = 0
var pierogi: int = 0
var best_by_mode: Dictionary = {}
var owned_characters: Array[String] = ["drwal"]
var character_index: int = 0
var equipped_character_id: String = "drwal"
var shield_used: bool = false
var next_photo_reward: int = 10
var combo_streak: int = 0
var current_mode_id: String = "radio"
var round_number: int = 0
var fact_index: int = 0
var clear_time: float = 0.0
var energy: float = 1.0
var scroll: float = 0.0
var px_vis: float = CX - PLAYER_DX
var dead_time: float = 0.0
var death_dir: float = 1.0
var death_power: float = 1.0
var death_msg: String = ""
var new_record: bool = false
var reached_top: bool = false
var shake: float = 0.0
var t: float = 0.0
var cur_off: Vector2 = Vector2.ZERO
 
# --- animacje
var chopping: bool = false
var chop_time: float = 0.0
var axe_a: float = -0.7
var tower_jit: float = 0.0
var climb_vis: float = 0.0
var phase_vis: float = 0.0
var night_amt: float = 0.0
var sky_top: Color = Color("#3d8fd6")
var sky_bot: Color = Color("#bfe9ff")
var banner_t: float = 0.0
var banner_top: String = ""
var banner_main: String = ""
var tram_x: float = -200.0
var tram_dir: float = 1.0
var tram_wait: float = 3.0
 
var stars: PackedVector2Array = PackedVector2Array()
var cl_x: PackedFloat32Array = PackedFloat32Array()
var cl_y: PackedFloat32Array = PackedFloat32Array()
var cl_s: PackedFloat32Array = PackedFloat32Array()
var cl_v: PackedFloat32Array = PackedFloat32Array()
var flying: Array[Dictionary] = []
var chips: Array[Dictionary] = []
var popups: Array[Dictionary] = []
var sfx: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
 
var pal_top: Array[Color] = [Color("#3d8fd6"), Color("#2b2a6e"), Color("#050a1f"), Color("#2e3f86")]
var pal_bot: Array[Color] = [Color("#bfe9ff"), Color("#ff9b57"), Color("#17285a"), Color("#f4a98f")]
var pal_night: Array[float] = [0.0, 0.3, 1.0, 0.35]
 
 
func _ready() -> void:
	rng.randomize()
	RenderingServer.set_default_clear_color(Color("#0b1530"))
	for i in range(50):
		stars.append(Vector2(rng.randf_range(0.0, W), rng.randf_range(0.0, 500.0)))
	for i in range(6):
		cl_x.append(rng.randf_range(0.0, W))
		cl_y.append(rng.randf_range(0.0, 560.0))
		cl_s.append(rng.randf_range(0.8, 1.6))
		cl_v.append(rng.randf_range(6.0, 18.0))
	setup_audio()
	load_progress()
	reset_game()
 
 
# ---------------------------------------------------------------- logika
 
func tw(y: float) -> float:
	return lerpf(TW_TOP, TW_BOT, clampf(y / GY, 0.0, 1.0))
 
 
func rand_seg() -> int:
	var p: float = minf(0.45 + float(score) * 0.004, 0.65)
	if rng.randf() > p:
		return 0
	return 1 if rng.randf() < 0.5 else 2


func bonus_chance() -> float:
	return 0.24 if equipped_character_id == "inzynier" else 0.14


func energy_cap() -> float:
	return 1.25 if equipped_character_id == "motorniczy" else 1.0


func add_seg(empty: bool) -> void:
	var kind: int = 0 if empty else rand_seg()
	segs.append(kind)
	seg_ids.append(next_id)
	next_id += 1
	var b: int = 0
	if kind == 0 and not empty and rng.randf() < bonus_chance():
		b = 1 + (rng.randi() % 2)
	bonus.append(b)
 
 
func reset_game() -> void:
	segs.clear()
	seg_ids.clear()
	bonus.clear()
	flying.clear()
	chips.clear()
	popups.clear()
	next_id = 0
	for i in range(NUM_SEGS):
		add_seg(i < 3)
	state = State.WAIT
	score = 0
	energy = energy_cap()
	shield_used = false
	next_photo_reward = 10
	combo_streak = 0
	scroll = 0.0
	side = 0
	px_vis = CX - PLAYER_DX
	dead_time = 0.0
	shake = 0.0
	new_record = false
	reached_top = false
	chopping = false
	axe_a = -0.7
	climb_vis = 0.0
	phase_vis = 0.0
	banner_t = 0.0
	clear_time = 0.0
 
 
func tap(s: int) -> void:
	if state == State.DEAD:
		if dead_time > 0.5:
			reset_game()
		return
	if state == State.CLEAR:
		if clear_time > 0.5:
			reset_game()
		return
	if state == State.WAIT:
		start_round()
		return
	side = s
	var prev: int = score
 
	# ścięty segment odlatuje na drugą stronę
	spawn_flying(PLAYER_Y + scroll)
	segs.remove_at(0)
	seg_ids.remove_at(0)
	bonus.remove_at(0)
	add_seg(false)
	scroll = maxf(scroll - SEG_H, -SEG_H * 2.0)
 
	chopping = true
	chop_time = 0.0
	tower_jit = 1.0
	spawn_chips(7)
	play_sfx("chop")
 
	if segs[0] == side + 1:
		if equipped_character_id == "astronom" and not shield_used:
			shield_used = true
			segs[0] = 0
			energy = minf(energy_cap(), energy + 0.15)
			spawn_popup("TARCZA! ANTENA ODBITA", Vector2(CX, PLAYER_Y - 90.0), Color("#c5b8ff"))
			play_sfx("bonus")
		else:
			die(pick_msg(true), 1.0)
			return

	combo_streak += 1
	if combo_streak % 10 == 0:
		pierogi += 1
		save_progress()
		spawn_popup("SERIA %d! +1 PIEROŻEK" % combo_streak, Vector2(CX, PLAYER_Y - 118.0), Color("#ffd84d"))
		confetti()
		play_sfx("bonus")

	score += 1
	energy = minf(energy_cap(), energy + 0.06)
	if bonus[0] == side + 1:
		bonus[0] = 0
		score += 2
		var pierogi_reward: int = 2 if equipped_character_id == "kucharz" else 1
		pierogi += pierogi_reward
		save_progress()
		var energy_reward: float = 0.4 if equipped_character_id == "botanik" else 0.22
		energy = minf(energy_cap(), energy + energy_reward)
		spawn_popup("+%d PIEROGI" % pierogi_reward, Vector2(px_vis, PLAYER_Y - 90.0), Color("#ffd84d"))
		play_sfx("bonus")

	if equipped_character_id == "kibic":
		energy = minf(energy_cap(), energy + 0.025)
	elif equipped_character_id == "motorniczy":
		energy = minf(energy_cap(), energy + 0.01)

	if equipped_character_id == "fotograf" and score >= next_photo_reward:
		pierogi += 1
		next_photo_reward += 10
		save_progress()
		spawn_popup("PAMIĄTKA: +1 PIEROŻEK", Vector2(CX, PLAYER_Y - 118.0), Color("#ffd84d"))

	var target: int = int(selected_mode().get("target", 0))
	if target > 0 and prev < target and score >= target:
		reached_top = true
		state = State.CLEAR
		clear_time = 0.0
		show_banner("MAKIETA GOTOWA!", str(selected_mode()["name"]))
		confetti()
		play_sfx("mile")
		update_best()
		return
	elif current_mode_id == "radio" and prev < TOWER_M and score >= TOWER_M:
		reached_top = true
		show_banner("111 m!", "Tyle co Radiostacja!")
		confetti()
		play_sfx("mile")
	else:
		var m_new: int = floori(float(score) / 20.0)
		var m_old: int = floori(float(prev) / 20.0)
		if m_new > m_old:
			var dname: String = DISTRICTS[(m_new - 1) % DISTRICTS.size()]
			show_banner("Witamy w dzielnicy", dname)
			play_sfx("mile")
 
 
func pick_msg(hit: bool) -> String:
	var hits: Array[String] = ["Zderzenie z anteną!", "Antena Cię dopadła!", "Zakłócenia w eterze!"]
	var offs: Array[String] = ["Padł prąd w Radiostacji!", "Zabrakło zasilania!"]
	if hit:
		return hits[rng.randi() % hits.size()]
	return offs[rng.randi() % offs.size()]
 
 
func die(msg: String, power: float = 1.0) -> void:
	state = State.DEAD
	death_msg = msg
	death_power = power if power > 0.0 else 1.0
	death_dir = 1.0 if side == 1 else -1.0
	dead_time = 0.0
	shake = 0.4
	update_best()
	play_sfx("die")


func selected_mode() -> Dictionary:
	for mode in MODES:
		if str(mode["id"]) == current_mode_id:
			return mode
	return MODES[0]


func selected_character() -> Dictionary:
	return CHARACTERS[character_index]


func equipped_character() -> Dictionary:
	for character in CHARACTERS:
		if str(character["id"]) == equipped_character_id:
			return character
	return CHARACTERS[0]


func update_best() -> void:
	if score > best:
		best = score
		new_record = true
		best_by_mode[current_mode_id] = best
		save_progress()


func start_round() -> void:
	round_number += 1
	fact_index = (round_number - 1) % GLIWICE_FACTS.size()
	reset_game()
	state = State.PLAY
	show_banner("CIEKAWOSTKA • RUNDA %d" % round_number, GLIWICE_FACTS[fact_index])


func change_character(step: int) -> void:
	character_index = posmod(character_index + step, CHARACTERS.size())
	queue_redraw()


func choose_mode(mode_id: String) -> void:
	current_mode_id = mode_id
	best = int(best_by_mode.get(current_mode_id, 0))


func select_or_buy_character() -> void:
	var character: Dictionary = selected_character()
	var character_id: String = str(character["id"])
	if owned_characters.has(character_id):
		equipped_character_id = character_id
		save_progress()
	elif pierogi >= int(character["cost"]):
		pierogi -= int(character["cost"])
		owned_characters.append(character_id)
		equipped_character_id = character_id
		save_progress()
	queue_redraw()


func open_shop() -> void:
	for i in range(CHARACTERS.size()):
		if str(CHARACTERS[i]["id"]) == equipped_character_id:
			character_index = i
			break
	state = State.SHOP
	queue_redraw()


func close_shop() -> void:
	state = State.WAIT
	queue_redraw()
 
 
func show_banner(top: String, main_text: String) -> void:
	banner_top = top
	banner_main = main_text
	banner_t = 2.4
 
 
func spawn_flying(cy: float) -> void:
	var away: float = 1.0 if side == 0 else -1.0
	flying.append({
		"pos": Vector2(CX, cy),
		"vel": Vector2(away * rng.randf_range(520.0, 760.0), rng.randf_range(-520.0, -300.0)),
		"rot": 0.0,
		"rv": away * rng.randf_range(5.0, 11.0),
		"kind": segs[0],
		"sid": seg_ids[0],
		"wt": tw(cy - SEG_H * 0.5),
		"wb": tw(cy + SEG_H * 0.5),
	})
 
 
func spawn_chips(n: int) -> void:
	var toward: float = -1.0 if side == 0 else 1.0
	var bx: float = CX + toward * tw(PLAYER_Y) * 0.5
	var cols: Array[Color] = [Color("#c18a4b"), Color("#8a5a2b"), Color("#e0b070"), Color("#ffd84d")]
	for i in range(n):
		chips.append({
			"pos": Vector2(bx, PLAYER_Y - 10.0 + rng.randf_range(-14.0, 14.0)),
			"vel": Vector2(toward * rng.randf_range(60.0, 280.0), rng.randf_range(-440.0, -120.0)),
			"life": rng.randf_range(0.35, 0.7),
			"size": rng.randf_range(3.0, 6.0),
			"col": cols[rng.randi() % cols.size()],
		})
 
 
func confetti() -> void:
	var cols: Array[Color] = [Color("#d62828"), Color("#1d4ed8"), Color("#ffffff"), Color("#ffd84d")]
	for i in range(60):
		chips.append({
			"pos": Vector2(CX + rng.randf_range(-40.0, 40.0), 330.0),
			"vel": Vector2(rng.randf_range(-320.0, 320.0), rng.randf_range(-620.0, -150.0)),
			"life": rng.randf_range(1.0, 1.8),
			"size": rng.randf_range(4.0, 8.0),
			"col": cols[rng.randi() % cols.size()],
		})
 
 
func spawn_popup(s: String, pos: Vector2, col: Color) -> void:
	popups.append({"text": s, "pos": pos, "life": 0.9, "col": col})
 
 
func _process(delta: float) -> void:
	t += delta
	scroll = lerpf(scroll, 0.0, 1.0 - exp(-delta * 22.0))
	var target_x: float = CX + (PLAYER_DX if side == 1 else -PLAYER_DX)
	px_vis = lerpf(px_vis, target_x, 1.0 - exp(-delta * 30.0))
	climb_vis = lerpf(climb_vis, float(score) * 7.0, 1.0 - exp(-delta * 4.0))
	tower_jit = maxf(0.0, tower_jit - delta * 6.0)
	banner_t = maxf(0.0, banner_t - delta)
	shake = maxf(0.0, shake - delta)
 
	if state == State.PLAY:
		var drain_rate: float = minf(0.18 + float(score) * 0.002, 0.45)
		if equipped_character_id == "radiowiec":
			drain_rate *= 0.8
		energy -= drain_rate * delta
		if energy <= 0.0:
			energy = 0.0
			die(pick_msg(false), 0.35)
	elif state == State.DEAD:
		dead_time += delta
	elif state == State.CLEAR:
		clear_time += delta
 
	# niebo: dzień -> zachód -> noc -> świt
	phase_vis = lerpf(phase_vis, float(score) / 15.0, 1.0 - exp(-delta * 1.5))
	var pos: float = fposmod(phase_vis, 4.0)
	var ia: int = int(pos)
	var ib: int = (ia + 1) % 4
	var f: float = smoothstep(0.0, 1.0, pos - float(ia))
	sky_top = pal_top[ia].lerp(pal_top[ib], f)
	sky_bot = pal_bot[ia].lerp(pal_bot[ib], f)
	night_amt = lerpf(pal_night[ia], pal_night[ib], f)
 
	# chmury
	for i in range(cl_x.size()):
		cl_x[i] += cl_v[i] * delta
		if cl_x[i] > W + 120.0:
			cl_x[i] = -140.0
 
	# tramwaj
	if tram_wait > 0.0:
		tram_wait -= delta
	else:
		tram_x += tram_dir * 110.0 * delta
		if (tram_dir > 0.0 and tram_x > W + 160.0) or (tram_dir < 0.0 and tram_x < -160.0):
			tram_wait = rng.randf_range(6.0, 14.0)
			tram_dir = 1.0 if rng.randf() < 0.5 else -1.0
			tram_x = -160.0 if tram_dir > 0.0 else W + 160.0
 
	# siekiera
	var target_a: float = -0.7
	if chopping:
		chop_time += delta
		var p: float = clampf(chop_time / CHOP_DUR, 0.0, 1.0)
		if p < 0.3:
			target_a = lerpf(-0.7, -1.9, p / 0.3)
		else:
			var q: float = (p - 0.3) / 0.7
			target_a = lerpf(-1.9, 0.55, 1.0 - (1.0 - q) * (1.0 - q))
		if chop_time >= CHOP_DUR:
			chopping = false
	axe_a = lerpf(axe_a, target_a, 1.0 - exp(-delta * 45.0))
 
	# latające segmenty
	for i in range(flying.size() - 1, -1, -1):
		var v: Vector2 = flying[i]["vel"]
		v.y += 2200.0 * delta
		flying[i]["vel"] = v
		var fp: Vector2 = flying[i]["pos"]
		fp += v * delta
		flying[i]["pos"] = fp
		flying[i]["rot"] = float(flying[i]["rot"]) + float(flying[i]["rv"]) * delta
		if fp.y > H + 250.0:
			flying.remove_at(i)
 
	# drzazgi i konfetti
	for i in range(chips.size() - 1, -1, -1):
		var cv: Vector2 = chips[i]["vel"]
		cv.y += 1500.0 * delta
		chips[i]["vel"] = cv
		var cp: Vector2 = chips[i]["pos"]
		chips[i]["pos"] = cp + cv * delta
		chips[i]["life"] = float(chips[i]["life"]) - delta
		if float(chips[i]["life"]) <= 0.0:
			chips.remove_at(i)
 
	# napisy unoszące się w górę
	for i in range(popups.size() - 1, -1, -1):
		var pp: Vector2 = popups[i]["pos"]
		pp.y -= 60.0 * delta
		popups[i]["pos"] = pp
		popups[i]["life"] = float(popups[i]["life"]) - delta
		if float(popups[i]["life"]) <= 0.0:
			popups.remove_at(i)
 
	queue_redraw()
 
 
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo:
			if state == State.SHOP:
				if k.keycode == KEY_ESCAPE:
					close_shop()
				elif k.keycode == KEY_LEFT or k.keycode == KEY_A:
					change_character(-1)
				elif k.keycode == KEY_RIGHT or k.keycode == KEY_D:
					change_character(1)
				elif k.keycode == KEY_ENTER or k.keycode == KEY_SPACE or k.keycode == KEY_B:
					select_or_buy_character()
				return
			if state == State.WAIT:
				if k.keycode == KEY_LEFT or k.keycode == KEY_A:
					choose_mode(str(MODES[maxi(0, _mode_index() - 1)]["id"]))
				elif k.keycode == KEY_RIGHT or k.keycode == KEY_D:
					choose_mode(str(MODES[mini(MODES.size() - 1, _mode_index() + 1)]["id"]))
				elif k.keycode == KEY_ENTER or k.keycode == KEY_SPACE:
					start_round()
				elif k.keycode == KEY_B or k.keycode == KEY_C:
					open_shop()
				queue_redraw()
				return
			if state == State.DEAD or state == State.CLEAR:
				if k.keycode == KEY_ENTER or k.keycode == KEY_SPACE:
					reset_game()
				return
			if k.keycode == KEY_LEFT or k.keycode == KEY_A:
				tap(0)
			elif k.keycode == KEY_RIGHT or k.keycode == KEY_D:
				tap(1)
			elif k.keycode == KEY_SPACE or k.keycode == KEY_ENTER:
				tap(1 - side)
	elif event is InputEventMouseButton:
		var m := event as InputEventMouseButton
		if m.pressed and m.button_index == MOUSE_BUTTON_LEFT:
			if state == State.WAIT:
				var p: Vector2 = m.position
				if p.y >= 185.0 and p.y < 320.0:
					var col: int = 0 if p.x < CX else 1
					var row: int = 0 if p.y < 252.0 else 1
					choose_mode(str(MODES[row * 2 + col]["id"]))
				elif p.y >= 330.0 and p.y < 425.0:
					open_shop()
				elif p.y >= 460.0 and p.y < 545.0:
					start_round()
				queue_redraw()
				return
			if state == State.SHOP:
				var shop_point: Vector2 = m.position
				if shop_point.y >= 270.0 and shop_point.y < 465.0:
					if shop_point.x < 112.0:
						change_character(-1)
					elif shop_point.x > 368.0:
						change_character(1)
				elif shop_point.y >= 600.0 and shop_point.y < 685.0:
					select_or_buy_character()
				elif shop_point.y >= 700.0:
					close_shop()
				queue_redraw()
				return
			tap(0 if m.position.x < CX else 1)
 
 
# ---------------------------------------------------------------- zapis
 
func _mode_index() -> int:
	for i in range(MODES.size()):
		if str(MODES[i]["id"]) == current_mode_id:
			return i
	return 0


func load_progress() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	var load_error: Error = cfg.load(SAVE_PATH)
	if load_error == OK:
		pierogi = maxi(0, int(cfg.get_value("profile", "pierogi", 0)))
		var saved_owned: Variant = cfg.get_value("profile", "owned_characters", ["drwal"])
		if saved_owned is Array:
			for character_id in saved_owned:
				if character_id is String and not owned_characters.has(character_id):
					owned_characters.append(character_id)
		var saved_character: String = str(cfg.get_value("profile", "equipped_character", "drwal"))
		for i in range(CHARACTERS.size()):
			if str(CHARACTERS[i]["id"]) == saved_character and owned_characters.has(saved_character):
				equipped_character_id = saved_character
		for mode in MODES:
			best_by_mode[str(mode["id"])] = int(cfg.get_value("records", str(mode["id"]), 0))
		if int(best_by_mode.get(current_mode_id, 0)) == 0:
			best_by_mode[current_mode_id] = int(cfg.get_value("game", "best", 0))
		best = int(best_by_mode.get(current_mode_id, 0))
	elif load_error != ERR_FILE_NOT_FOUND:
		push_error("Nie udało się wczytać postępów: %s" % error_string(load_error))


func save_progress() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.set_value("profile", "pierogi", pierogi)
	cfg.set_value("profile", "owned_characters", owned_characters)
	cfg.set_value("profile", "equipped_character", equipped_character_id)
	for mode_id in best_by_mode:
		cfg.set_value("records", str(mode_id), int(best_by_mode[mode_id]))
	cfg.set_value("game", "best", best)
	var save_error: Error = cfg.save(SAVE_PATH)
	if save_error != OK:
		push_error("Nie udało się zapisać postępów: %s" % error_string(save_error))
 
 
# ---------------------------------------------------------------- dźwięk (8-bit)
 
func setup_audio() -> void:
	var defs: Dictionary = {
		"chop": [[260.0, 90.0, 0.10, 0.55]],
		"bonus": [[660.0, 660.0, 0.06, 0.0], [880.0, 880.0, 0.06, 0.0], [1320.0, 1320.0, 0.10, 0.0]],
		"die": [[330.0, 70.0, 0.45, 0.25]],
		"mile": [[520.0, 520.0, 0.08, 0.0], [660.0, 660.0, 0.08, 0.0], [780.0, 780.0, 0.08, 0.0], [1040.0, 1040.0, 0.18, 0.0]],
	}
	for key in defs.keys():
		var pl := AudioStreamPlayer.new()
		pl.stream = build_wav(defs[key], 0.45)
		pl.volume_db = -8.0
		add_child(pl)
		sfx[key] = pl
 
 
func build_wav(notes: Array, vol: float) -> AudioStreamWAV:
	var rate: int = 22050
	var samples: PackedFloat32Array = PackedFloat32Array()
	var phase: float = 0.0
	for nt_v in notes:
		var nt: Array = nt_v
		var f0: float = nt[0]
		var f1: float = nt[1]
		var dur: float = nt[2]
		var noise: float = nt[3]
		var n: int = int(float(rate) * dur)
		for i in range(n):
			var u: float = float(i) / float(n)
			var fr: float = lerpf(f0, f1, u)
			phase += TAU * fr / float(rate)
			var sq: float = signf(sin(phase))
			var nz: float = rng.randf_range(-1.0, 1.0)
			samples.append((sq * (1.0 - noise) + nz * noise) * (1.0 - u) * vol)
	var data: PackedByteArray = PackedByteArray()
	data.resize(samples.size() * 2)
	for i in range(samples.size()):
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	var w: AudioStreamWAV = AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	return w
 
 
func play_sfx(key: String) -> void:
	if sfx.has(key):
		var pl: AudioStreamPlayer = sfx[key]
		pl.play()
 
 
# ---------------------------------------------------------------- rysowanie
 
func _draw() -> void:
	cur_off = Vector2.ZERO
	if shake > 0.0:
		cur_off = Vector2(rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0)) * shake * 25.0
	draw_set_transform(cur_off, 0.0, Vector2.ONE)
 
	draw_sky()
	draw_celestial()
	draw_clouds()
	draw_skyline(climb_vis * 0.35)
	if tram_wait <= 0.0:
		draw_tram(tram_x, GY - 3.0, tram_dir)
	draw_sign()
	draw_flag()
 
	# fale radiowe
	for k in range(3):
		var rad: float = fmod(t * 50.0 + float(k) * 60.0, 180.0)
		draw_arc(Vector2(CX, 90.0), rad, 0.0, TAU, 48, Color(1, 1, 1, (1.0 - rad / 180.0) * 0.22), 2.0)
 
	# wieża
	var jx: float = sin(t * 90.0) * tower_jit * 3.0
	for i in range(NUM_SEGS - 1, -3, -1):
		var cy: float = PLAYER_Y - float(i) * SEG_H + scroll
		if cy < -SEG_H or cy - SEG_H * 0.5 >= GY:
			continue
		var sid: int = 0
		var kind: int = 0
		var bn: int = 0
		if i >= 0:
			sid = seg_ids[i]
			kind = segs[i]
			bn = bonus[i]
		else:
			sid = seg_ids[0] + i
		draw_seg_body(Vector2(CX + jx, cy), tw(cy - SEG_H * 0.5), tw(cy + SEG_H * 0.5), kind, sid, bn, i >= 1)
 
	draw_ground()
	draw_rect(Rect2(CX - 52.0, GY - 6.0, 104.0, 12.0), Color("#6f7b82"))
	draw_rect(Rect2(CX - 52.0, GY - 6.0, 104.0, 3.0), Color("#a9b4ba"))
 
	# odlatujące belki
	for fl in flying:
		var fpos: Vector2 = fl["pos"]
		draw_set_transform(cur_off + fpos, float(fl["rot"]), Vector2.ONE)
		draw_seg_body(Vector2.ZERO, float(fl["wt"]), float(fl["wb"]), int(fl["kind"]), int(fl["sid"]), 0, false)
	draw_set_transform(cur_off, 0.0, Vector2.ONE)
 
	draw_player(px_vis, GY - 2.0)
 
	for c in chips:
		var cpos: Vector2 = c["pos"]
		var ca: float = clampf(float(c["life"]) * 3.0, 0.0, 1.0)
		var csz: float = float(c["size"])
		var cc: Color = c["col"]
		cc.a = ca
		draw_rect(Rect2(cpos.x - csz * 0.5, cpos.y - csz * 0.5, csz, csz), cc)
 
	for pu in popups:
		var ppos: Vector2 = pu["pos"]
		var pcol: Color = pu["col"]
		pcol.a = clampf(float(pu["life"]) * 2.5, 0.0, 1.0)
		var font: Font = ThemeDB.fallback_font
		draw_string(font, ppos + Vector2(-60.0 + 2.0, 2.0), str(pu["text"]), HORIZONTAL_ALIGNMENT_CENTER, 120.0, 20, Color(0, 0, 0, pcol.a * 0.6))
		draw_string(font, ppos + Vector2(-60.0, 0.0), str(pu["text"]), HORIZONTAL_ALIGNMENT_CENTER, 120.0, 20, pcol)
 
	# noc przyciemnia cały świat
	if night_amt > 0.01:
		draw_rect(Rect2(-20.0, -20.0, W + 40.0, H + 40.0), Color(0.02, 0.04, 0.16, night_amt * 0.28))
 
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_hud()
 
 
# ---- niebo, chmury, miasto
 
func draw_sky() -> void:
	for i in range(20):
		var c: Color = sky_top.lerp(sky_bot, float(i) / 19.0)
		draw_rect(Rect2(-20.0, float(i) * 40.0, W + 40.0, 41.0), c)
 
 
func draw_celestial() -> void:
	if night_amt > 0.05:
		for i in range(stars.size()):
			var sy: float = fposmod(stars[i].y + climb_vis * 0.1, 500.0)
			var a: float = (0.5 + 0.5 * sin(t * 2.0 + float(i))) * night_amt
			draw_circle(Vector2(stars[i].x, sy), 1.5, Color(1, 1, 1, a * 0.9))
	var sun_a: float = 1.0 - night_amt
	if sun_a > 0.02:
		draw_circle(Vector2(375.0, 130.0), 50.0, Color(1.0, 0.9, 0.5, 0.18 * sun_a))
		draw_circle(Vector2(375.0, 130.0), 34.0, Color(1.0, 0.93, 0.45, sun_a))
	if night_amt > 0.15:
		var ma: float = clampf((night_amt - 0.15) * 1.5, 0.0, 1.0)
		draw_circle(Vector2(100.0, 120.0), 28.0, Color(0.96, 0.96, 0.85, ma))
		draw_circle(Vector2(92.0, 112.0), 6.0, Color(0.8, 0.8, 0.7, ma))
		draw_circle(Vector2(110.0, 128.0), 4.0, Color(0.8, 0.8, 0.7, ma))
		draw_circle(Vector2(104.0, 108.0), 3.0, Color(0.8, 0.8, 0.7, ma))
 
 
func draw_clouds() -> void:
	var col: Color = Color(1, 1, 1, 0.9).lerp(Color(0.35, 0.4, 0.6, 0.7), night_amt)
	for i in range(cl_x.size()):
		var s: float = cl_s[i]
		var x: float = cl_x[i]
		var y: float = fposmod(cl_y[i] + climb_vis * 0.5, 560.0) - 60.0
		draw_rect(Rect2(x, y, 64.0 * s, 14.0 * s), col)
		draw_rect(Rect2(x + 10.0 * s, y - 10.0 * s, 38.0 * s, 12.0 * s), col)
		draw_rect(Rect2(x + 26.0 * s, y - 18.0 * s, 20.0 * s, 10.0 * s), col)
 
 
func dome(cx: float, base_y: float, rx: float, ry: float, steps: int) -> PackedVector2Array:
	var pts: PackedVector2Array = PackedVector2Array()
	for k in range(steps + 1):
		var a: float = PI * float(k) / float(steps)
		pts.append(Vector2(cx - cos(a) * rx, base_y - sin(a) * ry))
	return pts
 
 
func draw_skyline(off: float) -> void:
	var gy: float = GY + off
	var far_col: Color = Color("#6d8fbd").lerp(Color("#101d42"), night_amt)
	var near_col: Color = Color("#42658f").lerp(Color("#0a1430"), night_amt)
	var win_a: float = clampf((night_amt - 0.3) * 1.4, 0.0, 0.9)
 
	# bloki (dalszy plan)
	var x: float = -10.0
	var i: int = 0
	while x < W + 10.0:
		var bw: float = 26.0 + float((i * 17) % 22)
		var bh: float = 50.0 + float((i * 53) % 70)
		draw_rect(Rect2(x, gy - bh, bw, bh + 60.0), far_col)
		if win_a > 0.0:
			for r in range(int(bh / 14.0)):
				for c in range(int(bw / 10.0)):
					if (i * 31 + r * 7 + c * 13) % 5 == 0:
						draw_rect(Rect2(x + 3.0 + float(c) * 10.0, gy - bh + 6.0 + float(r) * 14.0, 4.0, 6.0), Color(1.0, 0.85, 0.4, win_a))
		x += bw + 2.0
		i += 1
 
	# komin z dymem
	for k in range(5):
		draw_rect(Rect2(8.0, gy - 200.0 + float(k) * 40.0, 12.0, 40.0), near_col if k % 2 == 0 else near_col.lerp(Color("#c0392b"), 0.55))
	for k in range(3):
		var sm: float = fmod(t * 10.0 + float(k) * 26.0, 78.0)
		draw_circle(Vector2(16.0 + sm * 0.6 + sin(t + float(k)) * 4.0, gy - 205.0 - sm), 8.0 + sm * 0.12, Color(0.8, 0.8, 0.85, (1.0 - sm / 78.0) * 0.28))
 
	# katedra
	draw_rect(Rect2(34.0, gy - 48.0, 76.0, 48.0), near_col)
	draw_colored_polygon(PackedVector2Array([Vector2(30.0, gy - 48.0), Vector2(114.0, gy - 48.0), Vector2(72.0, gy - 78.0)]), near_col)
	draw_rect(Rect2(58.0, gy - 120.0, 24.0, 120.0), near_col)
	draw_colored_polygon(PackedVector2Array([Vector2(55.0, gy - 120.0), Vector2(85.0, gy - 120.0), Vector2(70.0, gy - 208.0)]), near_col)
	draw_line(Vector2(70.0, gy - 208.0), Vector2(70.0, gy - 222.0), near_col, 2.0)
	draw_line(Vector2(65.0, gy - 216.0), Vector2(75.0, gy - 216.0), near_col, 2.0)
 
	# ratusz
	draw_rect(Rect2(128.0, gy - 62.0, 66.0, 62.0), near_col)
	draw_colored_polygon(PackedVector2Array([Vector2(124.0, gy - 62.0), Vector2(198.0, gy - 62.0), Vector2(161.0, gy - 88.0)]), near_col)
	draw_rect(Rect2(151.0, gy - 126.0, 20.0, 66.0), near_col)
	draw_colored_polygon(PackedVector2Array([Vector2(148.0, gy - 126.0), Vector2(174.0, gy - 126.0), Vector2(161.0, gy - 162.0)]), near_col)
	draw_circle(Vector2(161.0, gy - 108.0), 6.0, Color(0.95, 0.95, 0.85, 0.5 + 0.3 * night_amt))
 
	# palmiarnia
	draw_rect(Rect2(290.0, gy - 30.0, 70.0, 30.0), near_col)
	var glass: Color = Color(0.55, 0.85, 0.8).lerp(Color(0.12, 0.25, 0.3), night_amt)
	draw_colored_polygon(dome(325.0, gy - 30.0, 32.0, 46.0, 14), glass)
	for k in range(-2, 3):
		draw_line(Vector2(325.0 + float(k) * 12.0, gy - 30.0), Vector2(325.0 + float(k) * 5.0, gy - 74.0), near_col, 2.0)
 
	# arena
	draw_colored_polygon(dome(425.0, gy, 58.0, 52.0, 18), near_col.lerp(Color("#7aa0c8"), 0.15 * (1.0 - night_amt)))
	draw_rect(Rect2(367.0, gy - 10.0, 116.0, 10.0), near_col)
	for k in range(5):
		draw_line(Vector2(380.0 + float(k) * 18.0, gy - 8.0), Vector2(388.0 + float(k) * 12.0, gy - 44.0), Color(1, 1, 1, 0.12), 2.0)
 
 
func draw_tram(x: float, yb: float, dir: float) -> void:
	draw_line(Vector2(-10.0, yb - 46.0), Vector2(W + 10.0, yb - 46.0), Color(0, 0, 0, 0.3), 1.0)
	draw_rect(Rect2(x - 52.0, yb - 28.0, 104.0, 24.0), Color("#f2c230"))
	draw_rect(Rect2(x - 52.0, yb - 12.0, 104.0, 8.0), Color("#2a5db0"))
	var wc: Color = Color(0.7, 0.88, 1.0).lerp(Color(1.0, 0.85, 0.4), night_amt)
	for k in range(6):
		draw_rect(Rect2(x - 46.0 + float(k) * 16.0, yb - 24.0, 11.0, 9.0), wc)
	draw_circle(Vector2(x - 36.0, yb - 3.0), 4.0, Color("#222222"))
	draw_circle(Vector2(x + 36.0, yb - 3.0), 4.0, Color("#222222"))
	draw_line(Vector2(x - 10.0 * dir, yb - 28.0), Vector2(x - 2.0 * dir, yb - 46.0), Color("#222222"), 2.0)
	draw_rect(Rect2(x + dir * 52.0 - 2.0, yb - 22.0, 4.0, 6.0), Color(1, 1, 0.7, 0.9))
 
 
func draw_sign() -> void:
	draw_rect(Rect2(20.0, GY - 42.0, 4.0, 42.0), Color("#555b61"))
	draw_rect(Rect2(72.0, GY - 42.0, 4.0, 42.0), Color("#555b61"))
	draw_rect(Rect2(8.0, GY - 70.0, 84.0, 30.0), Color("#222222"))
	draw_rect(Rect2(10.0, GY - 68.0, 80.0, 26.0), Color("#f5f5f0"))
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(10.0, GY - 49.0), "GLIWICE", HORIZONTAL_ALIGNMENT_CENTER, 80.0, 16, Color("#111111"))
 
 
func draw_flag() -> void:
	var px: float = 452.0
	draw_rect(Rect2(px - 2.0, GY - 130.0, 4.0, 130.0), Color("#c9d1d6"))
	draw_circle(Vector2(px, GY - 132.0), 4.0, Color("#ffd84d"))
	for k in range(9):
		var wy: float = sin(t * 5.0 + float(k) * 0.7) * 3.0
		draw_rect(Rect2(px + 2.0 + float(k) * 4.0, GY - 126.0 + wy, 5.0, 12.0), Color("#d62828"))
		draw_rect(Rect2(px + 2.0 + float(k) * 4.0, GY - 114.0 + wy, 5.0, 12.0), Color("#1d4ed8"))
 
 
func draw_ground() -> void:
	draw_rect(Rect2(-20.0, GY, W + 40.0, H - GY + 20.0), Color("#2f6b43"))
	draw_rect(Rect2(-20.0, GY, W + 40.0, 10.0), Color("#5fb96f"))
	draw_rect(Rect2(-20.0, GY + 10.0, W + 40.0, 5.0), Color("#8e9aa3"))
	for k in range(25):
		var gx: float = float(k) * 20.0 + float((k * 7) % 9)
		draw_rect(Rect2(gx, GY - 4.0, 3.0, 6.0), Color("#5fb96f"))
		draw_rect(Rect2(gx + 5.0, GY - 2.0, 2.0, 4.0), Color("#4aa35c"))
	for k in range(9):
		var fx: float = 18.0 + float(k) * 54.0
		var fc: Color = Color("#ffd84d") if k % 2 == 0 else Color("#ff8fa3")
		draw_rect(Rect2(fx, GY + 30.0 + float((k * 5) % 14), 4.0, 4.0), fc)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(0.0, 784.0), "Radiostacja Gliwice • drewniana wieża • 1935 • 111 m", HORIZONTAL_ALIGNMENT_CENTER, W, 13, Color(1, 1, 1, 0.55))
 
 
# ---- wieża
 
func draw_seg_body(c: Vector2, wt: float, wb: float, kind: int, sid: int, bn: int, show_bonus: bool) -> void:
	var top: float = c.y - SEG_H * 0.5
	var bot: float = c.y + SEG_H * 0.5
	var tl: Vector2 = Vector2(c.x - wt * 0.5, top)
	var tr: Vector2 = Vector2(c.x + wt * 0.5, top)
	var bl: Vector2 = Vector2(c.x - wb * 0.5, bot)
	var br: Vector2 = Vector2(c.x + wb * 0.5, bot)
	var dark: Color = Color("#2a1a0e")
	var post: Color = Color("#c18a4b")
	var brace: Color = Color("#9a6a35")
 
	# wnętrze kratownicy (prześwituje niebo)
	draw_colored_polygon(PackedVector2Array([tl, tr, br, bl]), Color(0.1, 0.06, 0.03, 0.72))
	# przekątne
	draw_line(tl, br, dark, 7.0)
	draw_line(tr, bl, dark, 7.0)
	draw_line(tl, br, brace, 4.0)
	draw_line(tr, bl, brace, 4.0)
	# belka pozioma w środku
	var ml: Vector2 = Vector2(c.x - (wt + wb) * 0.25, c.y)
	var mr: Vector2 = Vector2(c.x + (wt + wb) * 0.25, c.y)
	draw_line(ml, mr, dark, 6.0)
	draw_line(ml, mr, brace, 3.0)
	# słupy
	draw_line(tl, bl, dark, 10.0)
	draw_line(tr, br, dark, 10.0)
	draw_line(tl, bl, post, 6.0)
	draw_line(tr, br, post, 6.0)
	draw_line(tl + Vector2(-1.5, 0.0), bl + Vector2(-1.5, 0.0), Color("#e0b070"), 2.0)
	draw_line(tr + Vector2(-1.5, 0.0), br + Vector2(-1.5, 0.0), Color("#e0b070"), 2.0)
	# belka górna
	draw_line(tl, tr, dark, 8.0)
	draw_line(tl, tr, post, 5.0)
 
	# platforma co 5 segmentów
	if posmod(sid, 5) == 0:
		var pw: float = wt + 32.0
		draw_rect(Rect2(c.x - pw * 0.5, top - 5.0, pw, 10.0), dark)
		draw_rect(Rect2(c.x - pw * 0.5 + 1.5, top - 3.5, pw - 3.0, 6.0), Color("#b07a3f"))
		var lx: float = c.x - pw * 0.5 + 3.0
		var rx: float = c.x + pw * 0.5 - 3.0
		draw_line(Vector2(lx, top - 5.0), Vector2(lx, top - 24.0), Color("#dfe6e9"), 3.0)
		draw_line(Vector2(rx, top - 5.0), Vector2(rx, top - 24.0), Color("#dfe6e9"), 3.0)
		draw_line(Vector2(lx, top - 24.0), Vector2(rx, top - 24.0), Color("#dfe6e9"), 2.0)
		var blink: float = 0.5 + 0.5 * sin(t * 4.0 + float(sid))
		draw_circle(Vector2(lx, top - 28.0), 7.0, Color(1, 0.1, 0.1, 0.25 * blink))
		draw_circle(Vector2(lx, top - 28.0), 3.5, Color(1, 0.2, 0.2, 0.4 + 0.6 * blink))
 
	if kind == 1:
		draw_antenna(Vector2((tl.x + bl.x) * 0.5, c.y), -1.0, sid)
	elif kind == 2:
		draw_antenna(Vector2((tr.x + br.x) * 0.5, c.y), 1.0, sid)
 
	if show_bonus and bn != 0:
		var dirb: float = -1.0 if bn == 1 else 1.0
		var bx: float = c.x + dirb * ((wt + wb) * 0.25 + 42.0)
		draw_pierogi(Vector2(bx, c.y + sin(t * 4.0 + float(sid)) * 4.0))
 
 
func draw_antenna(base: Vector2, dir: float, sid: int) -> void:
	var ang: float = sin(t * 2.0 + float(sid)) * 0.03
	var v: Vector2 = Vector2(dir, 0.0).rotated(ang * dir)
	var tip: Vector2 = base + v * ARM_LEN
	var dk: Color = Color("#20262b")
	draw_line(base, tip, dk, 10.0)
	draw_line(base, tip, Color("#aab4ba"), 6.0)
	for k in range(4):
		var bp: Vector2 = base + v * (ARM_LEN * (0.2 + 0.2 * float(k)))
		draw_rect(Rect2(bp.x - 2.0, bp.y - 5.0, 4.0, 10.0), Color("#7b8489"))
 
	var light_pos: Vector2 = tip
	if sid % 2 == 0:
		# antena kierunkowa (jagi)
		for k in range(5):
			var p: Vector2 = base + v * (ARM_LEN * (0.28 + 0.16 * float(k)))
			var h: float = 48.0 - float(k) * 7.0
			draw_line(p + Vector2(0.0, -h * 0.5), p + Vector2(0.0, h * 0.5), dk, 6.0)
			draw_line(p + Vector2(0.0, -h * 0.5), p + Vector2(0.0, h * 0.5), Color("#dfe6e9"), 3.0)
	else:
		# czasza satelitarna
		var pts: PackedVector2Array = PackedVector2Array()
		for k in range(13):
			var a: float = -PI * 0.5 + PI * float(k) / 12.0
			pts.append(tip + Vector2(-dir * cos(a) * 18.0, sin(a) * 36.0))
		draw_colored_polygon(pts, Color("#ecf0f1"))
		draw_polyline(pts, dk, 3.0)
		draw_line(pts[0], pts[12], dk, 3.0)
		draw_line(tip, tip + Vector2(dir * 24.0, 0.0), dk, 3.0)
		draw_circle(tip + Vector2(dir * 24.0, 0.0), 4.0, Color("#dfe6e9"))
		light_pos = tip + Vector2(0.0, -40.0)
 
	var blink: float = 0.55 + 0.45 * sin(t * 9.0 + float(sid))
	draw_circle(light_pos, 11.0, Color(1, 0.15, 0.15, 0.22 * blink))
	draw_circle(light_pos, 5.0, Color(1, 0.25, 0.25, blink))
 
 
func draw_pierogi(p: Vector2) -> void:
	draw_circle(p, 24.0, Color(1.0, 0.9, 0.4, 0.2))
	var pts: PackedVector2Array = PackedVector2Array()
	for k in range(13):
		var a: float = PI * float(k) / 12.0
		pts.append(p + Vector2(cos(a) * 17.0, 8.0 - sin(a) * 15.0))
	draw_colored_polygon(pts, Color("#f4e3b1"))
	draw_polyline(pts, Color("#c9a35a"), 2.0)
	draw_line(pts[0], pts[12], Color("#c9a35a"), 2.0)
	for k in range(1, 12, 2):
		draw_circle(pts[k], 1.6, Color("#c9a35a"))
	draw_circle(p + Vector2(-4.0, -2.0), 2.0, Color(1, 1, 1, 0.7))
 
 
# ---- gracz (drwal)
 
func draw_player(x: float, y: float, scale: float = 1.0, preview: bool = false) -> void:
	var f: float = 1.0 if side == 0 else -1.0
	var pos: Vector2 = Vector2(x, y)
	var rot: float = 0.0
	if state == State.DEAD:
		var tt: float = dead_time
		var hop: float = maxf(560.0 * tt - 1500.0 * tt * tt, 0.0) * death_power
		pos += Vector2(death_dir * minf(tt * 380.0, 170.0) * death_power, -hop)
		rot = death_dir * minf(tt * 9.0, PI * 0.5) * death_power
 
	draw_set_transform(cur_off + pos, rot, Vector2(f * scale, scale))
	var lean: float = clampf((axe_a + 1.9) / 2.4, 0.0, 1.0) * 5.0
	var sk: Color = Color("#f1c27d")
	var outfit: Dictionary = selected_character() if preview else equipped_character()
	var character_id: String = str(outfit["id"])
	var red: Color = outfit["shirt"]
	var red_d: Color = red.darkened(0.38)
	var hat_color: Color = outfit["hat"]
	var denim: Color = Color("#34495e")
	var boot: Color = Color("#3b2412")
 
	# nogi i buty
	draw_rect(Rect2(-10.0, -24.0, 9.0, 20.0), denim)
	draw_rect(Rect2(1.0, -24.0, 9.0, 20.0), denim)
	draw_rect(Rect2(-12.0, -6.0, 11.0, 6.0), boot)
	draw_rect(Rect2(1.0, -6.0, 13.0, 6.0), boot)
	# tylna ręka
	draw_rect(Rect2(-17.0 + lean, -46.0, 7.0, 20.0), red_d)
	# tułów w kratę
	var tx: float = -14.0 + lean * 0.5
	draw_rect(Rect2(tx, -52.0, 28.0, 30.0), red)
	if character_id == "drwal":
		for k in range(3):
			draw_rect(Rect2(tx + 4.0 + float(k) * 9.0, -52.0, 3.0, 30.0), Color(0.3, 0.05, 0.05, 0.5))
			draw_rect(Rect2(tx, -46.0 + float(k) * 9.0, 28.0, 3.0), Color(0.3, 0.05, 0.05, 0.5))
	elif character_id == "kibic":
		draw_rect(Rect2(tx + 5.0, -52.0, 5.0, 30.0), Color("#f7f7f2"))
		draw_rect(Rect2(tx + 19.0, -52.0, 5.0, 30.0), Color("#f7f7f2"))
	draw_rect(Rect2(tx, -24.0, 28.0, 4.0), Color("#2c1d12"))
	draw_rect(Rect2(tx + 11.0, -25.0, 6.0, 6.0), Color("#ffd84d"))
	if character_id == "kucharz":
		draw_rect(Rect2(tx + 4.0, -47.0, 20.0, 26.0), Color("#fffaf0"))
		draw_line(Vector2(tx + 4.0, -47.0), Vector2(tx + 1.0, -25.0), Color("#d6cfbc"), 2.0)
		draw_line(Vector2(tx + 24.0, -47.0), Vector2(tx + 27.0, -25.0), Color("#d6cfbc"), 2.0)
	# głowa, broda, oko
	var hx: float = -9.0 + lean
	draw_rect(Rect2(hx, -70.0, 18.0, 18.0), sk)
	draw_rect(Rect2(hx, -60.0, 18.0, 10.0), Color("#6b3e1f"))
	draw_rect(Rect2(hx + 10.0, -63.0, 8.0, 4.0), Color("#6b3e1f"))
	draw_rect(Rect2(hx + 11.0, -67.0, 3.0, 3.0), Color.BLACK)
	if character_id == "radiowiec":
		draw_arc(Vector2(hx + 9.0, -70.0), 12.0, PI, TAU, 16, hat_color, 3.0)
		draw_circle(Vector2(hx - 2.0, -69.0), 5.0, Color("#262c30"))
		draw_circle(Vector2(hx + 20.0, -69.0), 5.0, Color("#262c30"))
		draw_circle(Vector2(hx - 2.0, -69.0), 3.0, hat_color)
		draw_line(Vector2(hx + 20.0, -69.0), Vector2(hx + 23.0, -60.0), hat_color, 2.0)
	elif character_id == "inzynier":
		draw_rect(Rect2(hx - 5.0, -76.0, 28.0, 6.0), Color("#d49a0b"))
		draw_colored_polygon(PackedVector2Array([Vector2(hx - 2.0, -76.0), Vector2(hx + 1.0, -87.0), Vector2(hx + 15.0, -87.0), Vector2(hx + 20.0, -76.0)]), hat_color)
		draw_rect(Rect2(hx + 1.0, -66.0, 7.0, 4.0), Color("#7ce4e9"), false, 2.0)
		draw_rect(Rect2(hx + 12.0, -66.0, 7.0, 4.0), Color("#7ce4e9"), false, 2.0)
		draw_line(Vector2(hx + 8.0, -64.0), Vector2(hx + 12.0, -64.0), Color("#303b40"), 2.0)
	elif character_id == "botanik":
		draw_rect(Rect2(hx - 9.0, -78.0, 36.0, 5.0), Color("#987742"))
		draw_colored_polygon(PackedVector2Array([Vector2(hx - 3.0, -78.0), Vector2(hx + 1.0, -87.0), Vector2(hx + 15.0, -87.0), Vector2(hx + 21.0, -78.0)]), hat_color)
		draw_colored_polygon(PackedVector2Array([Vector2(hx + 8.0, -88.0), Vector2(hx + 13.0, -101.0), Vector2(hx + 17.0, -87.0)]), Color("#51b86b"))
	elif character_id == "kibic":
		draw_rect(Rect2(hx - 1.0, -79.0, 20.0, 9.0), hat_color)
		draw_rect(Rect2(hx - 1.0, -75.0, 20.0, 3.0), Color("#d62828"))
		draw_rect(Rect2(hx + 15.0, -73.0, 8.0, 3.0), Color("#143a9c"))
		draw_circle(Vector2(hx + 9.0, -81.0), 4.0, Color.WHITE)
		draw_rect(Rect2(hx - 13.0, -47.0, 10.0, 28.0), Color("#d62828"))
		draw_rect(Rect2(hx - 13.0, -35.0, 10.0, 5.0), Color("#ffd84d"))
	elif character_id == "kucharz":
		draw_rect(Rect2(hx - 2.0, -78.0, 22.0, 7.0), Color("#e4dfd4"))
		draw_colored_polygon(PackedVector2Array([Vector2(hx, -77.0), Vector2(hx - 2.0, -87.0), Vector2(hx + 1.0, -95.0), Vector2(hx + 7.0, -91.0), Vector2(hx + 13.0, -97.0), Vector2(hx + 19.0, -91.0), Vector2(hx + 21.0, -77.0)]), hat_color)
	elif character_id == "astronom":
		draw_colored_polygon(PackedVector2Array([Vector2(hx - 3.0, -75.0), Vector2(hx - 1.0, -88.0), Vector2(hx + 9.0, -97.0), Vector2(hx + 19.0, -88.0), Vector2(hx + 22.0, -75.0)]), hat_color)
		draw_rect(Rect2(hx + 4.0, -66.0, 5.0, 4.0), Color("#99e8ff"))
		draw_rect(Rect2(hx + 13.0, -66.0, 5.0, 4.0), Color("#99e8ff"))
		draw_circle(Vector2(hx + 26.0, -82.0), 2.5, Color("#fff0a8"))
	elif character_id == "fotograf":
		draw_rect(Rect2(hx - 2.0, -78.0, 22.0, 7.0), Color("#22252a"))
		draw_rect(Rect2(hx + 1.0, -87.0, 16.0, 10.0), hat_color)
		draw_rect(Rect2(tx + 18.0, -43.0, 13.0, 10.0), Color("#26272a"))
		draw_circle(Vector2(tx + 24.0, -38.0), 3.0, Color("#89d7eb"))
	elif character_id == "motorniczy":
		draw_rect(Rect2(hx - 2.0, -79.0, 24.0, 9.0), hat_color)
		draw_rect(Rect2(hx - 4.0, -73.0, 28.0, 3.0), Color("#e5c15a"))
		draw_rect(Rect2(hx + 3.0, -85.0, 12.0, 7.0), Color("#23477a"))
		draw_circle(Vector2(hx + 9.0, -83.0), 2.0, Color("#ffd84d"))
	else:
		draw_rect(Rect2(hx - 1.0, -79.0, 20.0, 9.0), hat_color)
		draw_rect(Rect2(hx - 1.0, -73.0, 20.0, 3.0), Color("#d62828"))
		draw_rect(Rect2(hx + 16.0, -73.0, 7.0, 3.0), Color("#143a9c"))
		draw_circle(Vector2(hx + 9.0, -81.0), 4.0, Color.WHITE)
 
	# przednia ręka + siekiera
	var sh: Vector2 = Vector2(8.0 + lean, -44.0)
	var d: Vector2 = Vector2(cos(axe_a), sin(axe_a))
	var perp: Vector2 = Vector2(-d.y, d.x)
	var hand: Vector2 = sh + d * 18.0
	var tip: Vector2 = sh + d * 40.0
	draw_line(sh, hand, red, 8.0)
	draw_line(hand - d * 8.0, tip, Color("#8b5a2b"), 4.0)
	draw_circle(hand, 4.5, sk)
	var head: PackedVector2Array = PackedVector2Array([
		tip - d * 4.0 + perp * 4.0,
		tip - d * 4.0 - perp * 4.0,
		tip + d * 8.0 - perp * 12.0,
		tip + d * 8.0 + perp * 12.0,
	])
	draw_colored_polygon(head, Color("#b8c4c9"))
	draw_line(tip + d * 8.0 + perp * 12.0, tip + d * 8.0 - perp * 12.0, Color.WHITE, 2.0)
	if character_id == "radiowiec":
		draw_rect(Rect2(tx + 2.0, -39.0, 5.0, 7.0), Color("#ffd84d"))
	elif character_id == "botanik":
		draw_colored_polygon(PackedVector2Array([Vector2(tx + 18.0, -50.0), Vector2(tx + 26.0, -57.0), Vector2(tx + 25.0, -46.0)]), Color("#65d47a"))
	elif character_id == "fotograf":
		draw_line(Vector2(tx + 2.0, -52.0), Vector2(tx + 20.0, -28.0), Color("#272522"), 3.0)
	elif character_id == "motorniczy":
		draw_rect(Rect2(tx + 4.0, -48.0, 3.0, 18.0), Color("#f7db78"))
	elif character_id == "astronom":
		draw_circle(Vector2(tx + 14.0, -39.0), 5.0, Color("#bba7ff"))

	draw_set_transform(cur_off, 0.0, Vector2.ONE)
 
	# gwiazdki po uderzeniu
	if state == State.DEAD and dead_time < 1.4:
		for k in range(3):
			var a: float = t * 6.0 + float(k) * 2.1
			draw_circle(pos + Vector2(cos(a) * 16.0, -92.0 + sin(a) * 5.0), 3.0, Color("#ffd84d"))
 
 
# ---- interfejs
 
func txt(s: String, y: float, size: int, col: Color = Color.WHITE) -> void:
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(2.0, y + 2.0), s, HORIZONTAL_ALIGNMENT_CENTER, W, size, Color(0, 0, 0, 0.6 * col.a))
	draw_string(font, Vector2(0.0, y), s, HORIZONTAL_ALIGNMENT_CENTER, W, size, col)
 
 
func txt_out(s: String, y: float, size: int, col: Color = Color.WHITE) -> void:
	var font: Font = ThemeDB.fallback_font
	for o in [Vector2(-3, 0), Vector2(3, 0), Vector2(0, -3), Vector2(0, 3), Vector2(3, 3)]:
		draw_string(font, Vector2(0.0, y) + o, s, HORIZONTAL_ALIGNMENT_CENTER, W, size, Color("#10151f"))
	draw_string(font, Vector2(0.0, y), s, HORIZONTAL_ALIGNMENT_CENTER, W, size, col)
 
 
func panel(y: float, h: float, alpha: float) -> void:
	draw_rect(Rect2(30.0, y, 420.0, h), Color(0.04, 0.07, 0.16, 0.72 * alpha))
	draw_rect(Rect2(30.0, y, 420.0, h), Color(1, 1, 1, 0.35 * alpha), false, 2.0)
	draw_rect(Rect2(30.0, y, 210.0, 5.0), Color("#1d4ed8"))
	draw_rect(Rect2(240.0, y, 210.0, 5.0), Color("#d62828"))
 
 
func draw_hud() -> void:
	if state == State.WAIT:
		draw_menu()
		return
	if state == State.SHOP:
		draw_shop()
		return

	# pasek zasilania
	var bar: Rect2 = Rect2(70.0, 18.0, 350.0, 24.0)
	var visual_energy: float = clampf(energy / energy_cap(), 0.0, 1.0)
	draw_rect(Rect2(bar.position - Vector2(3, 3), bar.size + Vector2(6, 6)), Color("#10151f"))
	draw_rect(bar, Color(0, 0, 0, 0.55))
	var ec: Color = Color("#d62828").lerp(Color("#3ddc84"), visual_energy)
	draw_rect(Rect2(bar.position, Vector2(bar.size.x * visual_energy, bar.size.y)), ec)
	draw_rect(Rect2(bar.position, Vector2(bar.size.x * visual_energy, 8.0)), Color(1, 1, 1, 0.25))
	for k in range(1, 6):
		var lx: float = bar.position.x + bar.size.x * float(k) / 6.0
		draw_line(Vector2(lx, bar.position.y), Vector2(lx, bar.position.y + bar.size.y), Color(0, 0, 0, 0.35), 2.0)
	draw_rect(bar, Color.WHITE, false, 2.0)
	if visual_energy < 0.25 and state == State.PLAY:
		draw_rect(bar, Color(1, 0, 0, 0.25 + 0.25 * sin(t * 14.0)))
	draw_colored_polygon(PackedVector2Array([Vector2(52.0, 14.0), Vector2(38.0, 33.0), Vector2(47.0, 33.0), Vector2(41.0, 48.0), Vector2(59.0, 27.0), Vector2(50.0, 27.0), Vector2(56.0, 14.0)]), Color("#ffd84d"))
	txt("ZASILANIE NADAJNIKA", 62.0, 13, Color(1, 1, 1, 0.85))
 
	var mode: Dictionary = selected_mode()
	var target: int = int(mode["target"])
	var meter_max: int = target if target > 0 else maxi(best, 100)
	var frac: float = clampf(float(score) / float(meter_max), 0.0, 1.0)
	var gold: Color = Color("#ffd84d") if reached_top else Color("#3ddc84")
	draw_rect(Rect2(457.0, 197.0, 14.0, 304.0), Color("#10151f"))
	draw_rect(Rect2(459.0, 199.0, 10.0, 300.0), Color(0, 0, 0, 0.5))
	draw_rect(Rect2(459.0, 499.0 - 300.0 * frac, 10.0, 300.0 * frac), gold)
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(426.0, 190.0), "%d m" % meter_max, HORIZONTAL_ALIGNMENT_CENTER, 72.0, 12, Color(1, 1, 1, 0.85))
	draw_string(font, Vector2(14.0, 92.0), "PIEROGI: %d" % pierogi, HORIZONTAL_ALIGNMENT_LEFT, 180.0, 15, Color("#ffd84d"))

	if state == State.PLAY:
		txt_out(str(score), 140.0, 72)
		txt("%d m / %s" % [score, "%d m" % target if target > 0 else "∞"], 168.0, 16, Color(1, 1, 1, 0.85))
		txt("SERIA: %d / 10" % (combo_streak % 10 if combo_streak % 10 != 0 else 10), 194.0, 13, Color("#ffe28a"))
	else:
		var cleared: bool = state == State.CLEAR
		var al: float = clampf(clear_time * 3.0 if cleared else dead_time * 3.0, 0.0, 1.0)
		panel(200.0, 330.0, al)
		txt("MAKIETA GOTOWA!" if cleared else death_msg, 258.0, 28, Color("#3ddc84") if cleared else Color(1.0, 0.42, 0.36, al))
		txt("Makieta: %s" % mode["name"] if cleared else str(equipped_character()["name"]), 292.0, 18, Color(0.6, 0.85, 1.0, al))
		txt_out("%d" % score, 370.0, 64, Color(1, 1, 1, al))
		txt("umownych metrów makiety", 394.0, 16, Color(1, 1, 1, 0.85 * al))
		txt("Rekord: %d m" % best, 430.0, 20, Color(1.0, 0.85, 0.3, al))
		txt("Seria udanych cięć: %d" % combo_streak, 486.0, 15, Color("#ffe28a"))
		if new_record and fmod(t, 0.8) < 0.5:
			txt("NOWY REKORD!", 462.0, 22, Color("#3ddc84"))
		txt("Ciekawostka: " + GLIWICE_FACTS[fact_index], 514.0, 13, Color("#fff1bb"))
		if (cleared and clear_time > 0.5) or (not cleared and dead_time > 0.5):
			txt("Dotknij lub naciśnij Enter, aby wrócić", 566.0, 17)
 
	# baner dzielnicy / szczytu
	if banner_t > 0.0:
		var ba: float = clampf(banner_t * 2.0, 0.0, 1.0) * clampf((2.4 - banner_t) * 6.0, 0.0, 1.0)
		draw_rect(Rect2(0.0, 205.0, 240.0, 62.0), Color(0.11, 0.31, 0.93, 0.85 * ba))
		draw_rect(Rect2(240.0, 205.0, 240.0, 62.0), Color(0.84, 0.16, 0.16, 0.85 * ba))
		txt(banner_top, 229.0, 15, Color(1, 1, 1, ba))
		var banner_size: int = 14 if banner_main.length() > 42 else (18 if banner_main.length() > 22 else 28)
		txt(banner_main, 257.0, banner_size, Color(1, 0.95, 0.6, ba))


func draw_menu() -> void:
	panel(34.0, 730.0, 1.0)
	txt_out("TIMBER • GLIWICE", 83.0 + sin(t * 2.0) * 2.0, 32, Color("#ffd84d"))
	txt("MAKIETOWA WSPINACZKA ARCADE", 111.0, 13, Color(1, 1, 1, 0.82))
	txt("Portfel: %d pierogów" % pierogi, 143.0, 17, Color("#ffd84d"))
	txt("WYBIERZ TRYB", 174.0, 17)
	for i in range(MODES.size()):
		var mode: Dictionary = MODES[i]
		var col: int = i % 2
		var row: int = i / 2
		var rect: Rect2 = Rect2(44.0 + float(col) * 202.0, 185.0 + float(row) * 68.0, 190.0, 58.0)
		var accent: Color = mode["color"]
		var selected: bool = str(mode["id"]) == current_mode_id
		draw_rect(rect, Color(0.07, 0.12, 0.23, 0.96))
		draw_rect(rect, accent if selected else Color(1, 1, 1, 0.3), false, 3.0 if selected else 1.0)
		draw_rect(Rect2(rect.position.x, rect.position.y, 6.0, rect.size.y), accent)
		draw_menu_text(str(mode["name"]), rect.position.y + 25.0, rect.position.x + 12.0, rect.size.x - 18.0, 16, Color.WHITE)
		draw_menu_text(str(mode["detail"]), rect.position.y + 46.0, rect.position.x + 10.0, rect.size.x - 15.0, 11, Color(1, 1, 1, 0.75))

	var equipped_character_data: Dictionary = equipped_character()
	draw_rect(Rect2(54.0, 337.0, 372.0, 80.0), Color(0.07, 0.12, 0.23, 0.96))
	draw_rect(Rect2(54.0, 337.0, 372.0, 80.0), Color("#ffd84d"), false, 2.0)
	draw_circle(Vector2(95.0, 377.0), 27.0, equipped_character_data["shirt"])
	draw_circle(Vector2(95.0, 377.0), 14.0, equipped_character_data["hat"])
	draw_menu_text("SKLEP POSTACI  •  %d / %d" % [owned_characters.size(), CHARACTERS.size()], 366.0, 134.0, 275.0, 18, Color("#ffd84d"))
	draw_menu_text("%s  |  %s" % [equipped_character_data["name"], equipped_character_data["perk"]], 396.0, 134.0, 275.0, 12, Color.WHITE)

	var mode_best: int = int(best_by_mode.get(current_mode_id, best))
	draw_rect(Rect2(74.0, 426.0, 332.0, 25.0), Color(0.05, 0.08, 0.15, 0.8))
	txt("%s  •  rekord: %d m" % [selected_mode()["name"], mode_best], 446.0, 15, Color("#ffd84d"))
	draw_rect(Rect2(82.0, 463.0, 316.0, 62.0), Color("#24784e"))
	draw_rect(Rect2(82.0, 463.0, 316.0, 62.0), Color("#a6ffd0"), false, 2.0)
	txt("START  •  ENTER", 502.0, 25, Color.WHITE)
	txt("A/D: tryb • B: sklep • Enter: start", 550.0, 13, Color(1, 1, 1, 0.8))

	draw_rect(Rect2(48.0, 574.0, 384.0, 130.0), Color(0.1, 0.13, 0.2, 0.93))
	draw_rect(Rect2(48.0, 574.0, 384.0, 130.0), Color("#ffd84d"), false, 1.0)
	txt("GLIWICKA CIEKAWOSTKA • RUNDA %d" % (round_number + 1), 600.0, 14, Color("#ffd84d"))
	var fact: String = GLIWICE_FACTS[round_number % GLIWICE_FACTS.size()]
	var fact_size: int = 11 if fact.length() > 48 else 13
	draw_menu_text(fact, 640.0, 62.0, 356.0, fact_size, Color.WHITE)
	draw_menu_text("Makiety są z kartonu; anteny to tylko przeszkody gry.", 672.0, 62.0, 356.0, 11, Color(1, 1, 1, 0.7))

func draw_shop() -> void:
	draw_rect(Rect2(0.0, 0.0, W, H), Color("#11172a"))
	draw_rect(Rect2(0.0, 0.0, W, 210.0), Color("#192c4d"))
	panel(30.0, 740.0, 1.0)
	txt_out("SKLEP GLIWICKICH LEGEND", 82.0, 27, Color("#ffd84d"))
	txt("POSTACIE • TALENTY • PIEROGI", 111.0, 13, Color(1, 1, 1, 0.8))
	draw_rect(Rect2(96.0, 128.0, 288.0, 34.0), Color("#392f20"))
	draw_rect(Rect2(96.0, 128.0, 288.0, 34.0), Color("#ffd84d"), false, 1.0)
	txt("TWÓJ PORTFEL: %d PIEROGÓW" % pierogi, 152.0, 17, Color("#ffe28a"))

	var character: Dictionary = selected_character()
	var accent: Color = character["shirt"]
	draw_circle(Vector2(CX, 340.0), 112.0 + sin(t * 2.0) * 3.0, Color(accent.r, accent.g, accent.b, 0.2))
	draw_circle(Vector2(CX, 340.0), 86.0, Color("#202c40"))
	draw_circle(Vector2(CX, 340.0), 86.0, Color(1, 1, 1, 0.35), false, 2.0)
	draw_line(Vector2(80.0, 455.0), Vector2(400.0, 455.0), Color(accent, 0.6), 2.0)
	draw_player(CX, 455.0, 1.3, true)
	draw_menu_text("‹", 371.0, 28.0, 78.0, 54, Color("#ffd84d"))
	draw_menu_text("›", 371.0, 374.0, 78.0, 54, Color("#ffd84d"))

	txt("%s" % character["name"], 493.0, 24, Color.WHITE)
	txt("%d / %d" % [character_index + 1, CHARACTERS.size()], 518.0, 13, Color(1, 1, 1, 0.7))
	draw_menu_text(str(character["detail"]), 546.0, 48.0, 384.0, 13, Color(1, 1, 1, 0.9))
	draw_rect(Rect2(52.0, 560.0, 376.0, 33.0), Color(0.12, 0.2, 0.3))
	draw_menu_text("PASYWKA: " + str(character["perk"]), 582.0, 62.0, 356.0, 12, Color("#a8e7ff"))

	var owned: bool = owned_characters.has(str(character["id"]))
	var equipped: bool = str(character["id"]) == equipped_character_id
	var can_afford: bool = pierogi >= int(character["cost"])
	var price_text: String = "CENA: %d PIEROGÓW" % int(character["cost"]) if int(character["cost"]) > 0 else "CENA: DARMOWA"
	var ownership_text: String = " • ZAŁOŻONA" if equipped else (" • KUPIONA" if owned else "")
	draw_menu_text(price_text + ownership_text, 608.0, 62.0, 356.0, 13, Color("#ffe28a"))
	var action_text: String = "ZAŁOŻONA  ✓" if equipped else ("WYBIERZ TĘ POSTAĆ" if owned else ("KUP ZA  %d  PIEROGÓW" % int(character["cost"]) if can_afford else "BRAKUJE %d PIEROGÓW" % (int(character["cost"]) - pierogi)))
	var action_color: Color = Color("#397b53") if equipped else (Color("#2367a8") if owned else (Color("#956a18") if can_afford else Color("#634443")))
	draw_rect(Rect2(64.0, 615.0, 352.0, 58.0), action_color)
	draw_rect(Rect2(64.0, 615.0, 352.0, 58.0), Color(1, 1, 1, 0.65), false, 2.0)
	txt(action_text, 650.0, 18 if action_text.length() < 27 else 15, Color.WHITE)
	txt("A/D lub strzałki: przeglądaj   •   Enter: kup / wybierz", 699.0, 12, Color(1, 1, 1, 0.75))
	draw_rect(Rect2(112.0, 711.0, 256.0, 48.0), Color("#273249"))
	draw_rect(Rect2(112.0, 711.0, 256.0, 48.0), Color("#a9bad4"), false, 1.0)
	txt("←  WRÓĆ DO MENU  •  ESC", 742.0, 16, Color.WHITE)


func draw_menu_text(text: String, baseline: float, x: float, width: float, size: int, color: Color) -> void:
	draw_string(ThemeDB.fallback_font, Vector2(x, baseline), text, HORIZONTAL_ALIGNMENT_CENTER, width, size, color)
 
