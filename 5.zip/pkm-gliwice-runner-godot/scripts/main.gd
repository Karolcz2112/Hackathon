extends Node2D

## Three-lane top-down endless runner. All art is drawn here; no assets required.
const LANE_COUNT: int = 3
const GOAL_SPEED: float = 500.0

var rng := RandomNumberGenerator.new()
var font: Font
var view_size := Vector2(540.0, 720.0)
var lane: int = 1
var entities: Array[Dictionary] = []
var scenery: Array[Dictionary] = []
var stars: Array[Dictionary] = []
var running: bool = false
var finished: bool = false
var score: int = 0
var distance_progress: float = 0.0
var tickets: int = 0
var best_score: int = 0
var speed: float = 245.0
var spawn_clock: float = 0.0
var road_offset: float = 0.0
var lane_width: float = 100.0
var road_left: float = 0.0

func _ready() -> void:
	rng.randomize()
	font = ThemeDB.fallback_font
	var save := ConfigFile.new()
	if save.load("user://pkm_gliwice.cfg") == OK:
		best_score = int(save.get_value("wyniki", "rekord", 0))
	get_viewport().size_changed.connect(_on_viewport_size_changed)
	_update_layout()
	_reset_scenery()
	queue_redraw()

func _on_viewport_size_changed() -> void:
	_update_layout()
	_reset_scenery()
	queue_redraw()

func _update_layout() -> void:
	view_size = get_viewport_rect().size
	road_left = view_size.x * 0.12
	lane_width = view_size.x * 0.76 / float(LANE_COUNT)

func _lane_x(which_lane: int) -> float:
	return road_left + lane_width * (float(which_lane) + 0.5)

func _reset_scenery() -> void:
	scenery.clear()
	stars.clear()
	for i in range(12):
		for side in range(2):
			var x: float = rng.randf_range(12.0, road_left - 18.0) if side == 0 else rng.randf_range(road_left + lane_width * LANE_COUNT + 18.0, view_size.x - 12.0)
			scenery.append({"x": x, "y": float(i) * 80.0, "kind": side, "shade": rng.randi_range(0, 2)})
	for i in range(int(view_size.x * view_size.y / 3200.0)):
		stars.append({"x": rng.randf_range(0.0, view_size.x), "y": rng.randf_range(0.0, view_size.y * 0.34), "r": rng.randf_range(0.7, 1.7), "a": rng.randf_range(0.2, 0.7)})

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_LEFT or event.keycode == KEY_A:
			_change_lane(-1)
		elif event.keycode == KEY_RIGHT or event.keycode == KEY_D:
			_change_lane(1)
		elif (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER) and not running:
			_start_game()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if not running:
			_start_game()
			return
		var local_x: float = event.position.x
		_change_lane(-1 if local_x < view_size.x * 0.5 else 1)
	elif event is InputEventScreenTouch and event.pressed:
		if not running:
			_start_game()
			return
		_change_lane(-1 if event.position.x < view_size.x * 0.5 else 1)

func _start_game() -> void:
	lane = 1
	entities.clear()
	score = 0
	distance_progress = 0.0
	tickets = 0
	speed = 245.0
	spawn_clock = 0.35
	road_offset = 0.0
	running = true
	finished = false
	queue_redraw()

func _change_lane(direction: int) -> void:
	if not running:
		_start_game()
		return
	lane = clampi(lane + direction, 0, LANE_COUNT - 1)

func _spawn_entity() -> void:
	var kind: String = "bus" if rng.randf() < 0.73 else "ticket"
	var new_lane: int = rng.randi_range(0, LANE_COUNT - 1)
	if kind == "bus":
		for entity in entities:
			if entity["kind"] == "bus" and float(entity["y"]) < 100.0 and int(entity["lane"]) == new_lane:
				new_lane = (new_lane + rng.randi_range(1, 2)) % LANE_COUNT
				break
	entities.append({"kind": kind, "lane": new_lane, "y": -90.0})

func _process(delta: float) -> void:
	var dt: float = minf(delta, 0.04)
	if running:
		speed = minf(GOAL_SPEED, 245.0 + float(score) * 0.65)
		road_offset = fposmod(road_offset + speed * dt, 74.0)
		spawn_clock += dt
		if spawn_clock >= maxf(0.47, 0.92 - float(score) / 3000.0):
			spawn_clock = 0.0
			_spawn_entity()
		_update_entities(dt)
		_update_scenery(dt)
		distance_progress += speed * dt / 28.0
		var whole_meters: int = int(distance_progress)
		if whole_meters > 0:
			score += whole_meters
			distance_progress -= float(whole_meters)
		if score > best_score:
			best_score = score
			_save_best()
	queue_redraw()

func _update_entities(delta: float) -> void:
	for i in range(entities.size() - 1, -1, -1):
		var entity: Dictionary = entities[i]
		entity["y"] = float(entity["y"]) + speed * delta
		if int(entity["lane"]) == lane and float(entity["y"]) > view_size.y * 0.75 - 44.0 and float(entity["y"]) < view_size.y * 0.75 + 48.0:
			if entity["kind"] == "bus":
				_finish()
				return
			tickets += 1
			entities.remove_at(i)
		elif float(entity["y"]) > view_size.y + 70.0:
			entities.remove_at(i)

func _update_scenery(delta: float) -> void:
	for item in scenery:
		item["y"] = float(item["y"]) + speed * delta * 0.52
		if float(item["y"]) > view_size.y + 30.0:
			item["y"] = -rng.randf_range(40.0, 150.0)
	for star in stars:
		star["y"] = float(star["y"]) + speed * delta * 0.025
		if float(star["y"]) > view_size.y * 0.34:
			star["y"] = 0.0
			star["x"] = rng.randf_range(0.0, view_size.x)

func _finish() -> void:
	running = false
	finished = true
	_save_best()
	queue_redraw()

func _save_best() -> void:
	var save := ConfigFile.new()
	save.set_value("wyniki", "rekord", best_score)
	save.save("user://pkm_gliwice.cfg")

func _draw() -> void:
	_draw_background()
	_draw_road()
	for entity in entities:
		var pos := Vector2(_lane_x(int(entity["lane"])), float(entity["y"]))
		if entity["kind"] == "bus":
			_draw_bus(pos, false)
		else:
			_draw_ticket(pos)
	if running:
		_draw_runner(Vector2(_lane_x(lane), view_size.y * 0.78))
		_draw_hud()
	else:
		_draw_overlay()

func _draw_background() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color("#9fc9d0"))
	draw_rect(Rect2(0.0, view_size.y * 0.34, view_size.x, view_size.y * 0.66), Color("#657b5f"))
	for star in stars:
		draw_circle(Vector2(float(star["x"]), float(star["y"])), float(star["r"]), Color(1.0, 0.95, 0.8, float(star["a"])))
	for item in scenery:
		var p := Vector2(float(item["x"]), float(item["y"]))
		if int(item["kind"]) == 0:
			draw_circle(p, 10.0, Color("#718861") if int(item["shade"]) == 0 else Color("#82916a"))
			draw_rect(Rect2(p.x - 2.0, p.y + 7.0, 4.0, 8.0), Color("#9a8561"))
		else:
			draw_rect(Rect2(p.x - 10.0, p.y - 5.0, 20.0, 13.0), Color("#879691"))

func _draw_road() -> void:
	var road_right: float = road_left + lane_width * float(LANE_COUNT)
	draw_rect(Rect2(0.0, view_size.y * 0.34, road_left, view_size.y * 0.66), Color("#687b60"))
	draw_rect(Rect2(road_right, view_size.y * 0.34, view_size.x - road_right, view_size.y * 0.66), Color("#687b60"))
	draw_rect(Rect2(road_left, view_size.y * 0.34, road_right - road_left, view_size.y * 0.66), Color("#343d45"))
	draw_rect(Rect2(road_left, view_size.y * 0.34, 4.0, view_size.y * 0.66), Color("#d7c88e"))
	draw_rect(Rect2(road_right - 4.0, view_size.y * 0.34, 4.0, view_size.y * 0.66), Color("#d7c88e"))
	for separator in range(1, LANE_COUNT):
		var x: float = road_left + lane_width * float(separator)
		var y: float = view_size.y * 0.34 - 74.0 + road_offset
		while y < view_size.y:
			draw_rect(Rect2(x - 1.5, y, 3.0, 36.0), Color("#ced0c4"))
			y += 74.0

func _draw_bus(pos: Vector2, player_bus: bool) -> void:
	var w: float = lane_width * 0.58
	var h: float = w * 1.63
	var body := Color("#f5bf24") if not player_bus else Color("#f5bf24")
	var rect := Rect2(pos.x - w * 0.5, pos.y - h * 0.5, w, h)
	draw_rect(Rect2(rect.position + Vector2(2.0, 5.0), rect.size), Color(0.0, 0.0, 0.0, 0.28))
	draw_rect(rect, body)
	draw_rect(Rect2(pos.x - w * 0.37, pos.y - h * 0.39, w * 0.74, h * 0.27), Color("#263b4c"))
	draw_rect(Rect2(pos.x - w * 0.34, pos.y - h * 0.02, w * 0.68, h * 0.39), Color("#e6edf0"))
	draw_rect(Rect2(pos.x - w * 0.35, pos.y + h * 0.36, w * 0.7, h * 0.09), Color("#edaa1c"))
	_draw_text("PKM GLIWICE", Vector2(pos.x - w * 0.37, pos.y + h * 0.27), maxf(7.0, w * 0.115), Color("#25303a"))
	draw_rect(Rect2(pos.x - w * 0.35, pos.y - h * 0.48, w * 0.22, 4.0), Color("#fff4bd"))
	draw_rect(Rect2(pos.x + w * 0.13, pos.y - h * 0.48, w * 0.22, 4.0), Color("#fff4bd"))
	draw_rect(Rect2(pos.x - w * 0.53, pos.y - h * 0.28, w * 0.08, h * 0.16), Color("#202735"))
	draw_rect(Rect2(pos.x + w * 0.45, pos.y - h * 0.28, w * 0.08, h * 0.16), Color("#202735"))

func _draw_ticket(pos: Vector2) -> void:
	draw_rect(Rect2(pos.x - 10.0, pos.y - 14.0, 20.0, 28.0), Color("#ffe478"))
	draw_rect(Rect2(pos.x - 6.0, pos.y - 10.0, 12.0, 20.0), Color("#a6741a"), false, 1.5)
	_draw_text("T", Vector2(pos.x - 4.0, pos.y + 5.0), 13.0, Color("#684c1e"))

func _draw_runner(pos: Vector2) -> void:
	draw_circle(pos + Vector2(0.0, 13.0), 13.0, Color(0.0, 0.0, 0.0, 0.24))
	draw_colored_polygon(PackedVector2Array([pos + Vector2(0.0, -17.0), pos + Vector2(11.0, -4.0), pos + Vector2(9.0, 12.0), pos + Vector2(-9.0, 12.0), pos + Vector2(-11.0, -4.0)]), Color("#39a87e"))
	draw_circle(pos + Vector2(0.0, -14.0), 6.0, Color("#f0c79b"))
	draw_rect(Rect2(pos.x - 8.0, pos.y + 9.0, 6.0, 9.0), Color("#25303c"))
	draw_rect(Rect2(pos.x + 2.0, pos.y + 9.0, 6.0, 9.0), Color("#25303c"))

func _draw_hud() -> void:
	draw_rect(Rect2(12.0, 12.0, view_size.x - 24.0, 54.0), Color(0.04, 0.07, 0.11, 0.78))
	_draw_text("DYSTANS", Vector2(24.0, 31.0), 10.0, Color("#c3ccdb"))
	_draw_text("%d m" % score, Vector2(24.0, 54.0), 21.0, Color("#fff3cf"))
	_draw_text("BILETY  %d" % tickets, Vector2(view_size.x * 0.47, 46.0), 16.0, Color("#ffe478"))
	_draw_text("REKORD %d" % best_score, Vector2(view_size.x - 112.0, 32.0), 11.0, Color("#87e8c5"))

func _draw_overlay() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color(0.025, 0.04, 0.08, 0.72))
	var center: float = view_size.x * 0.5
	_draw_text("MIEJSKA GRA ZRĘCZNOŚCIOWA", Vector2(center - 112.0, view_size.y * 0.31), 11.0, Color("#87e8c5"))
	_draw_text("PKM GLIWICE", Vector2(center - 98.0, view_size.y * 0.41), 28.0, Color("#fff3cf"))
	_draw_text("KURS NA REKORD", Vector2(center - 95.0, view_size.y * 0.47), 18.0, Color("#ffd34f"))
	if finished:
		_draw_text("KONIEC KURSU", Vector2(center - 71.0, view_size.y * 0.55), 16.0, Color("#ff9a8b"))
		_draw_text("Dystans: %d m  •  bilety: %d" % [score, tickets], Vector2(center - 115.0, view_size.y * 0.60), 12.0, Color("#e4eaf2"))
	else:
		_draw_text("Unikaj żółtych autobusów i zbieraj bilety", Vector2(center - 137.0, view_size.y * 0.56), 12.0, Color("#e4eaf2"))
	_draw_text("← → / A D   •   tapnij lewą lub prawą stronę", Vector2(center - 133.0, view_size.y * 0.66), 11.0, Color("#c3ccdb"))
	_draw_text("KLIKNIJ LUB SPACJA, ABY RUSZYĆ", Vector2(center - 120.0, view_size.y * 0.75), 12.0, Color("#87e8c5"))

func _draw_text(text: String, pos: Vector2, size: float, color: Color) -> void:
	if font != null:
		draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, int(size), color)
