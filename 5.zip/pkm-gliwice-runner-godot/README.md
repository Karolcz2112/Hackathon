# PKM Gliwice: Kurs na rekord — Godot 4

## Uruchomienie
1. Zainstaluj Godot 4.
2. Wybierz **Importuj** i wskaż `project.godot` w tym folderze.
3. Uruchom projekt klawiszem **F5**.

## Sterowanie
- **← / →** albo **A / D** — zmiana pasa
- **Kliknięcie/tap po lewej lub prawej stronie** — zmiana pasa
- **Spacja** — start lub ponowny start

Omijaj nadjeżdżające autobusy PKM Gliwice i zbieraj bilety. Wynik oraz rekord zapisują się lokalnie.

## Assety
Nie są potrzebne. Autobusy, bilet, droga, tło, drzewa, biegacz i interfejs są rysowane bezpośrednio w skrypcie. Własne grafiki i dźwięki można dodać później.
