extends Node2D
## Prototyp: autobus 2D, widok z góry, wygląd pixel-art (320x180). Zero zewnętrznych assetów.
## Sterowanie: strzałki lub WASD. Cel: dojeżdżaj na kolejne żółte przystanki i zatrzymuj się.

const VIEW_W := 320.0
const VIEW_H := 180.0
const MAX_SPEED := 110.0
const GRASS_SPEED := 50.0
const REVERSE_SPEED := 35.0
const ACCEL := 90.0
const BRAKE := 200.0
const FRICTION := 45.0
const TURN_RATE := 2.2
const START_TIME := 60.0
const STOP_TIME := 1.2
const BONUS_TIME := 15.0

enum State { WAIT, PLAY, OVER }

# Pikselowa czcionka 3x5 (tylko wielkie litery ASCII, cyfry i kilka znaków).
const FONT = {
	"A": [".X.", "X.X", "XXX", "X.X", "X.X"],
	"B": ["XX.", "X.X", "XX.", "X.X", "XX."],
	"C": [".XX", "X..", "X..", "X..", ".XX"],
	"D": ["XX.", "X.X", "X.X", "X.X", "XX."],
	"E": ["XXX", "X..", "XX.", "X..", "XXX"],
	"F": ["XXX", "X..", "XX.", "X..", "X.."],
	"G": [".XX", "X..", "X.X", "X.X", ".XX"],
	"H": ["X.X", "X.X", "XXX", "X.X", "X.X"],
	"I": ["XXX", ".X.", ".X.", ".X.", "XXX"],
	"J": ["..X", "..X", "..X", "X.X", ".X."],
	"K": ["X.X", "X.X", "XX.", "X.X", "X.X"],
	"L": ["X..", "X..", "X..", "X..", "XXX"],
	"M": ["X.X", "XXX", "XXX", "X.X", "X.X"],
	"N": ["XXX", "X.X", "X.X", "X.X", "X.X"],
	"O": [".X.", "X.X", "X.X", "X.X", ".X."],
	"P": ["XX.", "X.X", "XX.", "X..", "X.."],
	"Q": [".X.", "X.X", "X.X", "XX.", ".XX"],
	"R": ["XX.", "X.X", "XX.", "X.X", "X.X"],
	"S": [".XX", "X..", ".X.", "..X", "XX."],
	"T": ["XXX", ".X.", ".X.", ".X.", ".X."],
	"U": ["X.X", "X.X", "X.X", "X.X", "XXX"],
	"V": ["X.X", "X.X", "X.X", "X.X", ".X."],
	"W": ["X.X", "X.X", "XXX", "XXX", "X.X"],
	"X": ["X.X", "X.X", ".X.", "X.X", "X.X"],
	"Y": ["X.X", "X.X", ".X.", ".X.", ".X."],
	"Z": ["XXX", "..X", ".X.", "X..", "XXX"],
	"0": ["XXX", "X.X", "X.X", "X.X", "XXX"],
	"1": [".X.", "XX.", ".X.", ".X.", "XXX"],
	"2": ["XX.", "..X", ".X.", "X..", "XXX"],
	"3": ["XX.", "..X", ".X.", "..X", "XX."],
	"4": ["X.X", "X.X", "XXX", "..X", "..X"],
	"5": ["XXX", "X..", "XX.", "..X", "XX."],
	"6": [".XX", "X..", "XXX", "X.X", "XXX"],
	"7": ["XXX", "..X", ".X.", ".X.", ".X."],
	"8": ["XXX", "X.X", "XXX", "X.X", "XXX"],
	"9": ["XXX", "X.X", "XXX", "..X", "XX."],
	":": ["...", ".X.", "...", ".X.", "..."],
	".": ["...", "...", "...", "...", ".X."],
	"-": ["...", "...", "XXX", "...", "..."],
	"!": [".X.", ".X.", ".X.", "...", ".X."],
	"+": ["...", ".X.", "XXX", ".X.", "..."],
}

# Drogi (osiowo wyrównane prostokąty, szerokość 40) – obwodnica + dwie ulice środkowe.
var roads: Array[Rect2] = [
	Rect2(0, 0, 1200, 40),
	Rect2(0, 760, 1200, 40),
	Rect2(0, 0, 40, 800),
	Rect2(1160, 0, 40, 800),
	Rect2(0, 380, 1200, 40),
	Rect2(580, 0, 40, 800),
]

# Przystanki w kolejności odwiedzania.
var stops: Array[Rect2] = [
	Rect2(270, 6, 60, 28),
	Rect2(1166, 170, 28, 60),
	Rect2(880, 386, 60, 28),
	Rect2(300, 766, 60, 28),
	Rect2(6, 500, 28, 60),
]
var stop_names: Array[String] = ["DWORZEC", "RYNEK", "SZPITAL", "PORT", "OSIEDLE"]

var bus_pos := Vector2(120, 20)
var angle: float = 0.0
var speed: float = 0.0
var state: State = State.WAIT
var time_left: float = START_TIME
var money: int = 0
var stops_done: int = 0
var next_stop: int = 0
var stop_timer: float = 0.0
var last_pax: int = 0
var msg_timer: float = 0.0
var over_time: float = 0.0
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()
	RenderingServer.set_default_clear_color(Color("#101418"))
	reset()


func reset() -> void:
	bus_pos = Vector2(120, 20)
	angle = 0.0
	speed = 0.0
	state = State.WAIT
	time_left = START_TIME
	money = 0
	stops_done = 0
	next_stop = 0
	stop_timer = 0.0
	last_pax = 0
	msg_timer = 0.0
	over_time = 0.0


func key(a: Key, b: Key) -> bool:
	return Input.is_key_pressed(a) or Input.is_key_pressed(b)


func is_on_road(p: Vector2) -> bool:
	for r in roads:
		if r.has_point(p):
			return true
	return false


func _process(delta: float) -> void:
	var up := key(KEY_UP, KEY_W)
	var down := key(KEY_DOWN, KEY_S)
	var steer := 0.0
	if key(KEY_RIGHT, KEY_D):
		steer += 1.0
	if key(KEY_LEFT, KEY_A):
		steer -= 1.0

	if state == State.OVER:
		up = false
		down = false
		steer = 0.0
		over_time += delta
		if over_time > 1.0 and (key(KEY_ENTER, KEY_SPACE) or Input.is_key_pressed(KEY_R)):
			reset()
			return
	elif state == State.WAIT and (up or down):
		state = State.PLAY

	# fizyka autobusu
	var max_here := MAX_SPEED if is_on_road(bus_pos) else GRASS_SPEED
	if up:
		speed += ACCEL * delta
	elif down:
		if speed > 0.0:
			speed -= BRAKE * delta
		else:
			speed -= ACCEL * 0.6 * delta
	else:
		speed = move_toward(speed, 0.0, FRICTION * delta)
	if speed > max_here:
		speed = move_toward(speed, max_here, 250.0 * delta)
	speed = maxf(speed, -REVERSE_SPEED)
	angle += steer * TURN_RATE * clampf(speed / 50.0, -1.0, 1.0) * delta
	bus_pos += Vector2.from_angle(angle) * speed * delta
	bus_pos = bus_pos.clamp(Vector2(-100.0, -100.0), Vector2(1300.0, 900.0))

	# czas i przystanki
	if state == State.PLAY:
		time_left -= delta
		if time_left <= 0.0:
			time_left = 0.0
			state = State.OVER
			over_time = 0.0
		else:
			update_stop(delta)
	msg_timer = maxf(0.0, msg_timer - delta)
	queue_redraw()


func update_stop(delta: float) -> void:
	var zone := stops[next_stop]
	if zone.has_point(bus_pos) and absf(speed) < 10.0:
		stop_timer += delta
		if stop_timer >= STOP_TIME:
			var pax := rng.randi_range(3, 9)
			last_pax = pax
			money += pax * 4
			time_left += BONUS_TIME
			stops_done += 1
			msg_timer = 2.0
			next_stop = (next_stop + 1) % stops.size()
			stop_timer = 0.0
	else:
		stop_timer = 0.0


# ---------------------------------------------------------------- rysowanie

func _draw() -> void:
	var origin := (Vector2(VIEW_W, VIEW_H) * 0.5 - bus_pos).round()
	var screen := Rect2(0.0, 0.0, VIEW_W, VIEW_H)

	# trawa
	draw_rect(screen, Color("#3d7a3a"))
	var gx0 := floori(-origin.x / 16.0)
	var gy0 := floori(-origin.y / 16.0)
	for gx in range(gx0, gx0 + 22):
		for gy in range(gy0, gy0 + 13):
			var h := absi((gx * 73856093) ^ (gy * 19349663))
			if h % 3 == 0:
				var tx := gx * 16 + (h >> 4) % 13 + int(origin.x)
				var ty := gy * 16 + (h >> 9) % 13 + int(origin.y)
				draw_rect(Rect2(tx, ty, 2, 2), Color("#2f6a2f"))

	# drogi: krawężnik, asfalt, linie
	for r in roads:
		var cr := Rect2(r.position + origin, r.size).grow(2.0)
		if cr.intersects(screen):
			draw_rect(cr, Color("#8d8d8d"))
	for r in roads:
		var ar := Rect2(r.position + origin, r.size)
		if ar.intersects(screen):
			draw_rect(ar, Color("#3b3b42"))
	for r in roads:
		var dr := Rect2(r.position + origin, r.size)
		if dr.intersects(screen):
			draw_dashes(r, origin)

	# przystanki
	for i in stops.size():
		var zr := Rect2(stops[i].position + origin, stops[i].size)
		if not zr.intersects(screen):
			continue
		var active := (i == next_stop)
		var zc := Color("#f1c40f") if active else Color("#7f8c8d")
		draw_rect(zr, Color(zc.r, zc.g, zc.b, 0.35 if active else 0.2))
		draw_rect(zr, zc, false, 1.0)
		if active:
			shadow_text(stop_names[i], zr.position.x, zr.position.y - 8.0, Color.WHITE)

	# autobus
	draw_set_transform(origin + bus_pos, angle, Vector2.ONE)
	draw_rect(Rect2(-14.0, -6.5, 28.0, 13.0), Color("#2b2110"))
	draw_rect(Rect2(-13.0, -5.5, 26.0, 11.0), Color("#e8b923"))
	draw_rect(Rect2(-10.0, -4.0, 16.0, 8.0), Color("#f6d55c"))
	draw_rect(Rect2(8.0, -4.5, 4.0, 9.0), Color("#3a5f8f"))
	draw_rect(Rect2(-13.0, -4.5, 1.0, 2.0), Color("#e74c3c"))
	draw_rect(Rect2(-13.0, 2.5, 1.0, 2.0), Color("#e74c3c"))
	draw_rect(Rect2(12.0, -4.5, 1.0, 2.0), Color("#ffffff"))
	draw_rect(Rect2(12.0, 2.5, 1.0, 2.0), Color("#ffffff"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# strzałka do następnego przystanku
	if state != State.OVER:
		var to_stop := stops[next_stop].get_center() - bus_pos
		if to_stop.length() > 100.0:
			var d := to_stop.normalized()
			var p := Vector2(VIEW_W, VIEW_H) * 0.5 + d * 60.0
			var n := Vector2(-d.y, d.x)
			var tri := PackedVector2Array([p + d * 7.0, p - d * 4.0 + n * 5.0, p - d * 4.0 - n * 5.0])
			draw_colored_polygon(tri, Color("#f1c40f"))

	draw_hud()


func draw_dashes(r: Rect2, origin: Vector2) -> void:
	var col := Color("#d8d8c0")
	if r.size.x > r.size.y:
		var y := r.position.y + r.size.y * 0.5 - 1.0 + origin.y
		if y > -2.0 and y < VIEW_H + 2.0:
			var x := r.position.x + 8.0
			while x < r.end.x - 8.0:
				var sx := x + origin.x
				if sx > -10.0 and sx < VIEW_W + 10.0:
					draw_rect(Rect2(sx, y, 8.0, 2.0), col)
				x += 16.0
	else:
		var x2 := r.position.x + r.size.x * 0.5 - 1.0 + origin.x
		if x2 > -2.0 and x2 < VIEW_W + 2.0:
			var y2 := r.position.y + 8.0
			while y2 < r.end.y - 8.0:
				var sy := y2 + origin.y
				if sy > -10.0 and sy < VIEW_H + 10.0:
					draw_rect(Rect2(x2, sy, 2.0, 8.0), col)
				y2 += 16.0


func draw_hud() -> void:
	var yellow := Color("#f1c40f")
	shadow_text("CZAS " + str(ceili(time_left)), 4.0, 4.0, Color.WHITE)
	shadow_text("ZL " + str(money), 4.0, 12.0, yellow)
	shadow_text("KMH " + str(int(absf(speed) * 0.5)), VIEW_W - 40.0, 4.0, Color.WHITE)
	shadow_text("PRZYSTANEK: " + stop_names[next_stop], 4.0, VIEW_H - 10.0, Color.WHITE)

	if state == State.WAIT:
		center_text("AUTOBUS", 40.0, yellow, 3.0)
		center_text("STRZALKI LUB WASD", 70.0, Color.WHITE)
		center_text("DOJEDZ NA ZOLTY PRZYSTANEK I ZATRZYMAJ SIE", 82.0, Color.WHITE)
		center_text("TRAWA - WOLNIEJ. KAZDY PRZYSTANEK +15 S", 94.0, Color.WHITE)
	elif state == State.PLAY:
		if stop_timer > 0.0:
			center_text("WSIADAJA PASAZEROWIE", 130.0, Color.WHITE)
			draw_rect(Rect2(110.0, 140.0, 100.0, 6.0), Color(0, 0, 0, 0.7))
			draw_rect(Rect2(110.0, 140.0, 100.0 * clampf(stop_timer / STOP_TIME, 0.0, 1.0), 6.0), yellow)
		if msg_timer > 0.0:
			center_text("+%d PAX  +%d ZL  +15 S" % [last_pax, last_pax * 4], 50.0, yellow)
	else:
		center_text("KONIEC KURSU", 50.0, Color("#ff6b5b"), 2.0)
		center_text("ZAROBEK: %d ZL" % money, 80.0, yellow)
		center_text("PRZYSTANKI: %d" % stops_done, 92.0, Color.WHITE)
		if over_time > 1.0:
			center_text("ENTER - NOWA GRA", 116.0, Color.WHITE)


# Rysowanie tekstu pikselowym fontem 3x5.
func ptext(s: String, x: float, y: float, col: Color, sc: float = 1.0) -> void:
	var cx := x
	for ch in s.to_upper():
		if FONT.has(ch):
			var g: Array = FONT[ch]
			for row in 5:
				var line: String = g[row]
				for ci in 3:
					if line[ci] == "X":
						draw_rect(Rect2(cx + ci * sc, y + row * sc, sc, sc), col)
		cx += 4.0 * sc


func shadow_text(s: String, x: float, y: float, col: Color, sc: float = 1.0) -> void:
	ptext(s, x + sc, y + sc, Color(0, 0, 0, 0.8), sc)
	ptext(s, x, y, col, sc)


func center_text(s: String, y: float, col: Color, sc: float = 1.0) -> void:
	var w := s.length() * 4.0 * sc - sc
	shadow_text(s, floorf((VIEW_W - w) * 0.5), y, col, sc)
