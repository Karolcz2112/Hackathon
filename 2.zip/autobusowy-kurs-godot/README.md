# Autobusowy kurs — Godot 4

## Uruchomienie
1. Zainstaluj Godot 4.
2. Wybierz **Importuj** i wskaż `project.godot` w tym folderze.
3. Otwórz projekt i uruchom klawiszem **F5**.

## Sterowanie
- **← / →** lub **A / D** — kierowanie autobusem
- **↑ / ↓** lub **W / S** — przyspieszanie i hamowanie
- **Mysz albo palec** — przeciąganie autobusu
- **Spacja** lub kliknięcie — rozpoczęcie albo ponowne rozpoczęcie kursu

Omijaj auta, zbieraj pasażerów oznaczonych literą **P** i dowieź pięć osób. Trzy kolizje kończą kurs.

## Assety
Na razie nie musisz dodawać żadnych assetów. Autobus, samochody, droga, drzewa i przystanki są rysowane w skrypcie. Jeśli zechcesz, możesz później dodać własne sprite'y autobusu, aut, tła oraz dźwięki silnika i przystanku.
