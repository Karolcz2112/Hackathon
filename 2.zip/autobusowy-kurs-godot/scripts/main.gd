extends Node2D

## Autobusowy kurs: top-down driving prototype drawn entirely in GDScript.
const BUS_SIZE := Vector2(42.0, 76.0)
const STEER_SPEED := 330.0
const GOAL_STOPS := 5
const MAX_LIVES := 3

var rng := RandomNumberGenerator.new()
var font: Font
var view_size := Vector2(960, 600)
var road_left := 180.0
var road_right := 780.0
var bus_pos := Vector2(480, 455)
var objects: Array[Dictionary] = []
var scenery: Array[Dictionary] = []
var running := false
var ended := false
var won := false
var pointer_down := false
var pointer_target := Vector2.ZERO
var speed := 260.0
var distance := 0.0
var spawn_clock := 0.0
var road_offset := 0.0
var passengers := 0
var lives := MAX_LIVES
var best_stops := 0

func _ready() -> void:
	rng.randomize()
	font = ThemeDB.fallback_font
	var save := ConfigFile.new()
	if save.load("user://bus_route.cfg") == OK:
		best_stops = int(save.get_value("game", "best_stops", 0))
	get_viewport().size_changed.connect(_on_viewport_size_changed)
	_update_layout()
	_reset_scenery()
	queue_redraw()

func _on_viewport_size_changed() -> void:
	_update_layout()
	_reset_scenery()
	queue_redraw()

func _update_layout() -> void:
	view_size = get_viewport_rect().size
	var road_width := minf(view_size.x * 0.68, 610.0)
	road_left = (view_size.x - road_width) * 0.5
	road_right = road_left + road_width
	bus_pos.x = clampf(bus_pos.x, road_left + 45.0, road_right - 45.0)
	bus_pos.y = clampf(bus_pos.y, view_size.y * 0.48, view_size.y - 85.0)

func _reset_scenery() -> void:
	scenery.clear()
	for i in 13:
		for side in [-1, 1]:
			var x := road_left - rng.randf_range(35.0, 145.0) if side < 0 else road_right + rng.randf_range(35.0, 145.0)
			scenery.append({"x": x, "y": float(i) * 100.0 - 40.0, "size": rng.randf_range(24.0, 55.0), "color": [Color("#496e4b"), Color("#587c50"), Color("#68764c")][rng.randi_range(0, 2)]})

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_ENTER:
			if not running:
				_start_game()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if not running:
				_start_game()
			pointer_down = true
			pointer_target = event.position
		else:
			pointer_down = false
	elif event is InputEventMouseMotion and pointer_down:
		pointer_target = event.position
	elif event is InputEventScreenTouch:
		if event.pressed:
			if not running:
				_start_game()
			pointer_down = true
			pointer_target = event.position
		else:
			pointer_down = false
	elif event is InputEventScreenDrag:
		pointer_down = true
		pointer_target = event.position

func _start_game() -> void:
	objects.clear()
	passengers = 0
	lives = MAX_LIVES
	distance = 0.0
	speed = 260.0
	spawn_clock = 0.0
	bus_pos = Vector2(view_size.x * 0.5, view_size.y * 0.76)
	running = true
	ended = false
	won = false
	queue_redraw()

func _finish(victory: bool) -> void:
	running = false
	ended = true
	won = victory
	if passengers > best_stops:
		best_stops = passengers
		var save := ConfigFile.new()
		save.set_value("game", "best_stops", best_stops)
		save.save("user://bus_route.cfg")

func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	if running:
		var throttle := Input.get_axis("ui_down", "ui_up")
		speed = clampf(speed + throttle * 240.0 * dt, 100.0, 440.0)
		var steer := Vector2(Input.get_axis("ui_left", "ui_right"), Input.get_axis("ui_up", "ui_down"))
		if Input.is_key_pressed(KEY_A): steer.x = -1.0
		elif Input.is_key_pressed(KEY_D): steer.x = 1.0
		if Input.is_key_pressed(KEY_W): steer.y = -1.0
		elif Input.is_key_pressed(KEY_S): steer.y = 1.0
		if pointer_down:
			bus_pos = bus_pos.move_toward(pointer_target, STEER_SPEED * dt)
		else:
			bus_pos += steer * STEER_SPEED * dt
		bus_pos.x = clampf(bus_pos.x, road_left + BUS_SIZE.x * 0.65, road_right - BUS_SIZE.x * 0.65)
		bus_pos.y = clampf(bus_pos.y, view_size.y * 0.40, view_size.y - 72.0)
		distance += speed * dt / 12.0
		road_offset = fposmod(road_offset + speed * dt, 110.0)
		spawn_clock += dt
		if spawn_clock >= maxf(0.48, 1.12 - speed / 1000.0):
			spawn_clock = 0.0
			_spawn_object()
		_update_objects(dt)
		_update_scenery(dt)
	queue_redraw()

func _spawn_object() -> void:
	var lane_count := 3
	var lane_width := (road_right - road_left) / lane_count
	var lane := rng.randi_range(0, lane_count - 1)
	var kind := "car" if rng.randf() < 0.69 else "stop"
	objects.append({"x": road_left + lane_width * (lane + 0.5), "y": -80.0, "kind": kind, "color": [Color("#e76f51"), Color("#e9c46a"), Color("#7c8cde"), Color("#f4f1de")][rng.randi_range(0, 3)], "passed": false})

func _update_objects(dt: float) -> void:
	for i in range(objects.size() - 1, -1, -1):
		var obj := objects[i]
		obj["y"] = float(obj["y"]) + speed * dt
		var obj_pos := Vector2(float(obj["x"]), float(obj["y"]))
		if bus_pos.distance_to(obj_pos) < (34.0 if obj["kind"] == "stop" else 43.0):
			if obj["kind"] == "stop":
				passengers += 1
				objects.remove_at(i)
				if passengers >= GOAL_STOPS:
					_finish(true)
					return
			else:
				lives -= 1
				objects.remove_at(i)
				if lives <= 0:
					_finish(false)
					return
		elif float(obj["y"]) > view_size.y + 90.0:
			objects.remove_at(i)

func _update_scenery(dt: float) -> void:
	for piece in scenery:
		piece["y"] = float(piece["y"]) + speed * dt
		if float(piece["y"]) > view_size.y + 80.0:
			piece["y"] = -80.0 - rng.randf_range(0.0, 120.0)

func _draw() -> void:
	_draw_world()
	if running:
		for obj in objects:
			if obj["kind"] == "car": _draw_car(Vector2(float(obj["x"]), float(obj["y"])), obj["color"], false)
			else: _draw_stop(Vector2(float(obj["x"]), float(obj["y"])))
		_draw_bus(bus_pos)
		_draw_hud()
	else:
		_draw_menu()

func _draw_world() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color("#58784c"))
	for piece in scenery:
		var p := Vector2(float(piece["x"]), float(piece["y"]))
		draw_rect(Rect2(p - Vector2(20, 18), Vector2(40, 36)), Color(0.1, 0.16, 0.1, 0.17))
		draw_circle(p, float(piece["size"]) * 0.5, piece["color"])
		draw_circle(p + Vector2(-7, -5), float(piece["size"]) * 0.22, Color("#85a85b"))
	draw_rect(Rect2(road_left - 18, 0, (road_right - road_left) + 36, view_size.y), Color("#c3b99b"))
	draw_rect(Rect2(road_left, 0, road_right - road_left, view_size.y), Color("#343943"))
	draw_rect(Rect2(road_left + 8, 0, 5, view_size.y), Color("#eee4c8"))
	draw_rect(Rect2(road_right - 13, 0, 5, view_size.y), Color("#eee4c8"))
	var lane_width := (road_right - road_left) / 3.0
	for lane in [1, 2]:
		var x := road_left + lane_width * lane
		var y := -110.0 + road_offset
		while y < view_size.y:
			draw_rect(Rect2(x - 2, y, 4, 52), Color("#c7c9c8"))
			y += 110.0
	for piece in scenery:
		var sign_pos := Vector2(road_left - 10 if float(piece["x"]) < road_left else road_right + 10, float(piece["y"]))
		draw_line(sign_pos + Vector2(0, -11), sign_pos + Vector2(0, 11), Color("#ded8c6"), 3.0)
		draw_circle(sign_pos + Vector2(0, -7), 5, Color("#fff0c9"))

func _draw_bus(pos: Vector2) -> void:
	_draw_car(pos, Color("#f4d35e"), true)
	draw_rect(Rect2(pos + Vector2(-14, -25), Vector2(28, 30)), Color("#d6edf2"), true, 4.0)
	_draw_text("BUS", pos + Vector2(-11, 8), 10, Color("#333943"))

func _draw_car(pos: Vector2, body: Color, is_bus: bool) -> void:
	var half := BUS_SIZE * (0.5 if is_bus else 0.37)
	var rect := Rect2(pos - half, half * 2)
	draw_rect(rect.grow(2), Color(0, 0, 0, 0.3), true, 8.0)
	draw_rect(rect, body, true, 8.0)
	var window_h := 28.0 if is_bus else 17.0
	draw_rect(Rect2(pos.x - half.x + 5, pos.y - half.y + 8, half.x * 2 - 10, window_h), Color("#b8d7de"), true, 4.0)
	draw_rect(Rect2(pos.x - half.x + 5, pos.y + half.y - 14, half.x * 2 - 10, 6), Color("#f7f0d5"), true, 2.0)
	for side in [-1.0, 1.0]:
		draw_rect(Rect2(pos.x + side * (half.x - 2) - 3, pos.y - half.y + 12, 6, 13), Color("#242831"), true, 2.0)
		draw_rect(Rect2(pos.x + side * (half.x - 2) - 3, pos.y + half.y - 25, 6, 13), Color("#242831"), true, 2.0)

func _draw_stop(pos: Vector2) -> void:
	draw_circle(pos, 21, Color(0.14, 0.78, 0.93, 0.2))
	draw_rect(Rect2(pos.x - 2, pos.y - 17, 4, 34), Color("#e8edf2"))
	draw_rect(Rect2(pos.x - 13, pos.y - 18, 26, 15), Color("#2a9d8f"), true, 4.0)
	_draw_text("P", pos + Vector2(-5, -6), 12, Color.WHITE)

func _draw_hud() -> void:
	draw_rect(Rect2(14, 14, view_size.x - 28, 58), Color(0.04, 0.06, 0.08, 0.82), true, 14.0)
	_draw_text("PRĘDKOŚĆ", Vector2(30, 37), 12, Color("#bfc7cf"))
	_draw_text("%d km/h" % int(speed), Vector2(30, 59), 19, Color.WHITE)
	_draw_text("PRZYSTANKI  %d / %d" % [passengers, GOAL_STOPS], Vector2(view_size.x * 0.43, 51), 18, Color("#ffe082"))
	var hearts := "♥  ".repeat(lives) + "♡  ".repeat(MAX_LIVES - lives)
	_draw_text(hearts, Vector2(view_size.x - 130, 52), 20, Color("#ff8a80"))
	var bar_w := 150.0
	draw_rect(Rect2(view_size.x - bar_w - 28, 59, bar_w, 5), Color("#6d7479"), true, 3.0)
	draw_rect(Rect2(view_size.x - bar_w - 28, 59, bar_w * speed / 440.0, 5), Color("#65d6ad"), true, 3.0)

func _draw_menu() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color(0.02, 0.04, 0.04, 0.72))
	var cx := view_size.x * 0.5
	_draw_text("MIEJSKA LINIA  •  GODOT 4", Vector2(cx - 142, view_size.y * 0.31), 15, Color("#8ee3c0"))
	_draw_text("AUTOBUSOWY KURS", Vector2(cx - 229, view_size.y * 0.42), 36, Color("#fff5d6"))
	if ended:
		_draw_text("KURS ZAKOŃCZONY!" if won else "KONIEC KURSU", Vector2(cx - 115, view_size.y * 0.51), 20, Color("#ffe082"))
	else:
		_draw_text("Zawieź pasażerów bezpiecznie do celu", Vector2(cx - 211, view_size.y * 0.52), 18, Color("#e0e7dd"))
	_draw_text("← → / A D: kieruj     ↑ ↓ / W S: gaz i hamulec", Vector2(cx - 237, view_size.y * 0.60), 15, Color("#c5d0c6"))
	_draw_text("Mysz lub palec: przeciągnij autobus", Vector2(cx - 155, view_size.y * 0.65), 15, Color("#c5d0c6"))
	_draw_text("ZBIERZ 5 PASAŻERÓW  •  REKORD: %d" % best_stops, Vector2(cx - 178, view_size.y * 0.71), 16, Color("#ffe082"))
	_draw_text("KLIKNIJ LUB NACIŚNIJ SPACJĘ, ABY RUSZYĆ", Vector2(cx - 205, view_size.y * 0.79), 15, Color("#8ee3c0"))

func _draw_text(text: String, pos: Vector2, size: int, color: Color) -> void:
	if font:
		draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
