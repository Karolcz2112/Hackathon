extends Node2D
## Prototyp: autobus 2D, widok z góry, wygląd pixel-art (320x180). Zero zewnętrznych assetów.
## Sterowanie: strzałki lub WASD. Cel: dojeżdżaj na kolejne żółte przystanki i zatrzymuj się.

const VIEW_W := 320.0
const VIEW_H := 180.0
const MAX_SPEED := 140.0
const GRASS_SPEED := 50.0
const REVERSE_SPEED := 35.0
const ACCEL := 90.0
const BRAKE := 200.0
const FRICTION := 45.0
const TURN_RATE := 2.2
const START_TIME := 60.0
const STOP_TIME := 1.2
const BONUS_TIME := 15.0

enum State { MENU, WAIT, PLAY, UPGRADES, OVER }

# Pikselowa czcionka 3x5 (tylko wielkie litery ASCII, cyfry i kilka znaków).
const FONT = {
	"A": [".X.", "X.X", "XXX", "X.X", "X.X"],
	"B": ["XX.", "X.X", "XX.", "X.X", "XX."],
	"C": [".XX", "X..", "X..", "X..", ".XX"],
	"D": ["XX.", "X.X", "X.X", "X.X", "XX."],
	"E": ["XXX", "X..", "XX.", "X..", "XXX"],
	"F": ["XXX", "X..", "XX.", "X..", "X.."],
	"G": [".XX", "X..", "X.X", "X.X", ".XX"],
	"H": ["X.X", "X.X", "XXX", "X.X", "X.X"],
	"I": ["XXX", ".X.", ".X.", ".X.", "XXX"],
	"J": ["..X", "..X", "..X", "X.X", ".X."],
	"K": ["X.X", "X.X", "XX.", "X.X", "X.X"],
	"L": ["X..", "X..", "X..", "X..", "XXX"],
	"M": ["X.X", "XXX", "XXX", "X.X", "X.X"],
	"N": ["XXX", "X.X", "X.X", "X.X", "X.X"],
	"O": [".X.", "X.X", "X.X", "X.X", ".X."],
	"P": ["XX.", "X.X", "XX.", "X..", "X.."],
	"Q": [".X.", "X.X", "X.X", "XX.", ".XX"],
	"R": ["XX.", "X.X", "XX.", "X.X", "X.X"],
	"S": [".XX", "X..", ".X.", "..X", "XX."],
	"T": ["XXX", ".X.", ".X.", ".X.", ".X."],
	"U": ["X.X", "X.X", "X.X", "X.X", "XXX"],
	"V": ["X.X", "X.X", "X.X", "X.X", ".X."],
	"W": ["X.X", "X.X", "XXX", "XXX", "X.X"],
	"X": ["X.X", "X.X", ".X.", "X.X", "X.X"],
	"Y": ["X.X", "X.X", ".X.", ".X.", ".X."],
	"Z": ["XXX", "..X", ".X.", "X..", "XXX"],
	"0": ["XXX", "X.X", "X.X", "X.X", "XXX"],
	"1": [".X.", "XX.", ".X.", ".X.", "XXX"],
	"2": ["XX.", "..X", ".X.", "X..", "XXX"],
	"3": ["XX.", "..X", ".X.", "..X", "XX."],
	"4": ["X.X", "X.X", "XXX", "..X", "..X"],
	"5": ["XXX", "X..", "XX.", "..X", "XX."],
	"6": [".XX", "X..", "XXX", "X.X", "XXX"],
	"7": ["XXX", "..X", ".X.", ".X.", ".X."],
	"8": ["XXX", "X.X", "XXX", "X.X", "XXX"],
	"9": ["XXX", "X.X", "XXX", "..X", "XX."],
	":": ["...", ".X.", "...", ".X.", "..."],
	".": ["...", "...", "...", "...", ".X."],
	"-": ["...", "...", "XXX", "...", "..."],
	"!": [".X.", ".X.", ".X.", "...", ".X."],
	"+": ["...", ".X.", "XXX", ".X.", "..."],
}

# Drogi (osiowo wyrównane prostokąty, szerokość 40) – obwodnica + dwie ulice środkowe.
var roads: Array[Rect2] = [
	Rect2(0, 0, 1200, 40),
	Rect2(0, 760, 1200, 40),
	Rect2(0, 0, 40, 800),
	Rect2(1160, 0, 40, 800),
	Rect2(0, 380, 1200, 40),
	Rect2(580, 0, 40, 800),
	# Local connector streets between city blocks.
	Rect2(40, 170, 220, 24), Rect2(360, 170, 220, 24), Rect2(620, 170, 540, 24),
	Rect2(40, 560, 1120, 24),
]

# Przystanki w kolejności odwiedzania.
var stops: Array[Rect2] = [
	Rect2(270, 6, 60, 28), Rect2(1166, 170, 28, 60),
	Rect2(880, 386, 60, 28), Rect2(300, 766, 60, 28),
	Rect2(6, 500, 28, 60), Rect2(420, 6, 60, 28),
	Rect2(6, 220, 28, 60), Rect2(720, 386, 60, 28),
	Rect2(760, 766, 60, 28), Rect2(1166, 570, 28, 60),
	Rect2(6, 100, 28, 60), Rect2(900, 6, 60, 28),
]
var stop_names: Array[String] = [
	"DWORZEC", "RYNEK", "PALMIARNIA", "RADIOSTACJA", "ARENA",
	"PLAC PIASTOW", "SZPITAL", "OSIEDLE", "ZATORZE", "GLIWICE WSCHOD",
	"POLITECHNIKA", "CENTRUM",
]

# Budynki i samochody w świecie gry. Prostokąty służą również do kolizji.
var buildings: Array[Rect2] = [
	Rect2(65, 65, 42, 30), Rect2(145, 65, 48, 34),
	Rect2(220, 65, 38, 28), Rect2(330, 65, 52, 34),
	Rect2(420, 65, 42, 30), Rect2(490, 65, 50, 32),
	Rect2(635, 65, 42, 30), Rect2(720, 65, 54, 34),
	Rect2(820, 65, 44, 30), Rect2(930, 65, 52, 34),
	Rect2(1030, 65, 44, 30), Rect2(1080, 65, 48, 32),
	Rect2(65, 285, 44, 34), Rect2(145, 285, 52, 30),
	Rect2(235, 285, 40, 34), Rect2(330, 285, 50, 30),
	Rect2(420, 285, 44, 34), Rect2(490, 285, 48, 30),
	Rect2(635, 285, 46, 32), Rect2(735, 285, 50, 34),
	Rect2(830, 285, 42, 30), Rect2(940, 285, 50, 34),
	Rect2(1035, 285, 42, 30), Rect2(1080, 285, 48, 34),
	Rect2(65, 445, 48, 30), Rect2(155, 445, 42, 34),
	Rect2(245, 445, 50, 30), Rect2(335, 445, 44, 34),
	Rect2(420, 445, 50, 30), Rect2(490, 445, 42, 34),
	Rect2(635, 445, 50, 30), Rect2(735, 445, 44, 34),
	Rect2(835, 445, 50, 30), Rect2(940, 445, 42, 34),
	Rect2(1035, 445, 50, 30), Rect2(1085, 445, 42, 34),
	Rect2(65, 625, 50, 30), Rect2(155, 625, 44, 34),
	Rect2(245, 625, 50, 30), Rect2(335, 625, 42, 34),
	Rect2(420, 625, 50, 30), Rect2(490, 625, 44, 34),
	Rect2(635, 625, 50, 30), Rect2(735, 625, 42, 34),
	Rect2(835, 625, 50, 30), Rect2(940, 625, 44, 34),
	Rect2(1035, 625, 50, 30), Rect2(1085, 625, 42, 34),
	# Dodatkowe kwartały zabudowy: małe kamienice, większe bloki i budynki usługowe.
	Rect2(75, 115, 32, 24), Rect2(120, 125, 58, 38), Rect2(210, 118, 36, 26),
	Rect2(290, 110, 46, 40), Rect2(360, 125, 34, 24), Rect2(445, 115, 60, 38),
	Rect2(665, 115, 34, 26), Rect2(775, 120, 40, 28), Rect2(865, 112, 62, 40),
	Rect2(965, 120, 34, 24), Rect2(1050, 120, 48, 38),
	Rect2(75, 220, 56, 38), Rect2(165, 220, 34, 25), Rect2(255, 215, 60, 42),
	Rect2(350, 225, 36, 26), Rect2(440, 218, 44, 32), Rect2(505, 220, 34, 24),
	Rect2(665, 220, 56, 38), Rect2(765, 215, 34, 26), Rect2(855, 220, 48, 34),
	Rect2(960, 215, 58, 40), Rect2(1060, 220, 34, 24),
	Rect2(75, 505, 34, 24), Rect2(130, 510, 62, 40), Rect2(220, 505, 42, 30),
	Rect2(310, 510, 34, 25), Rect2(390, 505, 58, 38), Rect2(470, 510, 34, 24),
	Rect2(660, 505, 44, 32), Rect2(755, 510, 60, 40), Rect2(855, 505, 34, 25),
	Rect2(955, 510, 44, 32), Rect2(1060, 505, 58, 38),
	Rect2(75, 685, 58, 38), Rect2(175, 685, 34, 25), Rect2(265, 680, 44, 32),
	Rect2(355, 685, 60, 40), Rect2(455, 680, 34, 24), Rect2(665, 685, 58, 38),
	Rect2(765, 680, 34, 24), Rect2(855, 685, 44, 32), Rect2(955, 680, 60, 40),
]
# Samochody jako prostokąty w układzie świata; można w nie uderzyć.
var cars: Array[Dictionary] = [
	{"pos": Vector2(190, 10), "angle": 0.0, "color": Color("#d94f45"), "axis": "x", "min": 55.0, "max": 550.0, "speed": 48.0},
	{"pos": Vector2(390, 30), "angle": PI, "color": Color("#4a9bd8"), "axis": "x", "min": 55.0, "max": 550.0, "speed": -36.0},
	{"pos": Vector2(760, 10), "angle": 0.0, "color": Color("#eeeeee"), "axis": "x", "min": 650.0, "max": 1135.0, "speed": 42.0},
	{"pos": Vector2(1010, 30), "angle": PI, "color": Color("#b76bd1"), "axis": "x", "min": 650.0, "max": 1135.0, "speed": -32.0},
	{"pos": Vector2(590, 210), "angle": PI / 2.0, "color": Color("#e67e22"), "axis": "y", "min": 55.0, "max": 745.0, "speed": 39.0},
	{"pos": Vector2(610, 520), "angle": -PI / 2.0, "color": Color("#45b878"), "axis": "y", "min": 55.0, "max": 745.0, "speed": -34.0},
	{"pos": Vector2(420, 390), "angle": PI, "color": Color("#d94f45"), "axis": "x", "min": 55.0, "max": 550.0, "speed": -43.0},
	{"pos": Vector2(820, 410), "angle": 0.0, "color": Color("#4a9bd8"), "axis": "x", "min": 650.0, "max": 1135.0, "speed": 37.0},
]
var collision_cooldown := 0.0
var initial_cars: Array[Dictionary] = []

# Wybór linii inspirowanych prawdziwą siatką ZTM/GZM w Gliwicach.
# Numery linii są prawdziwe; trasy w prototypie są uproszczone i nie są nawigacją 1:1.
var selected_line := 0
var custom_line_text := ""
var custom_line_editing := false
var custom_line_enter_block := false
var bus_scale := 1.0
var line_numbers: Array[String] = ["6", "32", "840", "A4"]
var line_destinations: Array[String] = ["GLIWICE CENTRUM", "SOŚNICA", "KATOWICE", "PORT LOTNICZY"]
var line_colors: Array[Color] = [Color("#f2c62f"), Color("#e9e9e7"), Color("#f0c52f"), Color("#41a8e0")]
var line_descriptions: Array[String] = ["MIASTO / RYNEK", "OSIEDLA / SZPITAL", "TRASA PODMIEJSKA", "SZYBKA LINIA A4"]
var particles: Array[Dictionary] = []
var fx_clock := 0.0
var exhaust_clock := 0.0
var stop_flash := 0.0
var bus_health := 100.0
var bus_invulnerability := 0.0
var wrecks: Array[Dictionary] = []
var crash_shake := 0.0
var menu_left_prev := false
var menu_right_prev := false
var menu_color_prev := false

const DAY_CYCLE_SECONDS := 100.0
const TRAFFIC_CYCLE_SECONDS := 12.0
var day_clock := 0.0
var daylight := 1.0
var traffic_clock := 0.0
var bus_color_index := 0
var bus_paint_colors: Array[Color] = [
	Color("#f2c62f"), Color("#2677c9"), Color("#d94f45"),
	Color("#319b68"), Color("#ece9df"), Color("#7647a5"),
	Color("#ef7d28"), Color("#252b32"),
]

var bus_pos := Vector2(120, 20)
var angle: float = 0.0
var speed: float = 0.0
var state: State = State.WAIT
var time_left: float = START_TIME
var money: int = 0
var stops_done: int = 0
var upgrades_taken: Array[String] = []
var upgrade_choices: Array[Dictionary] = []
var speed_upgrade := 1.0
var fare_upgrade := 0
var time_upgrade := 0.0
var health_upgrade := 0
var stop_duration := STOP_TIME
var next_stop: int = 0
var stop_timer: float = 0.0
var last_pax: int = 0
var msg_timer: float = 0.0
var over_time: float = 0.0
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.randomize()
	RenderingServer.set_default_clear_color(Color("#101418"))
	initial_cars = cars.duplicate(true)
	reset()


func _input(event: InputEvent) -> void:
	if state == State.UPGRADES and event is InputEventKey:
		var upgrade_key := event as InputEventKey
		if upgrade_key.pressed and not upgrade_key.echo:
			if upgrade_key.keycode == KEY_1:
				choose_upgrade(0)
			elif upgrade_key.keycode == KEY_2:
				choose_upgrade(1)
			elif upgrade_key.keycode == KEY_3:
				choose_upgrade(2)
			get_viewport().set_input_as_handled()
		return
	if state != State.MENU or not custom_line_editing or not (event is InputEventKey):
		return
	var key_event := event as InputEventKey
	if not key_event.pressed or key_event.echo:
		return
	if key_event.keycode == KEY_BACKSPACE:
		if custom_line_text.length() > 0:
			custom_line_text = custom_line_text.substr(0, custom_line_text.length() - 1)
		get_viewport().set_input_as_handled()
		queue_redraw()
		return
	if key_event.keycode == KEY_ESCAPE:
		custom_line_editing = false
		get_viewport().set_input_as_handled()
		queue_redraw()
		return
	if key_event.keycode == KEY_ENTER or key_event.keycode == KEY_KP_ENTER:
		custom_line_editing = false
		custom_line_enter_block = true
		get_viewport().set_input_as_handled()
		queue_redraw()
		return
	var typed := ""
	if key_event.unicode >= 32 and key_event.unicode <= 126:
		typed = String.chr(key_event.unicode).to_upper()
	if typed.length() > 0 and (typed.is_valid_int() or typed.to_upper() in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
		if custom_line_text.length() < 6:
			custom_line_text += typed
		get_viewport().set_input_as_handled()
		queue_redraw()


func reset() -> void:
	# Restore traffic after crashes/restarts; cars are removed when hit.
	cars = initial_cars.duplicate(true)
	bus_pos = Vector2(120, 20)
	angle = 0.0
	speed = 0.0
	state = State.MENU
	time_left = START_TIME
	money = 0
	stops_done = 0
	upgrades_taken.clear()
	upgrade_choices.clear()
	speed_upgrade = 1.0
	fare_upgrade = 0
	time_upgrade = 0.0
	health_upgrade = 0
	stop_duration = STOP_TIME
	next_stop = 0
	stop_timer = 0.0
	last_pax = 0
	msg_timer = 0.0
	over_time = 0.0
	collision_cooldown = 0.0
	particles.clear()
	fx_clock = 0.0
	exhaust_clock = 0.0
	stop_flash = 0.0
	bus_health = 100.0
	bus_invulnerability = 0.0
	day_clock = 0.0
	daylight = 1.0
	traffic_clock = 0.0
	wrecks.clear()
	crash_shake = 0.0


func key(a: Key, b: Key) -> bool:
	return Input.is_key_pressed(a) or Input.is_key_pressed(b)


func is_on_road(p: Vector2) -> bool:
	for r in roads:
		if r.has_point(p):
			return true
	return false


func speed_limit_at(p: Vector2) -> float:
	if not is_on_road(p):
		return GRASS_SPEED
	if p.y >= 170.0 and p.y <= 194.0 or p.y >= 560.0 and p.y <= 584.0:
		return 60.0
	if p.y < 40.0 or p.y >= 760.0:
		return 140.0
	return 100.0


func randomize_route() -> void:
	# Shuffle stops and their labels together so every run gets a different order.
	var route_pairs: Array[Dictionary] = []
	for i in range(stops.size()):
		route_pairs.append({"stop": stops[i], "name": stop_names[i]})
	route_pairs.shuffle()
	for i in range(route_pairs.size()):
		stops[i] = route_pairs[i]["stop"]
		stop_names[i] = route_pairs[i]["name"]


func apply_custom_line() -> void:
	var typed_line := custom_line_text.strip_edges().to_upper()
	if typed_line.is_empty():
		return
	var found := line_numbers.find(typed_line)
	if found >= 0:
		selected_line = found
	else:
		line_numbers.append(typed_line)
		line_destinations.append("WŁASNA TRASA")
		line_colors.append(Color("#62c6a5"))
		line_descriptions.append("WŁASNY NUMER LINII")
		selected_line = line_numbers.size() - 1


func _process(delta: float) -> void:
	day_clock = fmod(day_clock + delta, DAY_CYCLE_SECONDS)
	traffic_clock = fmod(traffic_clock + delta, TRAFFIC_CYCLE_SECONDS)
	daylight = (cos(day_clock / DAY_CYCLE_SECONDS * TAU) + 1.0) * 0.5
	# Ruch uliczny. Na głównym skrzyżowaniu auta pionowe respektują czerwone światło.
	var vertical_green := traffic_clock < TRAFFIC_CYCLE_SECONDS * 0.5
	for car in cars:
		var cp: Vector2 = car["pos"]
		var axis: String = car["axis"]
		var velocity: float = float(car["speed"])
		if axis == "x":
			cp.x += velocity * delta
			if cp.x < float(car["min"]):
				cp.x = float(car["min"])
				car["speed"] = absf(velocity)
			elif cp.x > float(car["max"]):
				cp.x = float(car["max"])
				car["speed"] = -absf(velocity)
			car["angle"] = 0.0 if float(car["speed"]) >= 0.0 else PI
		else:
			var red_at_crossing := not vertical_green and absf(cp.x - 600.0) < 30.0
			if red_at_crossing and cp.y >= 350.0 and cp.y <= 450.0:
				# Stop at the line, wait for green, then continue in the original direction.
				if velocity > 0.0:
					cp.y = 365.0
				else:
					cp.y = 435.0
			else:
				cp.y += velocity * delta
			if cp.y < float(car["min"]):
				cp.y = float(car["min"])
				car["speed"] = absf(velocity)
			elif cp.y > float(car["max"]):
				cp.y = float(car["max"])
				car["speed"] = -absf(velocity)
			car["angle"] = PI / 2.0 if float(car["speed"]) >= 0.0 else -PI / 2.0
		car["pos"] = cp

	var up := key(KEY_UP, KEY_W)
	var down := key(KEY_DOWN, KEY_S)
	var steer := 0.0
	if key(KEY_RIGHT, KEY_D):
		steer += 1.0
	if key(KEY_LEFT, KEY_A):
		steer -= 1.0

	fx_clock += delta
	stop_flash = maxf(0.0, stop_flash - delta)
	bus_invulnerability = maxf(0.0, bus_invulnerability - delta)
	crash_shake = maxf(0.0, crash_shake - delta)
	if state == State.MENU:
		# Wybór linii: strzałki lewo/prawo lub klawisze 1-3, Enter aby wyjechać.
		var left_now := Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A)
		var right_now := Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)
		if custom_line_enter_block:
			custom_line_enter_block = false
			queue_redraw()
			return
		if not custom_line_editing and left_now and not menu_left_prev:
			selected_line = (selected_line + line_numbers.size() - 1) % line_numbers.size()
		elif not custom_line_editing and right_now and not menu_right_prev:
			selected_line = (selected_line + 1) % line_numbers.size()
		elif not custom_line_editing and Input.is_key_pressed(KEY_1):
			selected_line = 0
		elif not custom_line_editing and Input.is_key_pressed(KEY_2):
			selected_line = 1
		elif not custom_line_editing and Input.is_key_pressed(KEY_3):
			selected_line = 2
		elif not custom_line_editing and Input.is_key_pressed(KEY_4):
			selected_line = 3
		elif not custom_line_editing and Input.is_key_pressed(KEY_C) and not menu_color_prev:
			bus_color_index = (bus_color_index + 1) % bus_paint_colors.size()
		elif not custom_line_editing and Input.is_key_pressed(KEY_L):
			custom_line_editing = true
			custom_line_text = ""
		elif not custom_line_editing and (key(KEY_ENTER, KEY_SPACE) or up):
			apply_custom_line()
			randomize_route()
			bus_scale = [0.78, 1.0, 1.22][rng.randi_range(0, 2)]
			state = State.WAIT
			bus_pos = Vector2(120, 20)
			speed = 0.0
			angle = 0.0
		menu_left_prev = left_now
		menu_right_prev = right_now
		menu_color_prev = Input.is_key_pressed(KEY_C)
		queue_redraw()
		return
	elif state == State.UPGRADES:
		queue_redraw()
		return
	elif state == State.OVER:
		up = false
		down = false
		steer = 0.0
		over_time += delta
		if over_time > 1.0 and (key(KEY_ENTER, KEY_SPACE) or Input.is_key_pressed(KEY_R)):
			reset()
			return
	elif state == State.WAIT and (up or down):
		state = State.PLAY

	# Freeze gameplay physics once the run is over (restart input is handled above).
	if state == State.OVER:
		queue_redraw()
		return

	# Exhaust puffs and tyre dust spawn in world coordinates; collisions emit sparks.
	if absf(speed) > 8.0 and state == State.PLAY:
		exhaust_clock += delta
		if exhaust_clock > 0.12:
			exhaust_clock = 0.0
			var rear := bus_pos - Vector2.from_angle(angle) * 15.0
			particles.append({"pos": rear, "vel": -Vector2.from_angle(angle) * rng.randf_range(8.0, 20.0) + Vector2(rng.randf_range(-5.0, 5.0), rng.randf_range(-5.0, 5.0)), "life": 0.45, "max": 0.45, "color": Color("#d6e0e2"), "size": rng.randf_range(1.0, 2.5), "kind": "smoke"})
		if not is_on_road(bus_pos) and rng.randf() < 0.35:
			particles.append({"pos": bus_pos + Vector2(rng.randf_range(-5, 5), rng.randf_range(-5, 5)), "vel": Vector2(rng.randf_range(-10, 10), rng.randf_range(-10, 10)), "life": 0.3, "max": 0.3, "color": Color("#c5ad79"), "size": 2.0, "kind": "dust"})
	# Keep effects bounded so repeated crashes cannot cause unbounded allocations.
	if particles.size() > 500:
		particles = particles.slice(particles.size() - 500)
	# Update and fade all particles.
	for pi in range(particles.size() - 1, -1, -1):
		var particle: Dictionary = particles[pi]
		particle["life"] = float(particle["life"]) - delta
		particle["pos"] = particle["pos"] + particle["vel"] * delta
		particle["vel"] = particle["vel"] * 0.94
		if float(particle["life"]) <= 0.0:
			particles.remove_at(pi)
		else:
			particles[pi] = particle
	for wi in range(wrecks.size() - 1, -1, -1):
		var wreck: Dictionary = wrecks[wi]
		wreck["life"] = float(wreck["life"]) - delta
		if float(wreck["life"]) <= 0.0:
			wrecks.remove_at(wi)
		else:
			wrecks[wi] = wreck

	# fizyka autobusu
	var max_here := speed_limit_at(bus_pos) * speed_upgrade
	if up:
		speed += ACCEL * delta
	elif down:
		if speed > 0.0:
			speed -= BRAKE * delta
		else:
			speed -= ACCEL * 0.6 * delta
	else:
		speed = move_toward(speed, 0.0, FRICTION * delta)
	if speed > max_here:
		speed = move_toward(speed, max_here, 250.0 * delta)
	speed = maxf(speed, -REVERSE_SPEED)
	angle += steer * TURN_RATE * clampf(speed / 50.0, -1.0, 1.0) * delta
	bus_pos += Vector2.from_angle(angle) * speed * delta
	bus_pos = bus_pos.clamp(Vector2(-100.0, -100.0), Vector2(1300.0, 900.0))

	# Kolizje są sprawdzane w świecie gry, niezależnie od przesunięcia kamery.
	# Menu must not consume traffic or damage the bus.
	if state == State.MENU:
		queue_redraw()
		return
	collision_cooldown = maxf(0.0, collision_cooldown - delta)
	var hit := false
	var hit_car_index := -1
	var hit_building := false
	var bus_box := Rect2(bus_pos - Vector2(10.0, 7.0), Vector2(20.0, 14.0))
	for b in buildings:
		if bus_box.intersects(b):
			hit = true
			hit_building = true
			break
	if not hit:
		for ci in range(cars.size()):
			var car: Dictionary = cars[ci]
			var cp: Vector2 = car["pos"]
			var ca: float = car["angle"]
			var car_box := Rect2(cp - Vector2(10.0, 6.0), Vector2(20.0, 12.0))
			if absf(sin(ca)) > 0.5:
				car_box = Rect2(cp - Vector2(6.0, 10.0), Vector2(12.0, 20.0))
			if bus_box.intersects(car_box):
				hit = true
				hit_car_index = ci
				break
	if hit and collision_cooldown <= 0.0 and bus_invulnerability <= 0.0:
		speed *= -0.25
		time_left = maxf(0.0, time_left - 2.0)
		bus_health = maxf(0.0, bus_health - (12.0 if hit_building else 22.0))
		bus_invulnerability = 1.0
		collision_cooldown = 0.65
		crash_shake = 0.22
		msg_timer = 1.0
		for spark_i in range(18):
			var spark_angle := rng.randf_range(0.0, TAU)
			particles.append({"pos": bus_pos, "vel": Vector2.from_angle(spark_angle) * rng.randf_range(18.0, 65.0), "life": rng.randf_range(0.18, 0.42), "max": 0.42, "color": [Color("#fff0a0"), Color("#ff9c42"), Color("#ff5d45")][spark_i % 3], "size": rng.randf_range(1.0, 2.2), "kind": "spark"})
		if hit_car_index >= 0:
			# Destroy the struck car in a bright, arcade-style explosion and leave a smoking wreck.
			var wreck_car: Dictionary = cars[hit_car_index]
			var wreck_pos: Vector2 = wreck_car["pos"]
			wrecks.append({"pos": wreck_pos, "angle": wreck_car["angle"], "color": wreck_car["color"], "life": 7.0})
			for ex_i in range(42):
				var ex_angle := rng.randf_range(0.0, TAU)
				var ex_speed := rng.randf_range(22.0, 115.0)
				var ex_color: Color = [Color("#fff4a3"), Color("#ffb12e"), Color("#ff5a36"), Color("#d83d2e"), Color("#5d6267")][ex_i % 5]
				particles.append({"pos": wreck_pos, "vel": Vector2.from_angle(ex_angle) * ex_speed, "life": rng.randf_range(0.35, 1.0), "max": 1.0, "color": ex_color, "size": rng.randf_range(1.5, 4.0), "kind": "explosion"})
			for smoke_i in range(10):
				particles.append({"pos": wreck_pos + Vector2(rng.randf_range(-5, 5), rng.randf_range(-5, 5)), "vel": Vector2(rng.randf_range(-8, 8), rng.randf_range(-20, -4)), "life": rng.randf_range(1.0, 2.2), "max": 2.2, "color": Color("#596168"), "size": rng.randf_range(3.0, 6.0), "kind": "smoke"})
			cars.remove_at(hit_car_index)
		if bus_health <= 0.0:
			state = State.OVER
			over_time = 0.0

	# czas i przystanki
	if state == State.PLAY:
		time_left -= delta
		if time_left <= 0.0:
			time_left = 0.0
			state = State.OVER
			over_time = 0.0
		else:
			update_stop(delta)
	msg_timer = maxf(0.0, msg_timer - delta)
	queue_redraw()


func update_stop(delta: float) -> void:
	var zone := stops[next_stop]
	if zone.has_point(bus_pos) and absf(speed) < 10.0:
		stop_timer += delta
		if stop_timer >= stop_duration:
			var pax := rng.randi_range(3, 9)
			last_pax = pax
			money += pax * (4 + fare_upgrade)
			time_left += BONUS_TIME + time_upgrade
			stops_done += 1
			msg_timer = 2.0
			stop_flash = 0.8
			if stops_done % 3 == 0:
				generate_upgrade_choices()
				state = State.UPGRADES
			for confetti_i in range(22):
				var confetti_angle := rng.randf_range(0.0, TAU)
				particles.append({"pos": bus_pos + Vector2(rng.randf_range(-8, 8), rng.randf_range(-8, 8)), "vel": Vector2.from_angle(confetti_angle) * rng.randf_range(12.0, 38.0), "life": rng.randf_range(0.35, 0.75), "max": 0.75, "color": [Color("#f5ce3e"), Color("#77e0bd"), Color("#f08a68"), Color("#a8c9ff")][confetti_i % 4], "size": rng.randf_range(1.0, 2.0), "kind": "confetti"})
			next_stop = (next_stop + 1) % stops.size()
			stop_timer = 0.0
	else:
		stop_timer = 0.0


func generate_upgrade_choices() -> void:
	var pool: Array[Dictionary] = [
		{"id": "turbo", "name": "TURBO SILNIK", "desc": "+15% predkosci maksymalnej"},
		{"id": "premium", "name": "DROZSZE BILETY", "desc": "+2 zl za kazdego pasazera"},
		{"id": "schedule", "name": "DOPLATA CZASOWA", "desc": "+5 sekund na kazdym przystanku"},
		{"id": "reinforced", "name": "WZMOCNIONE NADWOZIE", "desc": "+25 punktow wytrzymalosci"},
		{"id": "accel", "name": "SZYBSZE DRZWI", "desc": "Szybsza obsluga przystankow"},
		{"id": "bonus", "name": "PREMIA MIEJSKA", "desc": "+30 zl od razu"}
	]
	var available: Array[Dictionary] = []
	for item in pool:
		if not upgrades_taken.has(str(item["id"])):
			available.append(item)
	upgrade_choices.clear()
	while upgrade_choices.size() < 3 and not available.is_empty():
		var idx := rng.randi_range(0, available.size() - 1)
		upgrade_choices.append(available[idx])
		available.remove_at(idx)
	# If every unique upgrade has been collected, allow repeatable upgrades again.
	if upgrade_choices.size() < 3:
		for item in pool:
			if upgrade_choices.size() >= 3:
				break
			if not upgrade_choices.has(item):
				upgrade_choices.append(item)


func choose_upgrade(index: int) -> void:
	if state != State.UPGRADES or index < 0 or index >= upgrade_choices.size():
		return
	var picked: Dictionary = upgrade_choices[index]
	var upgrade_id := str(picked["id"])
	upgrades_taken.append(upgrade_id)
	match upgrade_id:
		"turbo": speed_upgrade *= 1.15
		"premium": fare_upgrade += 2
		"schedule": time_upgrade += 5.0
		"reinforced": bus_health = minf(100.0, bus_health + 25.0)
		"accel": stop_duration = maxf(0.5, stop_duration - 0.2)
		"bonus": money += 30
	upgrade_choices.clear()
	state = State.PLAY
	queue_redraw()


# ---------------------------------------------------------------- rysowanie

func _draw() -> void:
	var origin := (Vector2(VIEW_W, VIEW_H) * 0.5 - bus_pos).round()
	var screen := Rect2(0.0, 0.0, VIEW_W, VIEW_H)

	# trawa
	draw_rect(screen, Color("#3d7a3a"))
	var gx0 := floori(-origin.x / 16.0)
	var gy0 := floori(-origin.y / 16.0)
	for gx in range(gx0, gx0 + 22):
		for gy in range(gy0, gy0 + 13):
			var h := absi((gx * 73856093) ^ (gy * 19349663))
			if h % 3 == 0:
				var tx := gx * 16 + (h >> 4) % 13 + int(origin.x)
				var ty := gy * 16 + (h >> 9) % 13 + int(origin.y)
				draw_rect(Rect2(tx, ty, 2, 2), Color("#2f6a2f"))

	# drogi: krawężnik, asfalt, linie
	for r in roads:
		var cr := Rect2(r.position + origin, r.size).grow(2.0)
		if cr.intersects(screen):
			draw_rect(cr, Color("#8d8d8d"))
	for r in roads:
		var ar := Rect2(r.position + origin, r.size)
		if ar.intersects(screen):
			draw_rect(ar, Color("#3b3b42"))
	for r in roads:
		var dr := Rect2(r.position + origin, r.size)
		if dr.intersects(screen):
			draw_dashes(r, origin)

	# Lane markings: broken center lines and edge lines make the two traffic lanes obvious.
	for road_y in [20.0, 400.0]:
		for dash_x in range(35, 1160, 34):
			var dash_pos := Vector2(float(dash_x), road_y) + origin
			draw_rect(Rect2(dash_pos - Vector2(7, 1), Vector2(14, 2)), Color("#e5d8a0"))
		draw_line(Vector2(0, road_y - 13) + origin, Vector2(1200, road_y - 13) + origin, Color("#c5c5b3"), 1.0)
		draw_line(Vector2(0, road_y + 13) + origin, Vector2(1200, road_y + 13) + origin, Color("#c5c5b3"), 1.0)
	for road_x in [600.0]:
		for dash_y in range(35, 780, 34):
			var dash_pos := Vector2(road_x, float(dash_y)) + origin
			draw_rect(Rect2(dash_pos - Vector2(1, 7), Vector2(2, 14)), Color("#e5d8a0"))
		draw_line(Vector2(road_x - 13, 0) + origin, Vector2(road_x - 13, 800) + origin, Color("#c5c5b3"), 1.0)
		draw_line(Vector2(road_x + 13, 0) + origin, Vector2(road_x + 13, 800) + origin, Color("#c5c5b3"), 1.0)

	# Bus-lane edge markings on the outer avenues.
	draw_line(Vector2(0, 6) + origin, Vector2(1200, 6) + origin, Color("#4fa9a3"), 2.0)
	draw_line(Vector2(0, 766) + origin, Vector2(1200, 766) + origin, Color("#4fa9a3"), 2.0)
	for label_x in range(90, 1160, 150):
		shadow_text("BUS", float(label_x) + origin.x, 1.0 + origin.y, Color("#7ed1c8"), 0.7)
	for label_x in range(90, 1160, 150):
		shadow_text("BUS", float(label_x) + origin.x, 765.0 + origin.y, Color("#7ed1c8"), 0.7)

	# Zebra crossings at the central junction.
	for cross_x in [560.0, 566.0, 572.0, 628.0, 634.0, 640.0]:
		draw_rect(Rect2(Vector2(cross_x, 385.0) + origin, Vector2(3, 30)), Color("#d6d8d1"))
	for cross_y in [356.0, 362.0, 368.0, 426.0, 432.0, 438.0]:
		draw_rect(Rect2(Vector2(585.0, cross_y) + origin, Vector2(30, 3)), Color("#d6d8d1"))

	# A compact painted mini-roundabout at the main junction.
	var roundabout_center := Vector2(600, 400) + origin
	draw_arc(roundabout_center, 14.0, 0.0, TAU, 36, Color("#e4dfc9"), 1.5)
	draw_arc(roundabout_center, 10.0, 0.0, TAU, 36, Color("#a9b0a1"), 1.0)
	draw_circle(roundabout_center, 5.0, Color("#628d55"))
	draw_circle(roundabout_center, 2.0, Color("#8fb56d"))

	# Speed-limit boards: 30 on local streets, 50 on the main avenue, 70 on perimeter roads.
	for sign in [{"pos": Vector2(78, 202), "value": "30"}, {"pos": Vector2(1085, 198), "value": "30"}, {"pos": Vector2(78, 365), "value": "50"}, {"pos": Vector2(75, 48), "value": "70"}]:
		var sign_screen: Vector2 = sign["pos"] + origin
		if not screen.grow(10.0).has_point(sign_screen):
			continue
		draw_rect(Rect2(sign_screen - Vector2(1, -4), Vector2(2, 8)), Color("#454d50"))
		draw_circle(sign_screen, 6.0, Color("#f1eee6"))
		draw_arc(sign_screen, 6.0, 0.0, TAU, 24, Color("#d64740"), 1.5)
		var sign_text: String = sign["value"]
		ptext(sign_text, sign_screen.x - 4.0, sign_screen.y - 2.5, Color("#293038"), 0.7)

	# Parking spaces painted onto a small paved lay-by beside the central avenue.
	draw_rect(Rect2(Vector2(118, 328) + origin, Vector2(116, 29)), Color("#565960"))
	for bay_x in range(125, 230, 18):
		draw_rect(Rect2(Vector2(float(bay_x), 332.0) + origin, Vector2(1, 22)), Color("#a7b1b3"))
		draw_line(Vector2(float(bay_x), 332.0) + origin, Vector2(float(bay_x + 14), 332.0) + origin, Color("#a7b1b3"), 1.0)
	draw_line(Vector2(125, 354) + origin, Vector2(230, 354) + origin, Color("#a7b1b3"), 1.0)

	# One-way arrows painted on local connector streets.
	for arrow_x in range(100, 1120, 100):
		var arrow_point := Vector2(float(arrow_x), 182.0) + origin
		if screen.grow(8.0).has_point(arrow_point):
			draw_line(arrow_point + Vector2(-4, -3), arrow_point + Vector2(4, 0), Color("#e1d8a7"), 1.0)
			draw_line(arrow_point + Vector2(4, 0), arrow_point + Vector2(-4, 3), Color("#e1d8a7"), 1.0)
	for arrow_x in range(1120, 100, -100):
		var arrow_point := Vector2(float(arrow_x), 572.0) + origin
		if screen.grow(8.0).has_point(arrow_point):
			draw_line(arrow_point + Vector2(4, -3), arrow_point + Vector2(-4, 0), Color("#e1d8a7"), 1.0)
			draw_line(arrow_point + Vector2(-4, 0), arrow_point + Vector2(4, 3), Color("#e1d8a7"), 1.0)

	# Animated traffic signals at major and local intersections.
	var signal_green := traffic_clock < TRAFFIC_CYCLE_SECONDS * 0.5
	for signal_pos in [Vector2(562, 372), Vector2(633, 428), Vector2(565, 162), Vector2(635, 202), Vector2(565, 552), Vector2(635, 592)]:
		var signal_screen: Vector2 = Vector2(signal_pos.x, signal_pos.y) + origin
		if not screen.grow(8.0).has_point(signal_screen):
			continue
		draw_rect(Rect2(signal_screen - Vector2(2, 5), Vector2(5, 11)), Color("#20272b"))
		draw_circle(signal_screen + Vector2(0, -3), 1.5, Color("#ed5149") if not signal_green else Color("#612f31"))
		draw_circle(signal_screen, 1.5, Color("#e5b84c") if traffic_clock >= 5.0 and traffic_clock < 6.0 else Color("#5a4b2d"))
		draw_circle(signal_screen + Vector2(0, 3), 1.5, Color("#45d18b") if signal_green else Color("#285840"))

	# TOP-DOWN BUILDINGS: roofs and rooftop details, not front-facing facades.
	for bi in buildings.size():
		var b: Rect2 = buildings[bi]
		var br := Rect2(b.position + origin, b.size)
		if not br.intersects(screen):
			continue
		var wall_colors: Array[Color] = [Color("#d9c59a"), Color("#c6d8db"), Color("#d6a38c"), Color("#c7bee0"), Color("#b7ca9e")]
		var roof_colors: Array[Color] = [Color("#a65d4d"), Color("#637985"), Color("#b17b49"), Color("#76638e"), Color("#68835c")]
		var roof: Color = roof_colors[bi % roof_colors.size()]
		# Footprint, cast shadow, wall lip, and flat roof seen from directly overhead.
		draw_rect(Rect2(br.position + Vector2(4, 5), br.size), Color("#19252b"))
		draw_rect(Rect2(br.position - Vector2(2, 2), br.size + Vector2(4, 4)), Color("#3a4548"))
		draw_rect(br, roof)
		draw_rect(Rect2(br.position + Vector2(3, 3), br.size - Vector2(6, 6)), roof.lightened(0.12))
		# Roof perimeter highlights and roof seams.
		draw_line(br.position + Vector2(3, 3), br.position + Vector2(br.size.x - 3, 3), roof.lightened(0.32), 1.0)
		draw_line(br.position + Vector2(3, 3), br.position + Vector2(3, br.size.y - 3), roof.lightened(0.2), 1.0)
		if bi % 5 == 0:
			# rooftop garden / green roof
			draw_rect(Rect2(br.position + Vector2(6, 6), Vector2(br.size.x - 12, br.size.y - 12)), Color("#4f8555"))
			for gx in range(3):
				for gy in range(2):
					draw_circle(br.position + Vector2(10 + gx * 8, 11 + gy * 8), 2.2, Color("#86b86a"))
		elif bi % 5 == 1:
			# HVAC units
			for hx in [7.0, br.size.x - 15.0]:
				draw_rect(Rect2(br.position + Vector2(hx, 7), Vector2(8, 7)), Color("#c3c9c7"))
				draw_rect(Rect2(br.position + Vector2(hx + 2, 9), Vector2(4, 3)), Color("#7c898d"))
				draw_line(br.position + Vector2(hx + 1, 15), br.position + Vector2(hx + 7, 15), Color("#333d42"), 1.0)
		elif bi % 5 == 2:
			# skylights
			for sx in [7.0, br.size.x - 15.0]:
				draw_rect(Rect2(br.position + Vector2(sx, 7), Vector2(8, 10)), Color("#343f48"))
				draw_rect(Rect2(br.position + Vector2(sx + 2, 9), Vector2(4, 6)), Color("#8ecbd8"))
				draw_line(br.position + Vector2(sx + 2, 12), br.position + Vector2(sx + 6, 12), Color("#d9f3f5"), 1.0)
		elif bi % 5 == 3:
			# solar panels
			for px in [6.0, 17.0, 28.0]:
				if px + 7 < br.size.x - 2:
					draw_rect(Rect2(br.position + Vector2(px, 8), Vector2(7, 12)), Color("#243d59"))
					draw_line(br.position + Vector2(px + 3.5, 8), br.position + Vector2(px + 3.5, 20), Color("#79a9cb"), 1.0)
					draw_line(br.position + Vector2(px, 14), br.position + Vector2(px + 7, 14), Color("#79a9cb"), 1.0)
		else:
			# roof access structure and vents
			draw_rect(Rect2(br.position + Vector2(br.size.x * 0.5 - 5, br.size.y * 0.5 - 4), Vector2(10, 8)), Color("#d3c9b3"))
			draw_rect(Rect2(br.position + Vector2(br.size.x * 0.5 - 3, br.size.y * 0.5 - 2), Vector2(6, 4)), Color("#8a938f"))
			draw_circle(br.position + Vector2(br.size.x - 8, 8), 2.5, Color("#414c51"))
		# Roof-only buildings: no front-facing door or facade details.
		# Tiny shop sign on the roof edge, with recognizable transit-related colors.
		var sign_color := Color("#f0c52f") if bi % 3 == 0 else (Color("#3b8290") if bi % 3 == 1 else Color("#b85b4b"))
		draw_rect(Rect2(br.position + Vector2(5, 1), Vector2(minf(12.0, br.size.x - 10.0), 3)), sign_color)

	# Gliwice landmarks, drawn as distinct overhead miniatures rather than generic blocks.
	# Rynek + ratusz: central square with arcaded tenement blocks and a clock tower.
	var market := Rect2(Vector2(270, 120) + origin, Vector2(84, 72))
	if market.intersects(screen):
		draw_rect(market.grow(5.0), Color("#8b8b80"))
		draw_rect(market, Color("#c8bda5"))
		for tile_x in range(0, 84, 8):
			draw_line(market.position + Vector2(tile_x, 0), market.position + Vector2(tile_x, 72), Color("#b2a58f"), 1.0)
		for tile_y in range(0, 72, 8):
			draw_line(market.position + Vector2(0, tile_y), market.position + Vector2(84, tile_y), Color("#b2a58f"), 1.0)
		draw_rect(Rect2(market.position + Vector2(28, 22), Vector2(28, 28)), Color("#a69b87"))
		draw_rect(Rect2(market.position + Vector2(31, 25), Vector2(22, 22)), Color("#d4c8ad"))
		draw_rect(Rect2(market.position + Vector2(37, 28), Vector2(10, 16)), Color("#8e6551"))
		draw_rect(Rect2(market.position + Vector2(37, 17), Vector2(10, 10)), Color("#e6dfcc"))
		draw_circle(market.position + Vector2(42, 22), 3.0, Color("#f2c62f"))
		# Arcade-like perimeter buildings.
		for shop_x in [4.0, 20.0, 60.0]:
			draw_rect(Rect2(market.position + Vector2(shop_x, 4), Vector2(12, 12)), Color("#9b5c4c"))
			draw_rect(Rect2(market.position + Vector2(shop_x + 2, 6), Vector2(8, 8)), Color("#d9bca0"))
			draw_rect(Rect2(market.position + Vector2(shop_x, 56), Vector2(12, 12)), Color("#647a87"))
			draw_rect(Rect2(market.position + Vector2(shop_x + 2, 58), Vector2(8, 8)), Color("#d7c5ad"))

	# Palmiarnia: long glass greenhouse roofs with green palm crowns.
	var palm := Rect2(Vector2(790, 115) + origin, Vector2(82, 48))
	if palm.intersects(screen):
		draw_rect(palm.grow(4.0), Color("#4b5749"))
		draw_rect(palm, Color("#78a9a0"))
		for gx in range(8, 78, 10):
			draw_rect(Rect2(palm.position + Vector2(gx, 3), Vector2(7, 42)), Color("#a8d8d0"))
			draw_line(palm.position + Vector2(gx + 3, 4), palm.position + Vector2(gx + 3, 44), Color("#547d79"), 1.0)
		for tree in [Vector2(17, 15), Vector2(37, 30), Vector2(58, 14), Vector2(67, 33)]:
			draw_circle(palm.position + tree, 5.0, Color("#2e754c"))
			draw_circle(palm.position + tree + Vector2(-2, -1), 2.5, Color("#66ad63"))
		draw_rect(Rect2(palm.position + Vector2(32, 0), Vector2(16, 48)), Color(0.2, 0.35, 0.34, 0.5))

	# Radiostacja: recognizable tall wooden mast base with cross-bracing and red warning lights.
	var radio := Vector2(1000, 525) + origin
	if screen.grow(30.0).has_point(radio):
		draw_circle(radio + Vector2(3, 4), 21.0, Color(0.02, 0.03, 0.03, 0.3))
		draw_rect(Rect2(radio - Vector2(15, 15), Vector2(30, 30)), Color("#6c5944"))
		draw_rect(Rect2(radio - Vector2(12, 12), Vector2(24, 24)), Color("#b78d5b"))
		draw_line(radio + Vector2(-11, -11), radio + Vector2(11, 11), Color("#6c402d"), 2.0)
		draw_line(radio + Vector2(11, -11), radio + Vector2(-11, 11), Color("#6c402d"), 2.0)
		draw_line(radio + Vector2(-8, -13), radio + Vector2(0, -24), Color("#c8a16a"), 2.0)
		draw_line(radio + Vector2(8, -13), radio + Vector2(0, -24), Color("#c8a16a"), 2.0)
		draw_circle(radio + Vector2(0, -24), 2.0, Color("#ff625b"))
		draw_circle(radio, 3.0, Color("#44362d"))

	# Piast Castle: compact historic red-roofed courtyard.
	var castle := Rect2(Vector2(315, 515) + origin, Vector2(60, 42))
	if castle.intersects(screen):
		draw_rect(castle.grow(3.0), Color("#77766c"))
		draw_rect(castle, Color("#a75c48"))
		draw_rect(Rect2(castle.position + Vector2(7, 7), Vector2(46, 28)), Color("#c5b69a"))
		draw_rect(Rect2(castle.position + Vector2(15, 13), Vector2(30, 16)), Color("#7d9b78"))
		for tower_pos in [Vector2(5, 5), Vector2(45, 5), Vector2(5, 29), Vector2(45, 29)]:
			draw_rect(Rect2(castle.position + tower_pos, Vector2(10, 8)), Color("#8f463b"))
			draw_rect(Rect2(castle.position + tower_pos + Vector2(2, 2), Vector2(6, 4)), Color("#d2b18a"))

	# TOP-DOWN TRAFFIC: compact cars viewed from directly above, aligned to lanes.
	for car in cars:
		var cp: Vector2 = car["pos"]
		var ca: float = car["angle"]
		if not screen.intersects(Rect2(cp + origin - Vector2(15, 12), Vector2(30, 24))):
			continue
		draw_set_transform(cp + origin, ca, Vector2.ONE)
		# Drop shadow and tires.
		draw_rect(Rect2(-12, -7, 24, 14), Color("#172126"))
		draw_rect(Rect2(-10, -8, 5, 3), Color("#101518"))
		draw_rect(Rect2(5, -8, 5, 3), Color("#101518"))
		draw_rect(Rect2(-10, 5, 5, 3), Color("#101518"))
		draw_rect(Rect2(5, 5, 5, 3), Color("#101518"))
		# Body shell, hood, roof, and windshields.
		draw_rect(Rect2(-12, -6, 24, 12), Color("#252c32"))
		draw_rect(Rect2(-11, -5, 22, 10), car["color"])
		draw_rect(Rect2(-11, -4, 5, 8), car["color"].lightened(0.18))
		draw_rect(Rect2(-6, -4, 11, 8), Color("#8fc7d8"))
		draw_rect(Rect2(-4, -3, 7, 6), Color("#c6e6ed"))
		draw_rect(Rect2(5, -4, 4, 8), car["color"].darkened(0.18))
		# Windscreen reflections and center divider.
		draw_line(Vector2(-5, -3), Vector2(-1, -3), Color("#eefbff"), 1.0)
		draw_line(Vector2(-5, 3), Vector2(-1, 3), Color("#eefbff"), 1.0)
		draw_line(Vector2(1, -4), Vector2(1, 4), Color("#426a7b"), 1.0)
		# Headlight beams/glow become visible at dusk and night.
		if daylight < 0.62:
			var glow_alpha := clampf((0.72 - daylight) * 1.8, 0.12, 0.72)
			draw_colored_polygon(PackedVector2Array([Vector2(-11, -5), Vector2(-30, -12), Vector2(-30, 12), Vector2(-11, 5)]), Color(1.0, 0.91, 0.58, glow_alpha * 0.22))
			draw_circle(Vector2(-12, -2.5), 3.0, Color(1.0, 0.92, 0.62, glow_alpha))
			draw_circle(Vector2(-12, 2.5), 3.0, Color(1.0, 0.92, 0.62, glow_alpha))
		# Headlamps at front and red tail lamps at rear.
		draw_rect(Rect2(-12, -4, 2, 3), Color("#fff3bd"))
		draw_rect(Rect2(-12, 1, 2, 3), Color("#fff3bd"))
		draw_rect(Rect2(10, -4, 2, 3), Color("#ff665b"))
		draw_rect(Rect2(10, 1, 2, 3), Color("#ff665b"))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# Przystanki autobusowe: peron, ławka, wiata, słupek i tablica z literą B.
	for i in stops.size():
		var zr := Rect2(stops[i].position + origin, stops[i].size)
		if not zr.intersects(screen):
			continue
		var active := (i == next_stop)
		var zc := Color("#f1c40f") if active else Color("#7f8c8d")
		draw_rect(zr, Color(zc.r, zc.g, zc.b, 0.35 if active else 0.2))
		draw_rect(zr, zc, false, 1.0)
		if active:
			shadow_text(stop_names[i], zr.position.x, zr.position.y - 8.0, Color.WHITE)
		# Wiata i słupek są ustawiane na chodniku przy każdym przystanku.
		var horizontal_stop := zr.size.x >= zr.size.y
		var shelter_pos := zr.position + (Vector2(5, 3) if horizontal_stop else Vector2(3, 5))
		var shelter_size := Vector2(20, 16) if horizontal_stop else Vector2(16, 20)
		draw_rect(Rect2(shelter_pos + Vector2(2, 2), shelter_size), Color("#292f33"))
		draw_rect(Rect2(shelter_pos, shelter_size), Color("#6b777b"))
		draw_rect(Rect2(shelter_pos + Vector2(2, 2), shelter_size - Vector2(4, 5)), Color("#91c4cc"))
		draw_rect(Rect2(shelter_pos + Vector2(2, shelter_size.y - 4), Vector2(shelter_size.x - 4, 2)), Color("#d9d5c5"))
		draw_rect(Rect2(shelter_pos + Vector2(2, shelter_size.y - 2), Vector2(3, 2)), Color("#3c454a"))
		draw_rect(Rect2(shelter_pos + Vector2(shelter_size.x - 5, shelter_size.y - 2), Vector2(3, 2)), Color("#3c454a"))
		var pole_pos := zr.position + (Vector2(zr.size.x - 7, 2) if horizontal_stop else Vector2(2, zr.size.y - 9))
		draw_rect(Rect2(pole_pos, Vector2(2, 12)), Color("#44484c"))
		draw_rect(Rect2(pole_pos + Vector2(-3, -3), Vector2(8, 7)), Color("#f0c52f"))
		draw_rect(Rect2(pole_pos + Vector2(-1, -1), Vector2(4, 3)), Color("#315f9b"))
		shadow_text("B", pole_pos.x + 1, pole_pos.y - 2, Color.WHITE)

	# Particles: exhaust smoke, grass dust, collision sparks, and passenger confetti.
	for particle in particles:
		var pp: Vector2 = particle["pos"] + origin
		if not screen.grow(8.0).has_point(pp):
			continue
		var life_ratio: float = clampf(float(particle["life"]) / float(particle["max"]), 0.0, 1.0)
		var pcol: Color = particle["color"]
		pcol.a *= life_ratio
		var psz: float = float(particle["size"]) * (1.25 - life_ratio * 0.25)
		if particle["kind"] == "spark":
			var vel: Vector2 = particle["vel"]
			draw_line(pp, pp - vel.normalized() * 3.0, pcol, maxf(1.0, psz))
			draw_circle(pp, psz, pcol)
		elif particle["kind"] == "explosion":
			draw_circle(pp, psz * 1.5, Color(pcol.r, pcol.g, pcol.b, pcol.a * 0.35))
			draw_circle(pp, psz, pcol)
		elif particle["kind"] == "confetti":
			draw_set_transform(pp, fx_clock * 4.0, Vector2.ONE)
			draw_rect(Rect2(-psz, -psz * 0.5, psz * 2.0, psz), pcol)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		else:
			draw_circle(pp, psz, pcol)
			if particle["kind"] == "smoke":
				draw_circle(pp + Vector2(1, -1), psz * 0.6, Color(pcol.r, pcol.g, pcol.b, pcol.a * 0.45))

	# Dynamic day/night lighting tint; the HUD is drawn afterward and stays legible.
	var night_strength := 1.0 - daylight
	if night_strength > 0.01:
		draw_rect(screen, Color(0.035, 0.055, 0.16, night_strength * 0.58))
	var phase_fraction := day_clock / DAY_CYCLE_SECONDS
	var dusk_strength := 1.0 - absf(daylight * 2.0 - 1.0)
	if dusk_strength > 0.01:
		var transition_tint := Color(0.25, 0.10, 0.025, dusk_strength * 0.12)
		if phase_fraction >= 0.5:
			transition_tint = Color(0.12, 0.18, 0.28, dusk_strength * 0.08)
		draw_rect(screen, transition_tint)

	# Street lamps along sidewalks glow at night.
	var lamp_positions: Array[Vector2] = [
		Vector2(120, 354), Vector2(250, 354), Vector2(430, 354), Vector2(770, 354), Vector2(920, 354),
		Vector2(160, 445), Vector2(360, 445), Vector2(700, 445), Vector2(900, 445), Vector2(1090, 445),
		Vector2(555, 350), Vector2(645, 450), Vector2(555, 195), Vector2(645, 565),
	]
	for lamp in lamp_positions:
		var lamp_screen := lamp + origin
		if not screen.grow(16.0).has_point(lamp_screen):
			continue
		if night_strength > 0.05:
			draw_circle(lamp_screen, 11.0, Color(1.0, 0.76, 0.36, night_strength * 0.10))
		draw_rect(Rect2(lamp_screen - Vector2(1.0, 1.0), Vector2(3.0, 3.0)), Color("#ecd08a") if night_strength > 0.3 else Color("#667175"))

	# Dynamic bus shadow and soft headlight glow.
	var bus_screen := origin + bus_pos
	draw_set_transform(bus_screen + Vector2(3, 4), angle, Vector2(bus_scale, bus_scale))
	draw_rect(Rect2(-15, -7, 30, 15), Color(0.02, 0.04, 0.05, 0.42))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var head_pos := bus_screen + Vector2.from_angle(angle) * 14.0
	draw_circle(head_pos, 12.0, Color(1.0, 0.78, 0.36, night_strength * 0.12))
	draw_circle(head_pos, 5.0, Color(1.0, 0.9, 0.58, night_strength * 0.28))

	# Autobus: selectable paint color and brighter roof stripe; headlights cast beams at night.
	draw_set_transform(origin + bus_pos, angle, Vector2(bus_scale, bus_scale))
	if night_strength > 0.08:
		var beam := PackedVector2Array([Vector2(10, -4), Vector2(10, 4), Vector2(72, 22), Vector2(72, -22)])
		draw_colored_polygon(beam, Color(1.0, 0.83, 0.48, night_strength * 0.11))
	draw_rect(Rect2(-14.0, -6.5, 28.0, 13.0), Color("#2b2110"))
	var bus_paint: Color = bus_paint_colors[bus_color_index]
	draw_rect(Rect2(-13.0, -5.5, 26.0, 11.0), bus_paint)
	draw_rect(Rect2(-10.0, -4.0, 16.0, 8.0), bus_paint.lightened(0.12))
	draw_rect(Rect2(8.0, -4.5, 4.0, 9.0), Color("#23465f"))
	draw_rect(Rect2(-7.0, -5.0, 9.0, 1.5), Color("#263f50"))
	draw_rect(Rect2(-7.0, 3.5, 9.0, 1.5), Color("#263f50"))
	draw_rect(Rect2(7.0, -3.0, 4.0, 6.0), Color("#9fd9ed"))
	draw_rect(Rect2(-13.0, -4.5, 1.0, 2.0), Color("#e74c3c"))
	draw_rect(Rect2(-13.0, 2.5, 1.0, 2.0), Color("#e74c3c"))
	draw_rect(Rect2(12.0, -4.5, 1.0, 2.0), Color("#ffffff"))
	draw_rect(Rect2(12.0, 2.5, 1.0, 2.0), Color("#ffffff"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	shadow_text(line_numbers[selected_line], bus_screen.x - 2.0, bus_screen.y - 2.0, Color("#ffffff"))

	# strzałka do następnego przystanku
	if state != State.OVER:
		var to_stop := stops[next_stop].get_center() - bus_pos
		if to_stop.length() > 100.0:
			var d := to_stop.normalized()
			var p := Vector2(VIEW_W, VIEW_H) * 0.5 + d * 60.0
			var n := Vector2(-d.y, d.x)
			var tri := PackedVector2Array([p + d * 7.0, p - d * 4.0 + n * 5.0, p - d * 4.0 - n * 5.0])
			draw_colored_polygon(tri, Color("#f1c40f"))

	draw_hud()


func draw_dashes(r: Rect2, origin: Vector2) -> void:
	var col := Color("#d8d8c0")
	if r.size.x > r.size.y:
		var y := r.position.y + r.size.y * 0.5 - 1.0 + origin.y
		if y > -2.0 and y < VIEW_H + 2.0:
			var x := r.position.x + 8.0
			while x < r.end.x - 8.0:
				var sx := x + origin.x
				if sx > -10.0 and sx < VIEW_W + 10.0:
					draw_rect(Rect2(sx, y, 8.0, 2.0), col)
				x += 16.0
	else:
		var x2 := r.position.x + r.size.x * 0.5 - 1.0 + origin.x
		if x2 > -2.0 and x2 < VIEW_W + 2.0:
			var y2 := r.position.y + 8.0
			while y2 < r.end.y - 8.0:
				var sy := y2 + origin.y
				if sy > -10.0 and sy < VIEW_H + 10.0:
					draw_rect(Rect2(x2, sy, 2.0, 8.0), col)
				y2 += 16.0


func draw_hud() -> void:
	var yellow := Color("#f1c40f")
	if state == State.MENU:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.015, 0.035, 0.055, 0.86))
		draw_rect(Rect2(10, 8, VIEW_W - 20, VIEW_H - 16), Color("#1c2d38"))
		draw_rect(Rect2(10, 8, VIEW_W - 20, 3), Color("#f2c62f"))
		center_text("GLIWICE BUS DRIVER", 20.0, Color("#f2c62f"), 2.0)
		center_text("WYBIERZ LINIE", 38.0, Color.WHITE)
		for li in range(mini(line_numbers.size(), 4)):
			var row_y := 53.0 + li * 16.0
			var selected := li == selected_line
			if selected:
				draw_rect(Rect2(25, row_y - 3, VIEW_W - 50, 16), Color("#3c5968"))
				draw_rect(Rect2(25, row_y - 3, 3, 16), Color("#f2c62f"))
			shadow_text("LINIA " + line_numbers[li], 34.0, row_y, line_colors[li], 1.0)
			shadow_text(line_destinations[li], 91.0, row_y, Color.WHITE, 1.0)
		center_text("STRZALKI / 1-4: WYBOR LINII", 119.0, Color("#b9d4df"))
		center_text("KOLOR AUTOBUSU - C", 129.0, Color("#d6e3e8"))
		var swatch_width := 13.0
		var swatch_gap := 4.0
		var swatch_start := (VIEW_W - (bus_paint_colors.size() * swatch_width + (bus_paint_colors.size() - 1) * swatch_gap)) * 0.5
		for ci in range(bus_paint_colors.size()):
			var swatch := Rect2(swatch_start + ci * (swatch_width + swatch_gap), 135.0, swatch_width, 6.0)
			draw_rect(swatch, bus_paint_colors[ci])
			if ci == bus_color_index:
				draw_rect(swatch.grow(1.0), Color.WHITE, false, 1.0)
		if custom_line_editing:
			center_text("LINIA: " + custom_line_text + "_", 146.0, Color("#62c6a5"))
		else:
			center_text("L - WLASNY NUMER LINII", 146.0, Color("#62c6a5"))
		center_text("ENTER - START / ENTER W EDYCJI - OK", 160.0, Color("#f2c62f"))
		return
	shadow_text("LINIA " + line_numbers[selected_line], 4.0, 4.0, line_colors[selected_line])
	var phase_fraction := day_clock / DAY_CYCLE_SECONDS
	var time_phase := "DAY"
	if daylight < 0.28:
		time_phase = "NIGHT"
	elif daylight < 0.68:
		time_phase = "DUSK" if phase_fraction < 0.5 else "DAWN"
	else:
		time_phase = "DAY"
	shadow_text(time_phase, VIEW_W - time_phase.length() * 4.0 - 4.0, 13.0, Color("#f4d891") if daylight < 0.45 else Color("#ecf4f8"))
	shadow_text("ZL " + str(money), 4.0, 12.0, yellow)
	draw_rect(Rect2(4, 23, 84, 8), Color("#20282e"))
	var health_ratio := bus_health / 100.0
	var health_color := Color("#54d18b") if health_ratio > 0.6 else (Color("#f0c52f") if health_ratio > 0.3 else Color("#ef5548"))
	draw_rect(Rect2(5, 24, 82.0 * health_ratio, 6), health_color)
	shadow_text("BUS " + str(ceili(bus_health)) + "%", 4.0, 32.0, Color.WHITE)
	shadow_text("KMH " + str(int(absf(speed) * 0.5)), VIEW_W - 40.0, 4.0, Color.WHITE)
	shadow_text("PRZYSTANEK: " + stop_names[next_stop], 4.0, VIEW_H - 10.0, Color.WHITE)

	if state == State.WAIT:
		center_text("LINIA " + line_numbers[selected_line] + " - " + line_descriptions[selected_line], 40.0, yellow, 1.0)
		center_text("STRZALKI LUB WASD", 70.0, Color.WHITE)
		center_text("ZATRZYMAJ SIE NA ZOLTYM PRZYSTANKU", 82.0, Color.WHITE)
		center_text("DYM, PYL, BLASKI I EFEKTY KOLIZJI", 94.0, Color.WHITE)
	elif state == State.PLAY:
		if stop_timer > 0.0:
			center_text("WSIADAJA PASAZEROWIE", 130.0, Color.WHITE)
			draw_rect(Rect2(110.0, 140.0, 100.0, 6.0), Color(0, 0, 0, 0.7))
			draw_rect(Rect2(110.0, 140.0, 100.0 * clampf(stop_timer / stop_duration, 0.0, 1.0), 6.0), yellow)
		if msg_timer > 0.0:
			if collision_cooldown > 0.0:
				center_text("STLUCZKA! -2 S", 50.0, Color("#ff6b5b"))
			else:
				center_text("+%d PAX  +%d ZL  +%d S" % [last_pax, last_pax * (4 + fare_upgrade), int(BONUS_TIME + time_upgrade)], 50.0, yellow)
	elif state == State.UPGRADES:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.02, 0.04, 0.06, 0.88))
		center_text("WYBIERZ ULEPSZENIE", 35.0, yellow, 1.5)
		center_text("CO 3 PRZYSTANKI - WYBIERZ 1, 2 LUB 3", 48.0, Color.WHITE)
		for ui in range(upgrade_choices.size()):
			var card := Rect2(12.0 + ui * 101.0, 61.0, 94.0, 76.0)
			draw_rect(card, Color("#26343b"))
			draw_rect(card, yellow if ui == 0 else Color("#6f8790"), false, 1.0)
			center_text(str(ui + 1), 73.0, yellow)
			var item: Dictionary = upgrade_choices[ui]
			center_text(str(item["name"]), 88.0, Color.WHITE)
			center_text(str(item["desc"]), 103.0, Color("#b9d4df"))
		center_text("NACISNIJ KLAWISZ 1 / 2 / 3", 153.0, Color("#77e0bd"))
	else:
		center_text("KONIEC KURSU", 50.0, Color("#ff6b5b"), 2.0)
		center_text("ZAROBEK: %d ZL" % money, 80.0, yellow)
		center_text("PRZYSTANKI: %d" % stops_done, 92.0, Color.WHITE)
		if over_time > 1.0:
			center_text("ENTER - NOWA GRA", 116.0, Color.WHITE)


# Rysowanie tekstu pikselowym fontem 3x5.
func ptext(s: String, x: float, y: float, col: Color, sc: float = 1.0) -> void:
	var cx := x
	for ch in s.to_upper():
		if FONT.has(ch):
			var g: Array = FONT[ch]
			for row in 5:
				var line: String = g[row]
				for ci in 3:
					if line[ci] == "X":
						draw_rect(Rect2(cx + ci * sc, y + row * sc, sc, sc), col)
		cx += 4.0 * sc


func shadow_text(s: String, x: float, y: float, col: Color, sc: float = 1.0) -> void:
	ptext(s, x + sc, y + sc, Color(0, 0, 0, 0.8), sc)
	ptext(s, x, y, col, sc)


func center_text(s: String, y: float, col: Color, sc: float = 1.0) -> void:
	var w := s.length() * 4.0 * sc - sc
	shadow_text(s, floorf((VIEW_W - w) * 0.5), y, col, sc)
