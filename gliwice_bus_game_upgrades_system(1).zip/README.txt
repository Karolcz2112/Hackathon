GLIWICE BUS DRIVER — DELUXE PROTOTYPE

Open project.godot in Godot 4 and press F5.

Controls:
- Menu: Left/Right or 1/2/3 selects line; Enter/Space starts.
- Drive: WASD or arrow keys.
- Stop inside the highlighted stop zone and brake to pick up passengers.
- Enter/R after game over restarts.

Gliwice theme:
- Menu line choices use real line numbers found in the ZTM/GZM network (6, 32, 840).
- The selected line changes the bus livery and destination label.
- Landmark names are inspired by Gliwice: Market Square/Rynek, Palm House/Palmiarnia, and Radio Station/Radiostacja.
- Routes in this prototype are simplified gameplay loops, not exact official timetables or stop-by-stop routes. Vehicle graphics are stylized and do not claim to depict exact current fleet models.

Visuals:
- Dynamic exhaust smoke, grass dust, collision sparks, passenger confetti.
- Bus drop shadow and headlight glow.
- Top-down roof details, city greenery, and enhanced road lighting.

New in this version:
- Colliding with a car triggers an arcade-style explosion, removes the car from traffic, and leaves a smoking wreck.
- Bus health starts at 100%. Collisions damage the bus; buildings deal 12 damage, cars deal 22. At zero health the run ends.
- Added an A4 menu option with a distinct blue livery. This is a game route label/theme, not a claim that A4 is an official Gliwice city bus line.


Najnowsze zmiany:
- Budynki są widziane wyłącznie z góry: dachy, świetliki, panele słoneczne, wentylacja i ogrody dachowe; dodano wiele kolejnych budynków o różnych rozmiarach.
- Trasa losuje kolejność 12 przystanków przy każdym rozpoczęciu gry.
- Autobus losuje jeden z trzech rozmiarów wizualnych: mały, standardowy lub przegubowy/długi.
- W menu naciśnij L, wpisz własny numer linii (litery/cyfry, maks. 6 znaków), a następnie Enter, aby zatwierdzić wpis; Enter ponownie uruchamia grę. Backspace usuwa znak, Esc kończy edycję.


Aktualizacja: miasto, oświetlenie i kolory autobusów
- Dodano dwie węższe ulice lokalne między kwartałami zabudowy, oznaczenia buspasów, przejścia dla pieszych, miejsca parkingowe i strzałki kierunkowe.
- Dodano animowane sygnalizatory świetlne; ruch na głównym pionowym przejeździe zatrzymuje się na czerwonym świetle.
- Cykl dnia i nocy trwa około 100 sekund: oświetlenie otoczenia zmienia się, latarnie świecą po zmroku, a reflektory autobusu rozjaśniają drogę.
- W menu naciśnij C, aby przełączać 8 kolorów nadwozia. Wybrany kolor zostaje użyty w następnym kursie.
- Sterowanie: strzałki/WASD, C - kolor autobusu w menu, L - wpisanie własnego numeru linii.
- Różne ograniczenia prędkości (odczyt na HUD): 30 km/h na ulicach lokalnych, 50 km/h na głównych drogach oraz 70 km/h na drogach obwodowych. Dodano tablice ograniczeń i malowane mini-rondo przy głównym skrzyżowaniu.
