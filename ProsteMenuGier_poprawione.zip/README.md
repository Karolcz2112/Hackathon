# Menu gier — Godot 4

Projekt łączy trzy gry z archiwów w jednym menu. Przycisk **MENU GŁÓWNE** na brzegu ekranu oraz skrót **F10** lub **Home** wracają do wyboru gier. Pasek nawigacji jest dodany poza scenami gier, więc nie zmienia ich rozgrywki. Przyciski, sklep, wyniki i zasady wewnątrz gier pozostają takie jak w oryginalnych plikach.

## Uruchomienie projektu

1. Rozpakuj cały folder `outputs` w jedno miejsce.
2. Otwórz `project.godot` w Godot 4.7 lub nowszym. Projekty źródłowe wskazują format Godot 4.7.
3. Uruchom projekt klawiszem **F6** lub **F5**.
4. W menu wybierz jedną z trzech gier. Wróć przyciskiem **MENU GŁÓWNE** albo klawiszem **F10/Home**.

Sceny gier są wyświetlane w ich pierwotnych proporcjach obrazu: biegacz i autobus w poziomie, Timberman w pionie. W razie różnicy proporcji okna pojawią się wolne pasy po bokach lub u góry.

## Gry i mechaniki

### Gliwice Sprint: Szlak Radiostacji (`games/subwaysurf`)

Trójwymiarowy endless runner po stylizowanych Gliwicach. Biegnij trzema pasami, omijaj tramwaje, autobusy, pociągi, bariery i niskie belki. Zbieraj monety oraz czasowe moce. Rampa pozwala wbiec na dach pociągu. Wynik i monety są zapisywane, a monety można wydać w sklepie na postacie z własnymi bonusami.

- **A/D** lub **←/→** — zmiana pasa.
- **W**, **Spacja** lub **↑** — skok.
- **S** lub **↓** — kucanie pod belkami (przytrzymaj).
- **Enter** — rozpoczęcie biegu; po zderzeniu **R/Enter** uruchamia bieg ponownie.
- W sklepie postaci: **←/→** przeglądanie, **Enter** zakup/wybór, **Esc** powrót.

### Kierowca autobusu (`games/bus`)

Pikselowa gra z widokiem z góry. Wybierz linię i autobus, prowadź po mieście, zabieraj pasażerów na żółtych przystankach i zmieść się w limicie czasu. Co trzy przystanki wybierasz ulepszenie. Kolizje uszkadzają autobus, a pauza zatrzymuje symulację.

- **↑/W** — przyspieszanie; **↓/S** — hamowanie i cofanie.
- **←/A** oraz **→/D** — skręcanie.
- W menu: **↑/↓** wybór linii, **←/→** wybór rozmiaru autobusu, **C** zmiana koloru, **Enter** start.
- **Esc** — pauza/wznowienie; w pauzie **M** wraca do menu tej gry.
- Po trzech przystankach wybierz ulepszenie klawiszem **1**, **2** lub **3**.

### Radiostacja Gliwice — Wspinaczka (`games/timberman`)

Gra zręcznościowa inspirowana Timbermanem. Przerąbuj się w górę makietowej wieży, zmieniaj stronę i unikaj anten lub gałęzi. Pilnuj energii i zbieraj pierogi. Do wyboru są tryby: Radiostacja (111 m), Ratusz, Politechnika oraz bez końca. Pierogi odblokowują postacie z bonusami.

- **A/←** i **D/→** albo kliknięcie lewej/prawej połowy ekranu — zmiana strony i cięcie.
- **Enter/Spacja** — start oraz ponowienie rundy.
- **B** — sklep postaci; **←/→** przeglądanie, **Enter/Spacja/B** zakup lub wybór, **Esc** powrót.
- W menu **A/D** lub strzałkami wybieraj tryb.

## Zbudowanie pliku `.exe` na Windows

1. Otwórz projekt w Godot i zainstaluj pasujące szablony eksportu przez **Editor → Manage Export Templates**.
2. Wybierz **Project → Export**, kliknij **Add… → Windows Desktop**.
3. Wybierz preset **Windows Desktop**, a w eksporcie wskaż ścieżkę, np. `build/MenuGier.exe`.
4. Kliknij **Export Project**. Jeżeli Godot utworzy obok plik `.pck`, zachowaj go w tym samym folderze co `.exe`.
5. Uruchom `.exe` i sprawdź wybór oraz powrót z każdej gry. Do wysłania spakuj razem wszystkie pliki wygenerowane przez eksport.

Instrukcja Godot: [Eksport na Windows](https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_windows.html).


