# Gliwice Sprint: Szlak Radiostacji

Proceduralna gra 3D endless runner w Godot 4. Pędź przez stylizowane Gliwice, omijaj tramwaje, autobusy linii A4/M105/59, pociągi jadące wprost na biegacza, objazdy, doły i niskie belki. Pod belkami trzeba się kucnąć. Co chwilę pojawia się nowa grupa przeszkód, ale jeden pas zawsze zostaje wolny. Tempo zaczyna się spokojnie i stopniowo przyspiesza. Trasa mija Radiostację, Rynek, Politechnikę Śląską, Palmiarnię, Zamek Piastowski, dworzec, Arenę i gliwickie sklepy oraz szkoły. Po bokach znajdziesz przystanki, drzewa i miejskie detale, a charakterystyczna, rozszerzana u podstawy wieża Radiostacji pozostaje widoczna na horyzoncie. Na plecach biegacza widnieje napis **ZSTI GLIWICE**.

Na dach pociągu można dostać się wyłącznie przez rampę zaczynającą się na poziomie torów; wejście jest możliwe tylko wtedy, gdy biegacz jest ustawiony na pasie rampy. Po wejściu można biec po wagonach i zmieniać pas. Gdy koniec pociągu minie biegacza, postać spada z powrotem na trasę. Zderzenie kończy bieg dopiero przy fizycznym kontakcie z przeszkodą — sama obecność na tym samym pasie nie wystarcza; wysokość skoku i kucanie są uwzględniane. Bliskie minięcie przeszkody zwraca punkty, ale rusza za tobą łysy **Pan Procesor**. Ekran końca biegu pokazuje wynik, monety i rekord. Trzy power-upy: **tarcza** blokuje zderzenie, trójwymiarowy podkowiasty **magnes** przyciąga pionowo ustawione monety, a **fioletowe x2** podwaja wynik. Zebrana tarcza działa 10 sekund (Piast startuje z tarczą na 12 sekund), a liczniki mocy są widoczne po prawej stronie ekranu. Każda zebrana moc ma własny wiersz z ikoną i odliczaniem.

Zebrane monety zapisują się między biegami. W menu **Postacie** można za nie kupić osiem postaci; sklep pokazuje podgląd modelu, opis, cenę i unikalną supermoc. ZSTI ma wyższy skok, Piast zaczyna z czasową tarczą, Radio Fala z magnesem na 12 sekund, Nowe Gliwice z podwójnym wynikiem, Żabka daje dwie monety za każdą, Politechnika Śląska zwiększa wynik, uczeń szybciej zmienia pas, a Biedronka przyciąga monety z większej odległości.

## Uruchomienie

Otwórz `project.godot` w Godot 4 i uruchom projekt (F6/F5 lub przycisk „Uruchom projekt”). Gra nie wymaga zewnętrznych assetów ani dodatkowych zależności.

## Sterowanie

- **A / D** lub **← / →** — zmiana pasa
- **W / Spacja / ↑** — skok nad barierami
- **S / ↓** — kucanie pod niskimi belkami (przytrzymaj)
- Rampa pociągu automatycznie prowadzi na dach; nie musisz skakać ani kucać.
- **Enter** — start z menu
- W sklepie Postacie wybieraj postacie strzałkami i kupuj je Enterem.
- Po zderzeniu wybierz **Jeszcze raz** albo naciśnij **R / Enter**.
