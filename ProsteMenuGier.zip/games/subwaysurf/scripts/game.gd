extends Node3D

const LANE_SPACING: float = 3.0
const SEGMENT_LENGTH: float = 24.0
const SEGMENT_COUNT: int = 6
const PLAYER_Z: float = 0.0
const PROGRESS_PATH: String = "user://gliwice_sprint.cfg"
const TRAIN_RAMP_LENGTH: float = 8.0
const TRAIN_RAMP_OFFSET: float = 10.5
const TRAIN_RAMP_ANGLE: float = 0.4115
const TRAIN_CLIMB_DURATION: float = 0.85
const TRAIN_REAR_EXTENT: float = 10.8
const CHARACTER_CATALOG: Array[Dictionary] = [
	{"id": "zsti", "name": "ZSTI RUNNER", "cost": 0, "shirt": "#f4b83f", "trousers": "#263d5b", "description": "Szkolny sprinter z Gliwic.", "power_name": "Sprężysty krok", "power_description": "Wyższy skok pomaga przelatywać nad przeszkodami."},
	{"id": "piast", "name": "PIAST GLIWICE", "cost": 80, "shirt": "#2b6fbb", "trousers": "#e9e9dd", "description": "Niebiesko-czerwony wojownik Piasta.", "power_name": "Piastowska tarcza", "power_description": "Startujesz z tarczą, która chroni przez 12 sekund."},
	{"id": "radiostacja", "name": "RADIO FALA", "cost": 160, "shirt": "#e9eee6", "trousers": "#315c4e", "description": "Biegacz nadający prosto z Radiostacji.", "power_name": "Sygnał zbieracza", "power_description": "Magnes monet działa od początku przez 12 sekund."},
	{"id": "industrial", "name": "NOWE GLIWICE", "cost": 260, "shirt": "#e75f37", "trousers": "#30333a", "description": "Energia przemysłowych Gliwic w jednym stroju.", "power_name": "Fabryczny dopalacz", "power_description": "Podwójny wynik aktywny przez pierwsze 12 sekund."},
	{"id": "zabka", "name": "ŻABKA GLIWICE", "cost": 340, "shirt": "#39a95b", "trousers": "#253f32", "description": "Zielony błysk prosto z gliwickiego osiedla.", "power_name": "Moneta gratis", "power_description": "Każda zebrana moneta daje dodatkową monetę."},
	{"id": "politechnika", "name": "POLITECHNIKA ŚLĄSKA", "cost": 440, "shirt": "#8a4058", "trousers": "#34344c", "description": "Inżynier biegu z Politechniki Śląskiej.", "power_name": "Algorytm punktów", "power_description": "Wynik rośnie o 20% szybciej przez cały bieg."},
	{"id": "szkola", "name": "GLIWICKI UCZEŃ", "cost": 560, "shirt": "#4a79a8", "trousers": "#27354a", "description": "Uczeń, który zna każdy skrót w mieście.", "power_name": "Szybka zmiana pasa", "power_description": "Zmienia pas o połowę szybciej."},
	{"id": "biedronka", "name": "BIEDRONKA", "cost": 700, "shirt": "#d73b37", "trousers": "#30343c", "description": "Czerwony biegacz z najlepszą ofertą.", "power_name": "Łowca monet", "power_description": "Monety przyciągają się z większej odległości."},
]

var state: String = "menu"
var shop_open: bool = false
var lane: int = 1
var player_y: float = 0.0
var jump_velocity: float = 0.0
var is_sliding: bool = false
var run_time: float = 0.0
var score: float = 0.0
var coins: int = 0
var wallet_coins: int = 0
var best_score: int = 0
var speed: float = 10.0
var spawn_timer: float = 0.0
var wave_count: int = 0
var shield_charges: int = 0
var shield_timer: float = 0.0
var character_coin_streak: int = 0
var magnet_timer: float = 0.0
var double_score_timer: float = 0.0
var train_ride_timer: float = 0.0
var train_climb_timer: float = 0.0
var train_ride_distance: float = 0.0
var train_rides: int = 0
var chase_timer: float = 0.0
var near_misses: int = 0
var animation_time: float = 0.0
var slide_blend: float = 0.0
var jump_blend: float = 0.0
var selected_skin: String = "zsti"
var unlocked_skins: Array[String] = ["zsti"]
var shop_index: int = 0
var scenery: Array[Node3D] = []
var entities: Array[Dictionary] = []
var leg_parts: Array[Node3D] = []
var arm_parts: Array[Node3D] = []
var shirt_parts: Array[MeshInstance3D] = []
var trouser_parts: Array[MeshInstance3D] = []

var player_root: Node3D
var player_visual: Node3D
var camera: Camera3D
var hud_score: Label
var hud_coins: Label
var hud_speed: Label
var hud_chase: Label
var start_overlay: ColorRect
var end_overlay: ColorRect
var shop_overlay: ColorRect
var end_result: Label
var menu_wallet: Label
var shop_description: Label
var shop_action_button: Button
var shield_visual: MeshInstance3D
var magnet_visual: Node3D
var teacher_root: Node3D
var teacher_legs: Array[Node3D] = []
var teacher_arms: Array[Node3D] = []
var player_torso: Node3D
var player_head: Node3D
var shop_skin_label: Label
var shop_preview_model: Node3D
var shop_preview_shirt_parts: Array[MeshInstance3D] = []
var shop_preview_trouser_parts: Array[MeshInstance3D] = []
var power_panel: PanelContainer
var powerup_rows: Dictionary = {}


class PowerupIcon extends Control:
	var kind: String = ""

	func _draw() -> void:
		match kind:
			"shield":
				var outline := PackedVector2Array([Vector2(30, 5), Vector2(52, 13), Vector2(49, 39), Vector2(30, 57), Vector2(11, 39), Vector2(8, 13)])
				draw_colored_polygon(outline, Color("#66d9ee"))
				draw_polyline(PackedVector2Array([Vector2(20, 31), Vector2(27, 38), Vector2(41, 22)]), Color.WHITE, 5.0, true)
			"magnet":
				draw_polyline(PackedVector2Array([Vector2(12, 10), Vector2(12, 34), Vector2(18, 47), Vector2(30, 52), Vector2(42, 47), Vector2(48, 34), Vector2(48, 10)]), Color("#f05c7d"), 9.0, true)
				draw_line(Vector2(8, 10), Vector2(20, 10), Color("#5bb8f0"), 7.0, true)
				draw_line(Vector2(40, 10), Vector2(52, 10), Color("#5bb8f0"), 7.0, true)
			"double":
				draw_circle(Vector2(30, 31), 25.0, Color("#a88aff"))
				draw_string(ThemeDB.fallback_font, Vector2(12, 39), "x2", HORIZONTAL_ALIGNMENT_LEFT, -1, 23, Color.WHITE)
			_:
				draw_circle(Vector2(30, 31), 24.0, Color("#f3c24f"))
				draw_string(ThemeDB.fallback_font, Vector2(21, 39), "+", HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color.WHITE)

var mats: Dictionary = {}


func _ready() -> void:
	_create_materials()
	_create_world()
	_create_track()
	_create_distant_radio_tower()
	_create_player()
	_create_camera()
	_create_teacher()
	_create_ui()
	_load_progress()
	_apply_character_skin()
	_set_hud_visible(false)


func _process(delta: float) -> void:
	if shop_open and is_instance_valid(shop_preview_model):
		shop_preview_model.rotation.y = sin(float(Time.get_ticks_msec()) * 0.001) * 0.16
	if state != "running":
		return
	run_time += delta
	speed = minf(10.0 + run_time * 0.14, 22.0)
	shield_timer = maxf(0.0, shield_timer - delta)
	if shield_timer <= 0.0 and shield_charges > 0:
		shield_charges = 0
		shield_visual.visible = false
	magnet_timer = maxf(0.0, magnet_timer - delta)
	double_score_timer = maxf(0.0, double_score_timer - delta)
	var character_score_bonus := 1.2 if selected_skin == "politechnika" else 1.0
	score += speed * delta * 1.5 * character_score_bonus * (2.0 if double_score_timer > 0.0 else 1.0)
	chase_timer = maxf(0.0, chase_timer - delta)
	animation_time += delta * (speed * 0.72)
	spawn_timer -= delta
	if spawn_timer <= 0.0:
		_spawn_wave()
		spawn_timer = maxf(1.85, 2.8 - run_time * 0.008)
	_update_player(delta)
	_move_scenery(delta)
	_move_entities(delta)
	_try_board_train()
	_update_teacher(delta)
	camera.position.x = move_toward(camera.position.x, player_root.position.x * 0.36, delta * 1.6)
	camera.position.y = 5.5 + sin(animation_time) * 0.035
	camera.look_at(Vector3(player_root.position.x * 0.12, 1.1, -6.5), Vector3.UP)
	_update_hud()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var key_event: InputEventKey = event
		if state == "menu" and not shop_open and key_event.keycode == KEY_ENTER:
			_start_game()
			return
		if state == "gameover" and (key_event.keycode == KEY_R or key_event.keycode == KEY_ENTER):
			_start_game()
			return
		if state == "menu" and shop_open and key_event.keycode == KEY_ESCAPE:
			_close_shop()
			return
		if state == "menu" and shop_open:
			match key_event.keycode:
				KEY_LEFT:
					_change_shop_skin(-1)
				KEY_RIGHT:
					_change_shop_skin(1)
				KEY_ENTER:
					_shop_action()
			return
		if state != "running":
			return
		match key_event.keycode:
			KEY_LEFT, KEY_A:
				_change_lane(-1)
			KEY_RIGHT, KEY_D:
				_change_lane(1)
			KEY_UP, KEY_W, KEY_SPACE:
				_jump()


func _create_materials() -> void:
	mats["road"] = _material(Color("#303943"), 0.94)
	mats["line"] = _material(Color("#e8dcae"), 0.7)
	mats["sidewalk"] = _material(Color("#9ea3a1"), 0.9)
	mats["curb"] = _material(Color("#e7e1d4"), 0.9)
	mats["grass"] = _material(Color("#597c53"), 1.0)
	mats["building_a"] = _material(Color("#d6c4a2"), 0.95)
	mats["building_b"] = _material(Color("#aebdc1"), 0.95)
	mats["building_c"] = _material(Color("#c27d54"), 0.95)
	mats["window"] = _material(Color("#88c9d1"), 0.35, 0.0, true)
	mats["metal"] = _material(Color("#515e67"), 0.55, 0.45)
	mats["tower"] = _material(Color("#725a3c"), 0.9)
	mats["shirt"] = _material(Color("#f4b83f"), 0.82)
	mats["shirt_trim"] = _material(Color("#d85036"), 0.8)
	mats["skin"] = _material(Color("#d59a72"), 0.9)
	mats["trousers"] = _material(Color("#263d5b"), 0.85)
	mats["shoe"] = _material(Color("#eff0e7"), 0.75)
	mats["bus"] = _material(Color("#e6bd34"), 0.7)
	mats["tram"] = _material(Color("#c9e4df"), 0.65)
	mats["tram_dark"] = _material(Color("#256174"), 0.6)
	mats["glass"] = _material(Color("#4e9aa7"), 0.3, 0.0, true)
	mats["rubber"] = _material(Color("#20252a"), 0.95)
	mats["barrier"] = _material(Color("#ef623f"), 0.7)
	mats["barrier_white"] = _material(Color("#f2eee0"), 0.7)
	mats["coin"] = _material(Color("#ffd34e"), 0.25, 0.75, true)
	mats["lamp"] = _material(Color("#f5e4b0"), 0.3, 0.0, true)
	mats["sign"] = _material(Color("#28775c"), 0.7)
	mats["store_red"] = _material(Color("#c93432"), 0.65)
	mats["store_green"] = _material(Color("#168349"), 0.65)
	mats["store_blue"] = _material(Color("#315f9a"), 0.65)
	mats["track"] = _material(Color("#78838a"), 0.45, 0.65)
	mats["brick"] = _material(Color("#a95035"), 0.9)
	mats["roof"] = _material(Color("#65585a"), 0.9)
	mats["concrete"] = _material(Color("#ddd4c3"), 0.9)
	mats["crane"] = _material(Color("#d99e38"), 0.7, 0.2)
	mats["construction"] = _material(Color("#f27a36"), 0.8)
	mats["pit"] = _material(Color("#151d24"), 1.0)
	mats["shield_power"] = _material(Color("#77e8fa"), 0.22, 0.55, true)
	mats["magnet_power"] = _material(Color("#ff6681"), 0.2, 0.5, true)
	mats["magnet_north"] = _material(Color("#5bb8f0"), 0.24, 0.35, true)
	mats["magnet_silver"] = _material(Color("#e9eff0"), 0.3, 0.65, true)
	mats["score_power"] = _material(Color("#b596ff"), 0.2, 0.5, true)
	mats["iron"] = _material(Color("#37454f"), 0.42, 0.72)
	mats["wire"] = _material(Color("#66757a"), 0.5, 0.65)
	mats["leaf"] = _material(Color("#4e7952"), 0.9)
	mats["leaf_light"] = _material(Color("#8a9c55"), 0.9)
	mats["bus_a4"] = _material(Color("#e6bd34"), 0.55, 0.08)
	mats["bus_m105"] = _material(Color("#db5645"), 0.55, 0.08)
	mats["bus_59"] = _material(Color("#438e76"), 0.55, 0.08)
	mats["train"] = _material(Color("#266b91"), 0.45, 0.18)
	mats["train_roof"] = _material(Color("#b8c5c5"), 0.56, 0.22)
	mats["teacher_shirt"] = _material(Color("#ece5d4"), 0.85)
	mats["teacher_coat"] = _material(Color("#2f5745"), 0.8)
	mats["teacher_hair"] = _material(Color("#41352f"), 0.9)
	mats["skin_red"] = _material(Color("#c95e48"), 0.85)
	var shield_material := _material(Color("#72dcf2"), 0.18, 0.2, true)
	shield_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shield_material.albedo_color.a = 0.22
	mats["shield_aura"] = shield_material


func _material(color: Color, roughness: float = 0.8, metallic: float = 0.0, emissive: bool = false) -> StandardMaterial3D:
	var result := StandardMaterial3D.new()
	result.albedo_color = color
	result.roughness = roughness
	result.metallic = metallic
	if emissive:
		result.emission_enabled = true
		result.emission = color * 0.35
	return result


func _create_world() -> void:
	var environment_node := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#a9d5e4")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#d7e5ed")
	environment.ambient_light_energy = 0.7
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = Color("#a9d5e4")
	environment.fog_density = 0.006
	environment_node.environment = environment
	add_child(environment_node)

	var sunlight := DirectionalLight3D.new()
	sunlight.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	sunlight.light_color = Color("#fff0d7")
	sunlight.light_energy = 1.25
	sunlight.shadow_enabled = true
	add_child(sunlight)


func _create_track() -> void:
	for index in SEGMENT_COUNT:
		var segment := Node3D.new()
		segment.position.z = -float(index) * SEGMENT_LENGTH
		add_child(segment)
		_build_segment(segment, index)
		scenery.append(segment)


func _build_segment(segment: Node3D, index: int) -> void:
	_make_box(segment, Vector3(9.6, 0.3, SEGMENT_LENGTH), Vector3(0.0, -0.25, 0.0), mats["road"])
	_make_box(segment, Vector3(0.035, 0.035, SEGMENT_LENGTH), Vector3(-1.5, 5.0, 0.0), mats["wire"])
	_make_box(segment, Vector3(0.035, 0.035, SEGMENT_LENGTH), Vector3(1.5, 5.0, 0.0), mats["wire"])
	for side in [-1.0, 1.0]:
		_make_box(segment, Vector3(3.0, 0.22, SEGMENT_LENGTH), Vector3(side * 6.3, -0.21, 0.0), mats["sidewalk"])
		_make_box(segment, Vector3(0.18, 0.34, SEGMENT_LENGTH), Vector3(side * 4.85, -0.18, 0.0), mats["curb"])
		_make_box(segment, Vector3(3.0, 0.12, SEGMENT_LENGTH), Vector3(side * 9.0, -0.37, 0.0), mats["grass"])

	for line_index in 8:
		var z_pos := -10.0 + float(line_index) * 3.0
		for x_pos in [-1.5, 1.5]:
			_make_box(segment, Vector3(0.075, 0.025, 1.25), Vector3(x_pos, -0.075, z_pos), mats["line"])
		_make_box(segment, Vector3(0.09, 0.08, 2.8), Vector3(-0.85, -0.03, z_pos), mats["track"])
		_make_box(segment, Vector3(0.09, 0.08, 2.8), Vector3(0.85, -0.03, z_pos), mats["track"])
		_make_box(segment, Vector3(2.0, 0.07, 0.16), Vector3(0.0, -0.06, z_pos), mats["metal"])

	_build_city_props(segment, index)
	_build_landmark(segment, index)


func _build_city_props(segment: Node3D, index: int) -> void:
	for side in [-1.0, 1.0]:
		var x_pos: float = float(side) * (8.0 + float((index * 3) % 3))
		var building_height := 5.0 + float((index * 7) % 5)
		var building_names := ["building_a", "building_b", "building_c"]
		var building_material: Material = mats[building_names[index % 3]]
		_make_box(segment, Vector3(4.2, building_height, 18.0), Vector3(x_pos, building_height * 0.5 - 0.2, 0.0), building_material)
		for floor_index in 3:
			var window_y := 1.3 + float(floor_index) * 1.8
			for window_offset in [-1.0, 1.0]:
				_make_box(segment, Vector3(0.8, 0.95, 0.08), Vector3(x_pos + window_offset, window_y, 9.05), mats["window"])
		_build_facade_sign(segment, index, side, x_pos, building_height)
		_make_box(segment, Vector3(0.12, 3.7, 0.12), Vector3(side * 6.0, 1.65, -7.0), mats["metal"])
		_make_box(segment, Vector3(0.8, 0.13, 0.22), Vector3(side * 6.0, 3.55, -7.0), mats["lamp"])
		if posmod(index + int(side), 2) == 0:
			_build_street_tree(segment, side * 11.2, -3.0)
			_make_box(segment, Vector3(0.18, 5.0, 0.18), Vector3(side * 5.6, 2.3, 7.0), mats["iron"])
			_make_box(segment, Vector3(3.0, 0.16, 0.16), Vector3(0.0, 4.8, 7.0), mats["iron"])
		if posmod(index + int(side), 2) == 0:
			_build_tram_stop(segment, side * 7.0, -5.2)
		else:
			_build_side_bench(segment, side * 6.9, -5.0)

func _build_landmark(segment: Node3D, index: int) -> void:
	match posmod(index, 8):
		0:
			_build_radio_tower(segment, -12.0, 8.0)
			_make_city_sign(segment, "RADIOSTACJA", 7.1, 2.5, 9.0)
		1:
			_build_market_house(segment, 9.6, 0.0)
			_make_city_sign(segment, "RYNEK • GLIWICE", -7.0, 2.4, 8.8)
		2:
			_build_industrial_crane(segment, 8.0, -4.0)
			_make_city_sign(segment, "NOWE GLIWICE", -7.0, 2.4, 8.8)
		3:
			_build_politechnika(segment, -9.0, 0.0)
			_make_city_sign(segment, "POLITECHNIKA", 7.0, 2.4, 8.8)
		4:
			_build_palm_house(segment, 9.4, 0.0)
			_make_city_sign(segment, "PARK CHOPINA", -7.0, 2.4, 8.8)
		5:
			_build_castle_gate(segment, -9.2, 0.0)
			_make_city_sign(segment, "ZAMEK PIASTOWSKI", 7.0, 2.4, 8.8)
		6:
			_build_train_station(segment, 9.5, 0.0)
			_make_city_sign(segment, "GLIWICE • DWORZEC", -7.0, 2.4, 8.8)
		7:
			_build_arena(segment, -10.0, 0.0)
			_make_city_sign(segment, "ARENA GLIWICE", 7.0, 2.4, 8.8)


func _build_facade_sign(parent: Node3D, segment_index: int, side: float, x_pos: float, building_height: float) -> void:
	var names := ["BIEDRONKA", "ŻABKA", "POLITECHNIKA ŚLĄSKA", "ZSTI GLIWICE", "I LO GLIWICE", "TECHNIKUM GLIWICE"]
	var colors := ["store_red", "store_green", "store_blue", "store_blue", "store_red", "store_green"]
	var sign_index := posmod(segment_index * 2 + int(side > 0.0), names.size())
	var sign_y := minf(building_height - 0.65, 4.0)
	_make_box(parent, Vector3(3.35, 0.72, 0.18), Vector3(x_pos, sign_y, 9.14), mats[colors[sign_index]])
	var sign_label := _make_3d_label(names[sign_index], 21 if sign_index < 2 else 16, Color("#fff8e6"))
	sign_label.position = Vector3(x_pos, sign_y, 9.25)
	parent.add_child(sign_label)


func _build_tram_stop(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(2.5, 0.12, 1.2), Vector3(x_pos, 2.25, z_pos), mats["metal"])
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.08, 2.1, 0.08), Vector3(x_pos + side * 1.15, 1.2, z_pos), mats["metal"])
		_make_box(parent, Vector3(0.06, 1.7, 0.85), Vector3(x_pos + side * 1.12, 1.05, z_pos + 0.15), mats["glass"])
	_make_box(parent, Vector3(1.15, 0.12, 0.42), Vector3(x_pos, 0.75, z_pos + 0.25), mats["roof"])
	_make_box(parent, Vector3(0.76, 0.5, 0.12), Vector3(x_pos, 2.65, z_pos - 0.05), mats["sign"])
	var label := _make_3d_label("GLIWICE", 18, Color("#fff4dc"))
	label.position = Vector3(x_pos, 2.65, z_pos + 0.025)
	parent.add_child(label)


func _build_side_bench(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(1.7, 0.16, 0.44), Vector3(x_pos, 0.72, z_pos), mats["brick"])
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.12, 0.65, 0.12), Vector3(x_pos + side * 0.62, 0.34, z_pos), mats["metal"])


func _build_train_station(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(7.4, 4.1, 6.2), Vector3(x_pos, 1.85, z_pos), mats["concrete"])
	_make_box(parent, Vector3(7.8, 0.32, 6.6), Vector3(x_pos, 4.05, z_pos), mats["roof"])
	_make_box(parent, Vector3(1.0, 1.25, 0.16), Vector3(x_pos, 2.85, z_pos + 3.15), mats["sign"])
	var clock := _make_3d_label("12:08", 20, Color("#fff4dc"))
	clock.position = Vector3(x_pos, 2.85, z_pos + 3.25)
	parent.add_child(clock)
	for index in 4:
		_make_box(parent, Vector3(0.8, 1.2, 0.12), Vector3(x_pos - 2.5 + float(index) * 1.65, 1.8, z_pos + 3.15), mats["window"])


func _build_arena(parent: Node3D, x_pos: float, z_pos: float) -> void:
	var dome := SphereMesh.new()
	dome.radius = 4.2
	dome.height = 3.5
	_make_mesh(parent, dome, Vector3(x_pos, 2.0, z_pos), mats["building_b"])
	_make_box(parent, Vector3(8.0, 0.5, 8.0), Vector3(x_pos, 0.25, z_pos), mats["concrete"])
	_make_box(parent, Vector3(5.8, 0.42, 0.22), Vector3(x_pos, 2.0, z_pos + 4.0), mats["sign"])
	var arena_label := _make_3d_label("ARENA", 26, Color("#fff4dc"))
	arena_label.position = Vector3(x_pos, 2.0, z_pos + 4.15)
	parent.add_child(arena_label)


func _create_distant_radio_tower() -> void:
	var tower_root := Node3D.new()
	tower_root.name = "DistantGliwiceRadioTower"
	tower_root.position = Vector3(0.0, 0.0, -185.0)
	tower_root.scale = Vector3(3.2, 3.2, 3.2)
	add_child(tower_root)
	_build_radio_tower(tower_root, 0.0, 0.0)
	var skyline_sign := _make_3d_label("RADIOSTACJA GLIWICE", 42, Color("#fff0bb"))
	skyline_sign.position = Vector3(0.0, 17.0, 0.0)
	skyline_sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tower_root.add_child(skyline_sign)


func _build_street_tree(parent: Node3D, x_pos: float, z_pos: float) -> void:
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.17
	trunk.bottom_radius = 0.26
	trunk.height = 2.4
	_make_mesh(parent, trunk, Vector3(x_pos, 1.0, z_pos), mats["brick"])
	for branch in 5:
		var angle := float(branch) * TAU / 5.0
		var leaves := SphereMesh.new()
		leaves.radius = 0.9 if branch % 2 == 0 else 0.72
		leaves.height = leaves.radius * 1.6
		_make_mesh(parent, leaves, Vector3(x_pos + cos(angle) * 0.48, 2.55 + float(branch % 2) * 0.28, z_pos + sin(angle) * 0.48), mats["leaf"] if branch % 2 == 0 else mats["leaf_light"])


func _make_city_sign(parent: Node3D, text: String, x_pos: float, y_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(3.4, 0.72, 0.2), Vector3(x_pos, y_pos, z_pos), mats["sign"])
	var label := _make_3d_label(text, 30, Color("#fff3cf"))
	label.position = Vector3(x_pos, y_pos, z_pos + 0.13)
	parent.add_child(label)


func _build_market_house(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(5.2, 5.0, 5.2), Vector3(x_pos, 2.3, z_pos), mats["building_c"])
	_make_box(parent, Vector3(5.6, 0.28, 5.6), Vector3(x_pos, 4.85, z_pos), mats["roof"])
	_make_box(parent, Vector3(2.0, 2.5, 0.28), Vector3(x_pos, 6.2, z_pos), mats["brick"])
	_make_box(parent, Vector3(2.15, 0.2, 0.34), Vector3(x_pos, 7.55, z_pos), mats["roof"])
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.75, 1.1, 0.1), Vector3(x_pos + side * 1.35, 2.8, z_pos + 2.66), mats["window"])


func _build_industrial_crane(parent: Node3D, x_pos: float, z_pos: float) -> void:
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.35, 8.0, 0.35), Vector3(x_pos + side * 3.0, 3.8, z_pos), mats["crane"])
		_make_box(parent, Vector3(0.55, 0.22, 1.8), Vector3(x_pos + side * 3.0, 0.3, z_pos), mats["crane"])
	_make_box(parent, Vector3(7.0, 0.4, 0.5), Vector3(x_pos, 7.8, z_pos), mats["crane"])
	_make_box(parent, Vector3(0.2, 3.5, 0.2), Vector3(x_pos + 1.4, 5.8, z_pos), mats["metal"])
	_make_box(parent, Vector3(2.4, 1.1, 1.1), Vector3(x_pos + 1.4, 3.65, z_pos), mats["construction"])


func _build_politechnika(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(6.0, 4.8, 8.0), Vector3(x_pos, 2.2, z_pos), mats["concrete"])
	_make_box(parent, Vector3(6.5, 0.3, 8.4), Vector3(x_pos, 4.7, z_pos), mats["roof"])
	_make_box(parent, Vector3(0.28, 3.4, 0.35), Vector3(x_pos, 6.4, z_pos), mats["roof"])
	_make_box(parent, Vector3(4.9, 0.18, 0.25), Vector3(x_pos, 5.8, z_pos), mats["roof"])
	for floor_index in 2:
		for window_index in 4:
			_make_box(parent, Vector3(0.7, 0.75, 0.1), Vector3(x_pos - 1.8 + float(window_index) * 1.2, 1.6 + float(floor_index) * 1.5, z_pos + 4.06), mats["window"])


func _build_palm_house(parent: Node3D, x_pos: float, z_pos: float) -> void:
	_make_box(parent, Vector3(4.8, 3.8, 6.4), Vector3(x_pos, 1.8, z_pos), mats["glass"])
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.28, 5.0, 0.28), Vector3(x_pos + side * 2.5, 2.4, z_pos), mats["metal"])
		_make_box(parent, Vector3(0.16, 3.8, 0.16), Vector3(x_pos + side * 1.2, 1.9, z_pos + side * 0.5), mats["grass"])
	_make_box(parent, Vector3(2.5, 1.3, 3.0), Vector3(x_pos, 4.3, z_pos), mats["glass"], Vector3(0.0, 0.0, 0.35))


func _build_castle_gate(parent: Node3D, x_pos: float, z_pos: float) -> void:
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(1.7, 5.5, 2.0), Vector3(x_pos + side * 1.9, 2.5, z_pos), mats["brick"])
		_make_box(parent, Vector3(2.0, 0.35, 2.25), Vector3(x_pos + side * 1.9, 5.3, z_pos), mats["roof"])
	_make_box(parent, Vector3(2.2, 0.8, 2.1), Vector3(x_pos, 4.85, z_pos), mats["brick"])
	_make_box(parent, Vector3(1.1, 2.7, 0.18), Vector3(x_pos, 1.25, z_pos + 1.05), mats["roof"])


func _build_radio_tower(parent: Node3D, x_pos: float, z_pos: float) -> void:
	var tower_root := Node3D.new()
	tower_root.position = Vector3(x_pos, 0.0, z_pos)
	parent.add_child(tower_root)
	var tower_height := 15.0
	var level_count := 9
	var level_step := tower_height / float(level_count)
	for level in range(level_count + 1):
		var progress := float(level) / float(level_count)
		var half_width := lerpf(3.1, 0.62, progress)
		var y_pos := float(level) * level_step
		for side in [-1.0, 1.0]:
			_make_box(tower_root, Vector3(half_width * 2.0, 0.13, 0.13), Vector3(0.0, y_pos, side * half_width), mats["tower"])
			_make_box(tower_root, Vector3(0.13, 0.13, half_width * 2.0), Vector3(side * half_width, y_pos, 0.0), mats["tower"])
		if level == level_count:
			continue
		var next_width := lerpf(3.1, 0.62, float(level + 1) / float(level_count))
		var mid_y := y_pos + level_step * 0.5
		var mid_width := (half_width + next_width) * 0.5
		var half_dx := (half_width - next_width) * 0.5
		var brace_length := sqrt(level_step * level_step + half_dx * half_dx)
		var brace_angle := atan(half_dx / level_step)
		for x_side in [-1.0, 1.0]:
			for z_side in [-1.0, 1.0]:
				_make_box(tower_root, Vector3(0.2, brace_length, 0.2), Vector3(x_side * mid_width, mid_y, z_side * mid_width), mats["tower"], Vector3(0.0, 0.0, -x_side * brace_angle))
				_make_box(tower_root, Vector3(0.2, brace_length, 0.2), Vector3(x_side * mid_width, mid_y, z_side * mid_width), mats["tower"], Vector3(-z_side * brace_angle, 0.0, 0.0))
		for z_side in [-1.0, 1.0]:
			_make_box(tower_root, Vector3(half_width * 1.65, 0.1, 0.1), Vector3(0.0, mid_y, z_side * mid_width), mats["tower"], Vector3(0.0, 0.0, brace_angle))
		for x_side in [-1.0, 1.0]:
			_make_box(tower_root, Vector3(0.1, 0.1, half_width * 1.65), Vector3(x_side * mid_width, mid_y, 0.0), mats["tower"], Vector3(brace_angle, 0.0, 0.0))
	_make_box(tower_root, Vector3(0.18, 2.8, 0.18), Vector3(0.0, 16.35, 0.0), mats["metal"])


func _create_player() -> void:
	player_root = Node3D.new()
	player_root.position.z = PLAYER_Z
	add_child(player_root)
	player_visual = Node3D.new()
	player_root.add_child(player_visual)

	player_torso = Node3D.new()
	player_torso.position.y = 1.18
	player_visual.add_child(player_torso)
	shirt_parts.append(_make_box(player_torso, Vector3(0.76, 0.9, 0.43), Vector3.ZERO, mats["shirt"]))
	_make_box(player_torso, Vector3(0.77, 0.12, 0.45), Vector3(0.0, -0.43, 0.0), mats["shirt_trim"])
	var chest_logo := _make_3d_label("ZSTI", 23, Color("#18354a"))
	chest_logo.position = Vector3(0.0, -0.04, 0.225)
	player_torso.add_child(chest_logo)

	player_head = Node3D.new()
	player_head.position = Vector3(0.0, 0.69, 0.0)
	player_torso.add_child(player_head)
	var head := SphereMesh.new()
	head.radius = 0.25
	head.height = 0.5
	_make_mesh(player_head, head, Vector3(0.0, 0.0, 0.0), mats["skin"])
	var hair := _make_box(player_head, Vector3(0.48, 0.14, 0.49), Vector3(0.0, 0.16, -0.025), mats["teacher_hair"])
	hair.rotation.x = -0.12
	_make_box(player_head, Vector3(0.11, 0.09, 0.06), Vector3(-0.085, 0.015, 0.229), mats["metal"])
	_make_box(player_head, Vector3(0.11, 0.09, 0.06), Vector3(0.085, 0.015, 0.229), mats["metal"])
	trouser_parts.append(_make_box(player_torso, Vector3(0.5, 0.12, 0.5), Vector3(0.0, 0.52, 0.0), mats["trousers"]))

	for side in [-1.0, 1.0]:
		var leg_pivot := Node3D.new()
		leg_pivot.position = Vector3(side * 0.2, 0.72, 0.0)
		player_visual.add_child(leg_pivot)
		trouser_parts.append(_make_box(leg_pivot, Vector3(0.27, 0.58, 0.32), Vector3(0.0, -0.27, 0.0), mats["trousers"]))
		_make_box(leg_pivot, Vector3(0.34, 0.15, 0.46), Vector3(0.0, -0.58, 0.09), mats["shoe"])
		leg_parts.append(leg_pivot)
		var arm_pivot := Node3D.new()
		arm_pivot.position = Vector3(side * 0.49, 1.48, 0.0)
		player_visual.add_child(arm_pivot)
		shirt_parts.append(_make_box(arm_pivot, Vector3(0.24, 0.66, 0.3), Vector3(0.0, -0.3, 0.0), mats["shirt"]))
		_make_mesh(arm_pivot, _sphere_mesh(0.14), Vector3(0.0, -0.64, 0.0), mats["skin"])
		_make_box(arm_pivot, Vector3(0.25, 0.1, 0.31), Vector3(0.0, -0.53, 0.0), mats["shirt_trim"])

	var back_text := _make_3d_label("ZSTI GLIWICE", 44, Color("#18354a"))
	back_text.position = Vector3(0.0, -0.02, -0.225)
	back_text.rotation.y = PI
	player_torso.add_child(back_text)
	var aura_mesh := SphereMesh.new()
	aura_mesh.radius = 1.2
	aura_mesh.height = 2.5
	shield_visual = _make_mesh(player_visual, aura_mesh, Vector3(0.0, 1.1, 0.0), mats["shield_aura"])
	shield_visual.scale = Vector3(0.65, 0.9, 0.5)
	shield_visual.visible = false
	magnet_visual = Node3D.new()
	magnet_visual.position = Vector3(0.0, 0.12, 0.0)
	player_visual.add_child(magnet_visual)
	_make_box(magnet_visual, Vector3(0.16, 0.72, 0.16), Vector3(-0.27, 0.0, 0.0), mats["magnet_power"])
	_make_box(magnet_visual, Vector3(0.16, 0.72, 0.16), Vector3(0.27, 0.0, 0.0), mats["magnet_north"])
	_make_box(magnet_visual, Vector3(0.56, 0.16, 0.16), Vector3(0.0, -0.28, 0.0), mats["magnet_power"])
	_make_box(magnet_visual, Vector3(0.22, 0.12, 0.18), Vector3(-0.27, 0.39, 0.0), mats["magnet_silver"])
	_make_box(magnet_visual, Vector3(0.22, 0.12, 0.18), Vector3(0.27, 0.39, 0.0), mats["magnet_silver"])
	magnet_visual.visible = false


func _sphere_mesh(radius: float) -> SphereMesh:
	var sphere := SphereMesh.new()
	sphere.radius = radius
	sphere.height = radius * 2.0
	return sphere


func _create_camera() -> void:
	camera = Camera3D.new()
	camera.position = Vector3(0.0, 5.5, 10.5)
	add_child(camera)
	camera.look_at(Vector3(0.0, 1.1, -6.5), Vector3.UP)
	camera.fov = 67.0
	camera.current = true


func _create_teacher() -> void:
	teacher_root = Node3D.new()
	teacher_root.visible = false
	add_child(teacher_root)
	teacher_root.rotation.y = PI
	_make_box(teacher_root, Vector3(0.82, 0.92, 0.42), Vector3(0.0, 1.2, 0.0), mats["teacher_coat"])
	_make_box(teacher_root, Vector3(0.58, 0.18, 0.46), Vector3(0.0, 1.69, 0.0), mats["teacher_shirt"])
	_make_mesh(teacher_root, _sphere_mesh(0.27), Vector3(0.0, 1.92, 0.0), mats["skin"])
	var label := _make_3d_label("PAN PROCESOR", 30, Color("#fff4dc"))
	label.position = Vector3(0.0, 2.55, 0.0)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	teacher_root.add_child(label)
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.22, 0.78, 0.0)
		teacher_root.add_child(leg)
		_make_box(leg, Vector3(0.29, 0.68, 0.33), Vector3(0.0, -0.3, 0.0), mats["teacher_coat"])
		_make_box(leg, Vector3(0.34, 0.16, 0.43), Vector3(0.0, -0.63, 0.08), mats["shoe"])
		teacher_legs.append(leg)
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.5, 1.48, 0.0)
		teacher_root.add_child(arm)
		_make_box(arm, Vector3(0.25, 0.7, 0.3), Vector3(0.0, -0.3, 0.0), mats["teacher_coat"])
		_make_mesh(arm, _sphere_mesh(0.14), Vector3(0.0, -0.64, 0.0), mats["skin"])
		teacher_arms.append(arm)


func _create_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_PASS
	canvas.add_child(root)

	hud_score = _make_ui_label(root, "WYNIK  0", Vector2(24, 18), Vector2(280, 58), 28, HORIZONTAL_ALIGNMENT_LEFT)
	hud_coins = _make_ui_label(root, "MONETY  0", Vector2(24, 64), Vector2(230, 42), 21, HORIZONTAL_ALIGNMENT_LEFT)
	hud_speed = _make_ui_label(root, "TEMPO  10", Vector2(24, 18), Vector2(196, 45), 20, HORIZONTAL_ALIGNMENT_RIGHT)
	hud_speed.anchor_left = 1.0
	hud_speed.anchor_right = 1.0
	hud_speed.offset_left = -220.0
	hud_speed.offset_right = -24.0
	hud_speed.offset_top = 112.0
	hud_speed.offset_bottom = 152.0
	hud_score.anchor_left = 1.0
	hud_score.anchor_right = 1.0
	hud_score.offset_left = -320.0
	hud_score.offset_right = -24.0
	hud_score.offset_top = 12.0
	hud_score.offset_bottom = 58.0
	hud_coins.anchor_left = 1.0
	hud_coins.anchor_right = 1.0
	hud_coins.offset_left = -220.0
	hud_coins.offset_right = -24.0
	hud_coins.offset_top = 62.0
	hud_coins.offset_bottom = 100.0
	hud_chase = _make_ui_label(root, "", Vector2(0, 122), Vector2(0, 38), 22, HORIZONTAL_ALIGNMENT_CENTER, true)
	hud_chase.add_theme_color_override("font_color", Color("#ffb64c"))
	_create_powerup_hud(root)

	start_overlay = _make_overlay(root)
	_make_ui_label(start_overlay, "GLIWICE", Vector2(0, 62), Vector2(0, 44), 25, HORIZONTAL_ALIGNMENT_CENTER, true)
	_make_ui_label(start_overlay, "SPRINT", Vector2(0, 104), Vector2(0, 88), 58, HORIZONTAL_ALIGNMENT_CENTER, true)
	_make_ui_label(start_overlay, "SZLAK RADIOSTACJI  /  EDYCJA MIEJSKA", Vector2(0, 190), Vector2(0, 38), 20, HORIZONTAL_ALIGNMENT_CENTER, true)
	_make_ui_label(start_overlay, "Tramwaje. Autobusy. Gliwickie ulice.\nWskocz na rampę i przemknij nad pociągiem!", Vector2(0, 230), Vector2(0, 58), 19, HORIZONTAL_ALIGNMENT_CENTER, true)
	menu_wallet = _make_ui_label(start_overlay, "PORTFEL: 0   •   REKORD: 0", Vector2(0, 292), Vector2(0, 36), 19, HORIZONTAL_ALIGNMENT_CENTER, true)
	var start_button := _make_ui_button(start_overlay, "ROZPOCZNIJ BIEG", Vector2(0.5, 0.67), Vector2(272, 62))
	start_button.pressed.connect(_start_game)
	var shop_button := _make_ui_button(start_overlay, "POSTACIE", Vector2(0.5, 0.78), Vector2(272, 52))
	shop_button.pressed.connect(_open_shop)
	var instructions := _make_ui_label(start_overlay, "A / D lub ← / → — zmiana pasa  •  W / SPACJA / ↑ — skok  •  S / ↓ — kucanie pod niskimi belkami\nRampa sama prowadzi na dach pociągu; po nim możesz biec i zmieniać pas. Zbieraj monety, unikaj autobusów i korzystaj z mocy!", Vector2(0, 0), Vector2(0, 88), 15, HORIZONTAL_ALIGNMENT_CENTER, true)
	instructions.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	instructions.offset_top = -100.0
	instructions.offset_bottom = -10.0

	shop_overlay = _make_overlay(root)
	shop_overlay.visible = false
	_make_ui_label(shop_overlay, "POSTACIE", Vector2(0, 76), Vector2(0, 62), 37, HORIZONTAL_ALIGNMENT_CENTER, true)
	shop_skin_label = _make_ui_label(shop_overlay, "", Vector2(0, 146), Vector2(0, 48), 25, HORIZONTAL_ALIGNMENT_CENTER, true)
	_create_shop_preview(shop_overlay)
	var previous_skin := _make_ui_button(shop_overlay, "◀", Vector2(0.5, 0.48), Vector2(68, 58))
	previous_skin.anchor_left = 0.5
	previous_skin.anchor_right = 0.5
	previous_skin.offset_left = -184.0
	previous_skin.offset_right = -116.0
	previous_skin.pressed.connect(_change_shop_skin.bind(-1))
	var next_skin := _make_ui_button(shop_overlay, "▶", Vector2(0.5, 0.48), Vector2(68, 58))
	next_skin.offset_left = 116.0
	next_skin.offset_right = 184.0
	next_skin.pressed.connect(_change_shop_skin.bind(1))
	shop_description = _make_ui_label(shop_overlay, "", Vector2(0, 365), Vector2(0, 80), 17, HORIZONTAL_ALIGNMENT_CENTER, true)
	shop_description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	shop_action_button = _make_ui_button(shop_overlay, "KUP POSTAĆ", Vector2(0.5, 0.75), Vector2(250, 58))
	shop_action_button.pressed.connect(_shop_action)
	var close_shop := _make_ui_button(shop_overlay, "WRÓĆ DO MENU", Vector2(0.5, 0.87), Vector2(250, 50))
	close_shop.pressed.connect(_close_shop)

	end_overlay = _make_overlay(root)
	end_overlay.visible = false
	_make_ui_label(end_overlay, "KONIEC BIEGU", Vector2(0, 165), Vector2(0, 66), 40, HORIZONTAL_ALIGNMENT_CENTER, true)
	end_result = _make_ui_label(end_overlay, "Wynik: 0", Vector2(0, 235), Vector2(0, 46), 25, HORIZONTAL_ALIGNMENT_CENTER, true)
	var restart_button := _make_ui_button(end_overlay, "JESZCZE RAZ", Vector2(0.5, 0.62), Vector2(240, 58))
	restart_button.pressed.connect(_start_game)
	var garage_button := _make_ui_button(end_overlay, "MENU / POSTACIE", Vector2(0.5, 0.75), Vector2(240, 52))
	garage_button.pressed.connect(_return_to_menu)


func _create_powerup_hud(parent: Control) -> void:
	power_panel = PanelContainer.new()
	power_panel.anchor_left = 1.0
	power_panel.anchor_right = 1.0
	power_panel.offset_left = -300.0
	power_panel.offset_right = -20.0
	power_panel.offset_top = 158.0
	power_panel.offset_bottom = 344.0
	power_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.1, 0.15, 0.88)
	style.border_color = Color("#62cdb9")
	style.set_border_width_all(2)
	style.set_corner_radius_all(14)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 8.0
	style.content_margin_bottom = 8.0
	power_panel.add_theme_stylebox_override("panel", style)
	parent.add_child(power_panel)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 3)
	power_panel.add_child(rows)
	for kind in ["shield", "magnet", "double"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		rows.add_child(row)
		var icon := PowerupIcon.new()
		icon.kind = kind
		icon.custom_minimum_size = Vector2(44.0, 44.0)
		row.add_child(icon)
		var text_column := VBoxContainer.new()
		text_column.alignment = BoxContainer.ALIGNMENT_CENTER
		row.add_child(text_column)
		var name_label := Label.new()
		name_label.add_theme_font_size_override("font_size", 21)
		name_label.add_theme_color_override("font_color", Color("#fff4dc"))
		text_column.add_child(name_label)
		var timer_label := Label.new()
		timer_label.add_theme_font_size_override("font_size", 14)
		timer_label.add_theme_color_override("font_color", Color("#aee8d6"))
		text_column.add_child(timer_label)
		powerup_rows[kind] = {"icon": icon, "name": name_label, "timer": timer_label, "row": row}
	power_panel.visible = false


func _create_shop_preview(parent: Control) -> void:
	var preview_container := SubViewportContainer.new()
	preview_container.anchor_left = 0.5
	preview_container.anchor_right = 0.5
	preview_container.offset_left = -90.0
	preview_container.offset_right = 90.0
	preview_container.offset_top = 205.0
	preview_container.offset_bottom = 350.0
	preview_container.stretch = true
	preview_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(preview_container)

	var viewport := SubViewport.new()
	viewport.size = Vector2i(256, 256)
	viewport.transparent_bg = true
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	preview_container.add_child(viewport)

	var preview_world := Node3D.new()
	viewport.add_child(preview_world)
	var preview_environment_node := WorldEnvironment.new()
	var preview_environment := Environment.new()
	preview_environment.background_mode = Environment.BG_COLOR
	preview_environment.background_color = Color(0.0, 0.0, 0.0, 0.0)
	preview_environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	preview_environment.ambient_light_color = Color("#e1e9ef")
	preview_environment.ambient_light_energy = 0.8
	preview_environment_node.environment = preview_environment
	preview_world.add_child(preview_environment_node)
	var preview_camera := Camera3D.new()
	preview_camera.position = Vector3(0.0, 1.55, 5.0)
	preview_camera.fov = 38.0
	preview_world.add_child(preview_camera)
	preview_camera.look_at(Vector3(0.0, 1.15, 0.0), Vector3.UP)
	preview_camera.current = true
	var preview_light := DirectionalLight3D.new()
	preview_light.rotation_degrees = Vector3(-28.0, -22.0, 0.0)
	preview_light.light_energy = 1.4
	preview_world.add_child(preview_light)

	shop_preview_model = Node3D.new()
	preview_world.add_child(shop_preview_model)
	shop_preview_shirt_parts.append(_make_box(shop_preview_model, Vector3(0.78, 0.86, 0.46), Vector3(0.0, 1.35, 0.0), mats["shirt"]))
	shop_preview_trouser_parts.append(_make_box(shop_preview_model, Vector3(0.58, 0.2, 0.44), Vector3(0.0, 0.82, 0.0), mats["trousers"]))
	_make_mesh(shop_preview_model, _sphere_mesh(0.26), Vector3(0.0, 2.08, 0.0), mats["skin"])
	_make_box(shop_preview_model, Vector3(0.48, 0.14, 0.48), Vector3(0.0, 2.28, -0.025), mats["teacher_hair"])
	for side in [-1.0, 1.0]:
		shop_preview_trouser_parts.append(_make_box(shop_preview_model, Vector3(0.25, 0.67, 0.32), Vector3(side * 0.18, 0.38, 0.0), mats["trousers"]))
		shop_preview_shirt_parts.append(_make_box(shop_preview_model, Vector3(0.24, 0.62, 0.3), Vector3(side * 0.5, 1.38, 0.0), mats["shirt"]))
		_make_box(shop_preview_model, Vector3(0.32, 0.14, 0.42), Vector3(side * 0.18, 0.0, 0.08), mats["shoe"])


func _make_overlay(parent: Control) -> ColorRect:
	var overlay := ColorRect.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.color = Color(0.04, 0.09, 0.13, 0.86)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.add_child(overlay)
	return overlay


func _make_ui_label(parent: Control, text: String, position: Vector2, size: Vector2, font_size: int, alignment: HorizontalAlignment, centered: bool = false) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("#fff4dc"))
	label.add_theme_color_override("font_shadow_color", Color(0.05, 0.08, 0.1, 0.8))
	label.add_theme_constant_override("shadow_offset_x", 2)
	label.add_theme_constant_override("shadow_offset_y", 2)
	label.horizontal_alignment = alignment
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	if centered:
		label.anchor_left = 0.0
		label.anchor_right = 1.0
		label.anchor_top = 0.0
		label.anchor_bottom = 0.0
		label.offset_left = position.x
		label.offset_top = position.y
		label.offset_right = -position.x
		label.offset_bottom = position.y + size.y
	else:
		label.position = position
		label.size = size
	parent.add_child(label)
	return label


func _make_ui_button(parent: Control, text: String, anchor: Vector2, button_size: Vector2) -> Button:
	var button := Button.new()
	button.text = text
	button.anchor_left = 0.5
	button.anchor_right = 0.5
	button.anchor_top = anchor.y
	button.anchor_bottom = anchor.y
	button.offset_left = -button_size.x * 0.5
	button.offset_right = button_size.x * 0.5
	button.offset_top = -button_size.y * 0.5
	button.offset_bottom = button_size.y * 0.5
	button.add_theme_font_size_override("font_size", 22)
	button.add_theme_color_override("font_color", Color("#fff4dc"))
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color("#fff4dc"))
	var normal_style := StyleBoxFlat.new()
	normal_style.bg_color = Color("#256b66")
	normal_style.border_color = Color("#77cfb1")
	normal_style.set_border_width_all(2)
	normal_style.set_corner_radius_all(14)
	var hover_style := StyleBoxFlat.new()
	hover_style.bg_color = Color("#328a7c")
	hover_style.border_color = Color("#c5f0cb")
	hover_style.set_border_width_all(2)
	hover_style.set_corner_radius_all(14)
	var pressed_style := StyleBoxFlat.new()
	pressed_style.bg_color = Color("#194b4a")
	pressed_style.border_color = Color("#77cfb1")
	pressed_style.set_border_width_all(2)
	pressed_style.set_corner_radius_all(14)
	button.add_theme_stylebox_override("normal", normal_style)
	button.add_theme_stylebox_override("hover", hover_style)
	button.add_theme_stylebox_override("pressed", pressed_style)
	parent.add_child(button)
	return button


func _load_progress() -> void:
	var save := ConfigFile.new()
	var error := save.load(PROGRESS_PATH)
	if error != OK and error != ERR_FILE_NOT_FOUND:
		push_warning("Nie można wczytać zapisu gry: %s" % error_string(error))
	if error == OK:
		wallet_coins = int(save.get_value("progress", "coins", 0))
		best_score = int(save.get_value("progress", "best_score", 0))
		var loaded_skins: Variant = save.get_value("progress", "unlocked_skins", ["zsti"])
		if loaded_skins is Array:
			for skin_id in loaded_skins:
				if skin_id is String and _find_skin(String(skin_id)) >= 0 and not unlocked_skins.has(String(skin_id)):
					unlocked_skins.append(String(skin_id))
		var saved_selection := String(save.get_value("progress", "selected_skin", "zsti"))
		if unlocked_skins.has(saved_selection):
			selected_skin = saved_selection
	menu_wallet.text = "PORTFEL: %d   •   REKORD: %d" % [wallet_coins, best_score]


func _save_progress() -> void:
	var save := ConfigFile.new()
	save.set_value("progress", "coins", wallet_coins)
	save.set_value("progress", "best_score", best_score)
	save.set_value("progress", "unlocked_skins", unlocked_skins)
	save.set_value("progress", "selected_skin", selected_skin)
	var error := save.save(PROGRESS_PATH)
	if error != OK:
		push_warning("Nie można zapisać postępu gry: %s" % error_string(error))
	if is_instance_valid(menu_wallet):
		menu_wallet.text = "PORTFEL: %d   •   REKORD: %d" % [wallet_coins, best_score]


func _find_skin(skin_id: String) -> int:
	for index in CHARACTER_CATALOG.size():
		if String(CHARACTER_CATALOG[index]["id"]) == skin_id:
			return index
	return -1


func _apply_character_skin() -> void:
	var skin_index := _find_skin(selected_skin)
	if skin_index < 0:
		selected_skin = "zsti"
		skin_index = 0
	var skin: Dictionary = CHARACTER_CATALOG[skin_index]
	var shirt_material := _material(Color(String(skin["shirt"])), 0.78)
	var trouser_material := _material(Color(String(skin["trousers"])), 0.84)
	for part in shirt_parts:
		part.material_override = shirt_material
	for part in trouser_parts:
		part.material_override = trouser_material


func _open_shop() -> void:
	end_overlay.visible = false
	shop_open = true
	start_overlay.visible = false
	shop_overlay.visible = true
	shop_index = maxi(0, _find_skin(selected_skin))
	_update_shop()


func _close_shop() -> void:
	shop_open = false
	shop_overlay.visible = false
	start_overlay.visible = true


func _return_to_menu() -> void:
	state = "menu"
	chase_timer = 0.0
	teacher_root.visible = false
	end_overlay.visible = false
	start_overlay.visible = true
	_open_shop()


func _change_shop_skin(direction: int) -> void:
	shop_index = posmod(shop_index + direction, CHARACTER_CATALOG.size())
	_update_shop()


func _update_shop() -> void:
	var skin: Dictionary = CHARACTER_CATALOG[shop_index]
	var skin_id := String(skin["id"])
	var unlocked := unlocked_skins.has(skin_id)
	var is_selected := selected_skin == skin_id
	shop_skin_label.text = String(skin["name"])
	shop_description.text = "%s\nSUPERMOC: %s — %s\nMONETY: %d    •    POSTACIE: %d/%d" % [
		String(skin["description"]),
		String(skin["power_name"]),
		String(skin["power_description"]),
		wallet_coins,
		unlocked_skins.size(),
		CHARACTER_CATALOG.size()
	]
	var shirt_material := _material(Color(String(skin["shirt"])), 0.78)
	var trouser_material := _material(Color(String(skin["trousers"])), 0.84)
	for part in shop_preview_shirt_parts:
		part.material_override = shirt_material
	for part in shop_preview_trouser_parts:
		part.material_override = trouser_material
	if is_selected:
		shop_action_button.text = "AKTYWNA POSTAĆ"
		shop_action_button.disabled = true
	elif unlocked:
		shop_action_button.text = "WYBIERZ POSTAĆ"
		shop_action_button.disabled = false
	else:
		shop_action_button.text = "KUP POSTAĆ • %d MONET" % int(skin["cost"])
		shop_action_button.disabled = wallet_coins < int(skin["cost"])


func _shop_action() -> void:
	var skin: Dictionary = CHARACTER_CATALOG[shop_index]
	var skin_id := String(skin["id"])
	if unlocked_skins.has(skin_id):
		selected_skin = skin_id
	else:
		var cost := int(skin["cost"])
		if wallet_coins < cost:
			return
		wallet_coins -= cost
		unlocked_skins.append(skin_id)
		selected_skin = skin_id
	_save_progress()
	_apply_character_skin()
	_update_shop()


func _set_hud_visible(visible: bool) -> void:
	hud_score.visible = visible
	hud_coins.visible = visible
	hud_speed.visible = visible
	hud_chase.visible = visible and chase_timer > 0.0
	power_panel.visible = visible and (shield_charges > 0 or magnet_timer > 0.0 or double_score_timer > 0.0)


func _start_game() -> void:
	for entity in entities:
		var node: Node3D = entity["node"]
		node.queue_free()
	entities.clear()
	shop_open = false
	shop_overlay.visible = false
	run_time = 0.0
	score = 0.0
	coins = 0
	character_coin_streak = 0
	speed = 10.0
	spawn_timer = 0.8
	wave_count = 0
	train_rides = 0
	shield_charges = 0
	shield_timer = 0.0
	magnet_timer = 0.0
	double_score_timer = 0.0
	train_ride_timer = 0.0
	train_climb_timer = 0.0
	chase_timer = 0.0
	near_misses = 0
	animation_time = 0.0
	slide_blend = 0.0
	jump_blend = 0.0
	lane = 1
	player_root.position = Vector3(0.0, 0.0, PLAYER_Z)
	player_y = 0.0
	jump_velocity = 0.0
	is_sliding = false
	player_visual.scale.y = 1.0
	shield_visual.visible = false
	magnet_visual.visible = false
	match selected_skin:
		"piast":
			shield_charges = 1
			shield_timer = 12.0
			shield_visual.visible = true
		"radiostacja":
			magnet_timer = 12.0
			magnet_visual.visible = true
		"industrial":
			double_score_timer = 12.0
	teacher_root.visible = false
	player_root.position = Vector3(0.0, 0.0, PLAYER_Z)
	_apply_character_skin()
	state = "running"
	start_overlay.visible = false
	end_overlay.visible = false
	_set_hud_visible(true)
	_update_hud()


func _change_lane(direction: int) -> void:
	if state == "running":
		lane = clampi(lane + direction, 0, 2)


func _jump() -> void:
	if state != "running" or player_y > 0.01 or is_sliding:
		return
	if _try_board_train():
		return
	jump_velocity = 8.8 if selected_skin == "zsti" else 7.6


func _update_player(delta: float) -> void:
	var target_x := float(lane - 1) * LANE_SPACING
	var lane_speed := 18.0 if selected_skin == "szkola" else 12.0
	player_root.position.x = move_toward(player_root.position.x, target_x, lane_speed * delta)
	if train_ride_timer > 0.0:
		train_ride_distance = maxf(0.0, train_ride_distance - speed * delta)
		train_ride_timer = train_ride_distance / maxf(speed, 0.1)
		if train_climb_timer > 0.0:
			train_climb_timer = maxf(0.0, train_climb_timer - delta)
			var climb_progress := 1.0 - train_climb_timer / TRAIN_CLIMB_DURATION
			player_y = 3.35 * smoothstep(0.0, 1.0, climb_progress)
		else:
			player_y = 3.35
		jump_velocity = 0.0
		if train_ride_timer <= 0.0:
			train_climb_timer = 0.0
			train_ride_distance = 0.0
			jump_velocity = 0.0
	elif player_y > 0.0 or jump_velocity > 0.0:
		player_y += jump_velocity * delta
		jump_velocity -= 19.0 * delta
		if player_y <= 0.0:
			player_y = 0.0
			jump_velocity = 0.0
	else:
		player_y = 0.0
		jump_velocity = 0.0
	player_root.position.y = player_y
	is_sliding = Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN)
	var sliding_now := is_sliding and player_y < 0.2 and train_ride_timer <= 0.0
	slide_blend = move_toward(slide_blend, 1.0 if sliding_now else 0.0, delta * 8.0)
	jump_blend = move_toward(jump_blend, clampf(player_y / 1.45, 0.0, 1.0), delta * 7.0)
	var run_bob := sin(animation_time * 2.0) * 0.045 * (1.0 - slide_blend) * (1.0 - jump_blend)
	player_visual.position.y = run_bob
	player_visual.scale.y = 1.0 - slide_blend * 0.12
	player_torso.position.y = lerpf(1.18, 0.83, slide_blend)
	player_torso.rotation.x = -0.1 * jump_blend + 0.34 * slide_blend
	player_torso.rotation.z = lerpf(-clampf(target_x - player_root.position.x, -3.0, 3.0) * 0.055, 0.0, jump_blend)
	player_head.rotation.x = -0.12 * slide_blend + 0.08 * jump_blend
	player_head.rotation.y = sin(animation_time * 2.0) * 0.05 * (1.0 - jump_blend)
	var swing := sin(animation_time * 2.0) * 0.68 * (1.0 - slide_blend) * (1.0 - jump_blend * 0.75)
	for index in leg_parts.size():
		var side_sign := 1.0 if index == 0 else -1.0
		leg_parts[index].rotation.x = swing * side_sign + jump_blend * -0.8 + slide_blend * 0.48
		leg_parts[index].rotation.z = side_sign * slide_blend * 0.12
	for index in arm_parts.size():
		var arm_sign := -1.0 if index == 0 else 1.0
		arm_parts[index].rotation.x = arm_sign * swing - jump_blend * 1.55 + slide_blend * 0.52
		arm_parts[index].rotation.z = arm_sign * (jump_blend * 0.18 + slide_blend * 0.1)
	magnet_visual.rotation.y = sin(animation_time * 2.5) * 0.15


func _try_board_train() -> bool:
	if state != "running" or train_ride_timer > 0.0 or player_y > 0.15 or is_sliding:
		return false
	for index in entities.size():
		var entity: Dictionary = entities[index]
		if entity["kind"] != "train" or entity["resolved"] or int(entity["lane"]) != lane:
			continue
		var train: Node3D = entity["node"]
		var ramp_ground_z := train.position.z + TRAIN_RAMP_OFFSET + TRAIN_RAMP_LENGTH * 0.5 * cos(TRAIN_RAMP_ANGLE)
		var lane_x := float(int(entity["lane"]) - 1) * LANE_SPACING
		if absf(ramp_ground_z) > 0.8 or absf(player_root.position.x - lane_x) > 0.6:
			continue
		entity["resolved"] = true
		entities[index] = entity
		train_ride_distance = maxf(0.0, TRAIN_REAR_EXTENT - train.position.z)
		train_ride_timer = train_ride_distance / maxf(speed, 0.1)
		train_climb_timer = TRAIN_CLIMB_DURATION
		player_y = 0.0
		jump_velocity = 0.0
		train_rides += 1
		score += 125.0
		return true
	return false


func _move_scenery(delta: float) -> void:
	for segment in scenery:
		segment.position.z += speed * delta
		if segment.position.z > SEGMENT_LENGTH:
			var farthest_z := 0.0
			for other in scenery:
				farthest_z = minf(farthest_z, other.position.z)
			segment.position.z = farthest_z - SEGMENT_LENGTH


func _trigger_near_miss() -> void:
	near_misses += 1
	score += 60.0
	if chase_timer <= 0.0:
		chase_timer = 7.0
		teacher_root.visible = true


func _update_teacher(delta: float) -> void:
	if chase_timer <= 0.0:
		teacher_root.visible = false
		hud_chase.text = ""
		return
	teacher_root.visible = true
	var chase_progress := 1.0 - chase_timer / 7.0
	var chase_lane_x := float(lane - 1) * LANE_SPACING
	teacher_root.position.x = move_toward(teacher_root.position.x, chase_lane_x, delta * 3.8)
	teacher_root.position.y = 0.0
	teacher_root.position.z = lerpf(player_root.position.z + 6.4, player_root.position.z + 3.2, chase_progress)
	var chase_swing := sin(animation_time * 2.0 + 1.0) * 0.72
	for index in teacher_legs.size():
		teacher_legs[index].rotation.x = chase_swing if index == 0 else -chase_swing
	for index in teacher_arms.size():
		teacher_arms[index].rotation.x = -chase_swing if index == 0 else chase_swing
	hud_chase.text = "PAN PROCESOR GONI!  %d" % ceili(chase_timer)


func _spawn_wave() -> void:
	wave_count += 1
	var first_lane := randi_range(0, 2)
	var remaining_lanes: Array[int] = []
	for candidate_lane in range(3):
		if candidate_lane != first_lane:
			remaining_lanes.append(candidate_lane)
	var second_lane := remaining_lanes[randi_range(0, 1)]
	var safe_lane := 3 - first_lane - second_lane
	var kind_roll := randf()
	var kind := "barrier"
	if kind_roll < 0.22:
		kind = "train"
	elif kind_roll < 0.43:
		kind = "bus"
	elif kind_roll < 0.57:
		kind = "tram"
	elif kind_roll < 0.73:
		kind = "roadworks"
	elif kind_roll < 0.85:
		kind = "pit"
	elif kind_roll < 0.96:
		kind = "overhead"
	_spawn_hazard(kind, first_lane, -96.0 if kind == "train" else -82.0)

	var second_kind := "train" if wave_count % 4 == 0 else ("bus" if wave_count % 3 == 0 else "barrier")
	if wave_count % 5 == 0:
		second_kind = "tram"
	_spawn_hazard(second_kind, second_lane, -104.0 if second_kind == "train" else -100.0)

	var coin_lane := safe_lane
	for index in 6:
		_spawn_coin(coin_lane, -77.0 - float(index) * 2.2, 0.95 + float(index % 4) * 0.42)
	if wave_count % 3 == 0 or randf() < 0.12:
		var power_types: Array[String] = ["shield", "magnet", "double"]
		_spawn_powerup(power_types[randi_range(0, power_types.size() - 1)], safe_lane)


func _spawn_hazard(kind: String, hazard_lane: int, spawn_z: float = -82.0) -> void:
	var hazard := Node3D.new()
	hazard.position = Vector3(float(hazard_lane - 1) * LANE_SPACING, 0.0, spawn_z)
	add_child(hazard)
	match kind:
		"train":
			_build_train(hazard)
		"bus":
			var bus_routes := ["A4", "M105", "59"]
			_build_vehicle(hazard, bus_routes[randi_range(0, bus_routes.size() - 1)])
		"tram":
			_build_vehicle(hazard, "tram")
		"roadworks":
			_build_roadworks(hazard)
		"pit":
			_make_box(hazard, Vector3(2.2, 0.12, 2.6), Vector3(0.0, -0.08, 0.0), mats["pit"])
			_make_box(hazard, Vector3(2.5, 0.16, 0.22), Vector3(0.0, -0.03, -1.3), mats["barrier_white"])
			_make_box(hazard, Vector3(2.5, 0.16, 0.22), Vector3(0.0, -0.03, 1.3), mats["barrier_white"])
		"overhead":
			_make_box(hazard, Vector3(1.85, 0.2, 0.24), Vector3(0.0, 1.65, 0.0), mats["crane"])
			_make_box(hazard, Vector3(0.12, 1.75, 0.18), Vector3(-0.82, 0.87, 0.0), mats["metal"])
			_make_box(hazard, Vector3(0.12, 1.75, 0.18), Vector3(0.82, 0.87, 0.0), mats["metal"])
			_make_box(hazard, Vector3(1.05, 0.34, 0.08), Vector3(0.0, 1.38, 0.17), mats["sign"])
			var crouch_label := _make_3d_label("KUCNIJ!", 18, Color("#fff4dc"))
			crouch_label.position = Vector3(0.0, 1.38, 0.23)
			crouch_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			hazard.add_child(crouch_label)
		_:
			_make_box(hazard, Vector3(1.75, 0.95, 0.4), Vector3(0.0, 0.48, 0.0), mats["barrier"])
			for stripe in [-0.45, 0.45]:
				_make_box(hazard, Vector3(0.28, 0.8, 0.43), Vector3(stripe, 0.5, 0.0), mats["barrier_white"])
	entities.append({"node": hazard, "kind": kind, "lane": hazard_lane, "resolved": false})


func _build_roadworks(parent: Node3D) -> void:
	_make_box(parent, Vector3(1.5, 0.9, 0.24), Vector3(0.0, 1.05, 0.0), mats["construction"])
	for index in 3:
		_make_box(parent, Vector3(0.18, 0.72, 0.28), Vector3(-0.42 + float(index) * 0.42, 1.04, 0.15), mats["barrier_white"])
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.09, 0.6, 0.09), Vector3(side * 0.65, 0.3, 0.0), mats["metal"])
		var cone := CylinderMesh.new()
		cone.top_radius = 0.04
		cone.bottom_radius = 0.22
		cone.height = 0.72
		_make_mesh(parent, cone, Vector3(side * 1.0, 0.36, 0.3), mats["construction"])
	var sign := _make_3d_label("OBJAZD\nGLIWICE", 23, Color("#fff4dc"))
	sign.position = Vector3(0.0, 1.1, 0.25)
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(sign)


func _build_vehicle(parent: Node3D, vehicle_type: String) -> void:
	var is_tram := vehicle_type == "tram"
	var body_key := "tram" if is_tram else "bus_a4"
	if vehicle_type == "M105":
		body_key = "bus_m105"
	elif vehicle_type == "59":
		body_key = "bus_59"
	var body_material: Material = mats[body_key]
	var trim_material: Material = mats["tram_dark"] if is_tram else mats["shirt_trim"]
	var length := 5.4 if is_tram else 4.8
	_make_box(parent, Vector3(2.0, 2.55, length), Vector3(0.0, 1.27, 0.0), body_material)
	_make_box(parent, Vector3(1.72, 0.72, 0.08), Vector3(0.0, 1.85, length * 0.5 + 0.045), mats["glass"])
	_make_box(parent, Vector3(1.72, 0.58, 0.08), Vector3(0.0, 1.85, -length * 0.5 - 0.045), mats["glass"])
	_make_box(parent, Vector3(2.04, 0.24, length + 0.08), Vector3(0.0, 0.72, 0.0), trim_material)
	for z_side in [-1.0, 1.0]:
		for x_side in [-1.0, 1.0]:
			var wheel := SphereMesh.new()
			wheel.radius = 0.28
			wheel.height = 0.56
			_make_mesh(parent, wheel, Vector3(x_side * 0.9, 0.38, z_side * length * 0.31), mats["rubber"])
	for window_index in 4:
		var window_z := -length * 0.3 + float(window_index) * length * 0.2
		_make_box(parent, Vector3(0.08, 0.68, 0.68), Vector3(-1.01, 1.72, window_z), mats["glass"])
		_make_box(parent, Vector3(0.08, 0.68, 0.68), Vector3(1.01, 1.72, window_z), mats["glass"])
	_make_box(parent, Vector3(0.54, 0.18, 0.12), Vector3(-0.62, 0.38, length * 0.5 + 0.06), mats["lamp"])
	_make_box(parent, Vector3(0.54, 0.18, 0.12), Vector3(0.62, 0.38, length * 0.5 + 0.06), mats["lamp"])
	var route_name := "TRAMWAJE ŚLĄSKIE" if is_tram else "LINIA " + vehicle_type + " • GLIWICE"
	var route_label := _make_3d_label(route_name, 18, Color("#fff3cf"))
	route_label.position = Vector3(0.0, 2.32, length * 0.5 + 0.08)
	route_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(route_label)
	if is_tram:
		_make_box(parent, Vector3(0.16, 1.1, 0.16), Vector3(0.0, 3.05, -0.5), mats["metal"])
		_make_box(parent, Vector3(1.2, 0.12, 0.12), Vector3(0.0, 3.5, -0.5), mats["metal"])
	else:
		_make_box(parent, Vector3(1.3, 0.18, 0.2), Vector3(0.0, 2.58, 0.0), mats["sign"])


func _build_train(parent: Node3D) -> void:
	for car_index in 3:
		var car_z := -5.0 + float(car_index) * 5.0
		var car := Node3D.new()
		car.position.z = car_z
		parent.add_child(car)
		_make_box(car, Vector3(2.5, 2.9, 5.8), Vector3(0.0, 1.55, 0.0), mats["train"])
		_make_box(car, Vector3(2.24, 0.32, 5.55), Vector3(0.0, 3.14, 0.0), mats["train_roof"])
		_make_box(car, Vector3(2.58, 0.27, 5.84), Vector3(0.0, 0.74, 0.0), mats["tram_dark"])
		for window_index in 3:
			var window_z := -1.82 + float(window_index) * 1.82
			_make_box(car, Vector3(0.08, 0.82, 1.18), Vector3(-1.27, 2.05, window_z), mats["glass"])
			_make_box(car, Vector3(0.08, 0.82, 1.18), Vector3(1.27, 2.05, window_z), mats["glass"])
		for side in [-1.0, 1.0]:
			for axle in [-1.0, 1.0]:
				_make_mesh(car, _sphere_mesh(0.27), Vector3(side * 1.1, 0.42, axle * 1.8), mats["rubber"])
		if car_index == 2:
			_make_box(car, Vector3(1.65, 0.82, 0.12), Vector3(0.0, 2.18, 2.96), mats["glass"])
			_make_box(car, Vector3(0.42, 0.2, 0.16), Vector3(-0.72, 0.7, 2.98), mats["lamp"])
			_make_box(car, Vector3(0.42, 0.2, 0.16), Vector3(0.72, 0.7, 2.98), mats["lamp"])
	var destination := _make_3d_label("KATOWICE  •  GLIWICE", 32, Color("#fff4dc"))
	destination.position = Vector3(0.0, 3.55, 8.0)
	destination.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(destination)
	_build_train_ramp(parent)


func _build_train_ramp(parent: Node3D) -> void:
	var ramp_mid_y := TRAIN_RAMP_LENGTH * 0.5 * sin(TRAIN_RAMP_ANGLE)
	var ramp := _make_box(parent, Vector3(2.1, 0.22, TRAIN_RAMP_LENGTH), Vector3(0.0, ramp_mid_y, TRAIN_RAMP_OFFSET), mats["crane"], Vector3(TRAIN_RAMP_ANGLE, 0.0, 0.0))
	ramp.name = "GroundToRoofRamp"
	for side in [-1.0, 1.0]:
		_make_box(parent, Vector3(0.12, 0.3, TRAIN_RAMP_LENGTH), Vector3(side * 1.02, ramp_mid_y + 0.18, TRAIN_RAMP_OFFSET), mats["barrier_white"], Vector3(TRAIN_RAMP_ANGLE, 0.0, 0.0))
	for stripe in 7:
		var stripe_z := TRAIN_RAMP_OFFSET - 3.5 + float(stripe) * 1.0
		var stripe_y := ramp_mid_y - (stripe_z - TRAIN_RAMP_OFFSET) * sin(TRAIN_RAMP_ANGLE)
		_make_box(parent, Vector3(1.85, 0.04, 0.12), Vector3(0.0, stripe_y + 0.13, stripe_z), mats["barrier_white"], Vector3(TRAIN_RAMP_ANGLE, 0.0, 0.0))
	var label := _make_3d_label("WEJDŹ NA DACH", 24, Color("#fff4dc"))
	label.position = Vector3(0.0, 2.3, 14.7)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(label)


func _spawn_coin(coin_lane: int, z_pos: float, y_pos: float) -> void:
	var coin_root := Node3D.new()
	coin_root.position = Vector3(float(coin_lane - 1) * LANE_SPACING, y_pos, z_pos)
	add_child(coin_root)
	var coin_mesh := TorusMesh.new()
	coin_mesh.inner_radius = 0.3
	coin_mesh.outer_radius = 0.48
	coin_mesh.ring_segments = 10
	coin_mesh.rings = 6
	_make_mesh(coin_root, coin_mesh, Vector3.ZERO, mats["coin"], Vector3(PI * 0.5, 0.0, 0.0))
	entities.append({"node": coin_root, "kind": "coin", "lane": coin_lane, "resolved": false})


func _spawn_powerup(power_type: String, power_lane: int) -> void:
	var power_root := Node3D.new()
	power_root.position = Vector3(float(power_lane - 1) * LANE_SPACING, 1.45, -96.0)
	add_child(power_root)
	var caption := "TARCZA"
	if power_type == "magnet":
		caption = "MAGNES"
	elif power_type == "double":
		caption = "WYNIK x2"
	if power_type == "magnet":
		_make_box(power_root, Vector3(0.24, 0.96, 0.24), Vector3(-0.33, 0.0, 0.0), mats["magnet_power"])
		_make_box(power_root, Vector3(0.24, 0.96, 0.24), Vector3(0.33, 0.0, 0.0), mats["magnet_north"])
		_make_box(power_root, Vector3(0.84, 0.24, 0.24), Vector3(0.0, -0.36, 0.0), mats["magnet_power"])
		_make_box(power_root, Vector3(0.32, 0.14, 0.28), Vector3(-0.33, 0.52, 0.0), mats["magnet_silver"])
		_make_box(power_root, Vector3(0.32, 0.14, 0.28), Vector3(0.33, 0.52, 0.0), mats["magnet_silver"])
	else:
		var power_material: Material = mats["shield_power"] if power_type == "shield" else mats["score_power"]
		var orb := _sphere_mesh(0.46)
		_make_mesh(power_root, orb, Vector3.ZERO, power_material)
		var ring := TorusMesh.new()
		ring.inner_radius = 0.53
		ring.outer_radius = 0.62
		ring.ring_segments = 12
		ring.rings = 6
		_make_mesh(power_root, ring, Vector3.ZERO, power_material, Vector3(1.05, 0.0, 0.0))
	var label := _make_3d_label(caption, 23, Color("#fff4dc"))
	label.position = Vector3(0.0, 0.9, 0.0)
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	power_root.add_child(label)
	entities.append({"node": power_root, "kind": "powerup", "power_type": power_type, "lane": power_lane, "resolved": false})


func _move_entities(delta: float) -> void:
	for index in range(entities.size() - 1, -1, -1):
		var entity: Dictionary = entities[index]
		var node: Node3D = entity["node"]
		node.position.z += speed * delta
		if entity["kind"] == "coin":
			node.rotation.y += delta * 2.0
			var magnet_range := 30.0 if selected_skin == "biedronka" else 20.0
			if magnet_timer > 0.0 and absf(node.position.z - PLAYER_Z) < magnet_range:
				node.position.x = move_toward(node.position.x, player_root.position.x, 16.0 * delta)
			if not entity["resolved"] and absf(node.position.z - PLAYER_Z) < 1.1:
				if absf(node.position.x - player_root.position.x) < 1.2 and absf(node.position.y - player_y - 1.0) < 1.7:
					coins += 1
					wallet_coins += 1
					if selected_skin == "zabka":
						coins += 1
						wallet_coins += 1
					_save_progress()
					node.queue_free()
					entities.remove_at(index)
					continue
		elif entity["kind"] == "powerup":
			node.rotation.y += delta * 1.8
			node.position.y = 1.45 + sin(run_time * 3.2 + node.position.z) * 0.16
			if absf(node.position.z - PLAYER_Z) < 1.5 and absf(node.position.x - player_root.position.x) < 1.25:
				_collect_powerup(String(entity["power_type"]))
				node.queue_free()
				entities.remove_at(index)
				continue
		elif not entity["resolved"]:
			var kind := String(entity["kind"])
			if _hazard_touches_player(kind, node):
				entity["resolved"] = true
				entities[index] = entity
				if shield_charges > 0:
					shield_charges -= 1
					shield_timer = 0.0
					shield_visual.visible = false
					score += 150.0
					node.queue_free()
					entities.remove_at(index)
					continue
				_end_game()
				return
			elif node.position.z > 11.0:
				entity["resolved"] = true
				if absf(node.position.x - player_root.position.x) < 2.3:
					_trigger_near_miss()
		entities[index] = entity
		if node.position.z > 14.0:
			node.queue_free()
			entities.remove_at(index)


func _hazard_touches_player(kind: String, hazard: Node3D) -> bool:
	var half_width := 0.875
	var half_depth := 0.22
	var obstacle_bottom := 0.0
	var obstacle_top := 0.95
	match kind:
		"train":
			half_width = 1.25
			half_depth = 7.9
			obstacle_top = 3.3
		"bus":
			half_width = 1.02
			half_depth = 2.5
			obstacle_top = 2.55
		"tram":
			half_width = 1.02
			half_depth = 2.8
			obstacle_top = 2.55
		"roadworks":
			half_width = 1.0
			half_depth = 0.3
			obstacle_top = 1.65
		"pit":
			half_width = 1.25
			half_depth = 1.4
			obstacle_bottom = -0.2
			obstacle_top = 0.0
		"overhead":
			half_width = 0.95
			half_depth = 0.25
			obstacle_bottom = 1.25
			obstacle_top = 1.8

	var player_half_width := 0.4
	var player_half_depth := 0.35
	var player_bottom := player_y
	var player_top := player_y + (1.0 if is_sliding else 2.25)
	var overlaps_x := absf(player_root.position.x - hazard.position.x) < half_width + player_half_width
	var overlaps_z := absf(PLAYER_Z - hazard.position.z) < half_depth + player_half_depth
	var overlaps_y := player_bottom < obstacle_top and player_top > obstacle_bottom
	return overlaps_x and overlaps_z and overlaps_y


func _collect_powerup(power_type: String) -> void:
	match power_type:
		"shield":
			shield_charges = mini(shield_charges + 1, 1)
			shield_timer = 10.0
			shield_visual.visible = true
		"magnet":
			magnet_timer = 12.0 if selected_skin == "radiostacja" else 9.0
			magnet_visual.visible = true
		"double":
			double_score_timer = 12.0 if selected_skin == "industrial" else 9.0
	score += 50.0


func _end_game() -> void:
	state = "gameover"
	chase_timer = 0.0
	teacher_root.visible = false
	best_score = maxi(best_score, int(score))
	_save_progress()
	end_overlay.visible = true
	end_result.text = "Wynik: %d   •   Monety: %d\nRekord: %d" % [int(score), coins, best_score]
	_set_hud_visible(false)


func _update_hud() -> void:
	hud_score.text = "WYNIK  %d" % int(score)
	hud_coins.text = "MONETY  %d" % coins
	hud_speed.text = "TEMPO  %d" % int(speed)
	magnet_visual.visible = magnet_timer > 0.0
	hud_chase.visible = chase_timer > 0.0
	var shield_active := shield_charges > 0
	var magnet_active := magnet_timer > 0.0
	var double_active := double_score_timer > 0.0
	var any_power_active := shield_active or magnet_active or double_active
	power_panel.visible = state == "running" and any_power_active
	var shield_row: Dictionary = powerup_rows["shield"]
	shield_row["row"].visible = shield_active
	shield_row["name"].text = "TARCZA"
	shield_row["timer"].text = "%d s ochrony" % ceili(shield_timer)
	var magnet_row: Dictionary = powerup_rows["magnet"]
	magnet_row["row"].visible = magnet_active
	magnet_row["name"].text = "MAGNES"
	magnet_row["timer"].text = "%d s • monety lecą" % ceili(magnet_timer)
	var double_row: Dictionary = powerup_rows["double"]
	double_row["row"].visible = double_active
	double_row["name"].text = "WYNIK x2"
	double_row["timer"].text = "%d s • wynik x2" % ceili(double_score_timer)
	for row_data in powerup_rows.values():
		(row_data["icon"] as PowerupIcon).queue_redraw()


func _make_box(parent: Node3D, box_size: Vector3, box_position: Vector3, material: Material, rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = box_size
	return _make_mesh(parent, mesh, box_position, material, rotation)


func _make_mesh(parent: Node3D, mesh: Mesh, mesh_position: Vector3, material: Material, rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.position = mesh_position
	instance.rotation = rotation
	instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	parent.add_child(instance)
	return instance


func _make_3d_label(text: String, font_size: int, color: Color) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.font_size = font_size
	label.pixel_size = 0.006
	label.modulate = color
	label.outline_size = 5
	label.outline_modulate = Color("#24303a")
	return label
