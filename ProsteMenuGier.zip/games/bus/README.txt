KIEROWCA AUTOBUSU — PROTOTYP GODOT 4

Uruchomienie
Otworz folder projektu w Godot 4.2 lub nowszym i uruchom projekt (F6/F5).
Projekt nie wymaga zewnetrznych assetow.

Cel gry
Dowiez pasazerow na kolejne przystanki, zanim skonczy sie czas. Zatrzymaj
autobus na zoltym przystanku na chwile, aby zabrac pasazerow i dostac bonus
czasu. Co trzy przystanki wybierz ulepszenie klawiszem 1, 2 lub 3.

Sterowanie
- Menu: gora/dol lub W/S wybiera linie; lewo/prawo lub A/D wybiera rozmiar.
- C zmienia kolor autobusu; Enter rozpoczyna kurs.
- W/S lub strzalki przyspieszaja i hamuja/cofaja; A/D lub lewo/prawo skrecaja.
- Esc wstrzymuje gre i wznawia ja; M w pauzie wraca do menu.
- Po koncu kursu Enter, Spacja lub R rozpoczyna nowa gre.

Uwagi
- Numery linii sa inspirowane prawdziwymi liniami GZM, ale trasy w grze sa
  uproszczone i nie stanowia rzeczywistej nawigacji.
- Pauza, wybor ulepszenia i menu zatrzymuja symulacje ruchu ulicznego.
- Wybrany rozmiar autobusu zmienia jego wyglad i obszar kolizji.
