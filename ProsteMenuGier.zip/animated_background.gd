extends Control

var phase := 0.0
var light_theme := false

func set_light_theme(value: bool) -> void:
	light_theme = value
	queue_redraw()

func _process(delta: float) -> void:
	phase += delta * 0.18
	queue_redraw()

func _draw() -> void:
	var size := get_viewport_rect().size
	var glow_a := Color(0.25, 0.38, 0.9, 0.10) if not light_theme else Color(0.20, 0.38, 0.75, 0.07)
	var glow_b := Color(0.05, 0.72, 0.68, 0.08) if not light_theme else Color(0.02, 0.55, 0.50, 0.06)
	var c1 := Vector2(size.x * (0.18 + 0.05 * sin(phase)), size.y * (0.28 + 0.08 * cos(phase * 0.8)))
	var c2 := Vector2(size.x * (0.82 + 0.04 * cos(phase * 0.7)), size.y * (0.78 + 0.06 * sin(phase)))
	draw_circle(c1, 240.0, glow_a)
	draw_circle(c2, 290.0, glow_b)
	for i in range(36):
		var x := fposmod(float(i * 173) + phase * (13.0 + float(i % 5) * 3.0), size.x)
		var y := fposmod(float(i * 97) - phase * (8.0 + float(i % 7) * 2.0), size.y)
		draw_circle(Vector2(x, y), 1.3 if i % 3 else 2.0, Color(0.75, 0.85, 1.0, 0.15 if light_theme else 0.20))
	_draw_radiostation(size)

func _draw_radiostation(size: Vector2) -> void:
	# Gliwicka Radiostacja: smukła drewniana wieża kratownicowa i wysoki maszt.
	var scale_factor := clampf(size.y / 720.0, 0.65, 1.2)
	var center_x := size.x * 0.82
	var ground_y := size.y * 0.96
	var tower_h := size.y * 0.77
	var top_y := ground_y - tower_h
	var half_base := 85.0 * scale_factor
	var half_top := 18.0 * scale_factor
	var ink := Color(0.30, 0.39, 0.67, 0.25) if not light_theme else Color(0.16, 0.27, 0.48, 0.20)
	var soft_ink := Color(0.37, 0.49, 0.80, 0.15) if not light_theme else Color(0.16, 0.31, 0.54, 0.12)
	var left_base := Vector2(center_x - half_base, ground_y)
	var right_base := Vector2(center_x + half_base, ground_y)
	var left_top := Vector2(center_x - half_top, top_y + 40.0 * scale_factor)
	var right_top := Vector2(center_x + half_top, top_y + 40.0 * scale_factor)
	var line_width := 3.0 * scale_factor

	# Obrys i centralna konstrukcja wieży.
	_draw_line(left_base, left_top, ink, line_width)
	_draw_line(right_base, right_top, ink, line_width)
	_draw_line(Vector2(center_x, ground_y), Vector2(center_x, top_y + 40.0 * scale_factor), soft_ink, line_width * 0.8)
	_draw_line(Vector2(center_x - half_base * 0.72, ground_y), Vector2(center_x + half_base * 0.72, ground_y), ink, line_width)

	# Poprzeczki i krzyżulce drewnianej kratownicy.
	var levels := 12
	for i in range(levels + 1):
		var t := float(i) / float(levels)
		var y := lerpf(ground_y, top_y + 40.0 * scale_factor, t)
		var half_width := lerpf(half_base, half_top, t)
		var left := Vector2(center_x - half_width, y)
		var right := Vector2(center_x + half_width, y)
		_draw_line(left, right, soft_ink, line_width * 0.72)
		if i < levels:
			var next_t := float(i + 1) / float(levels)
			var next_y := lerpf(ground_y, top_y + 40.0 * scale_factor, next_t)
			var next_half := lerpf(half_base, half_top, next_t)
			var next_left := Vector2(center_x - next_half, next_y)
			var next_right := Vector2(center_x + next_half, next_y)
			_draw_line(left, next_right, ink, line_width * 0.68)
			_draw_line(right, next_left, ink, line_width * 0.68)

	# Iglica, anteny poprzeczne i fale radiowe.
	var mast_top := top_y - 95.0 * scale_factor
	_draw_line(Vector2(center_x, top_y + 40.0 * scale_factor), Vector2(center_x, mast_top), ink, line_width)
	_draw_line(Vector2(center_x - 10.0 * scale_factor, top_y + 40.0 * scale_factor), Vector2(center_x + 10.0 * scale_factor, top_y + 40.0 * scale_factor), ink, line_width)
	_draw_line(Vector2(center_x - 8.0 * scale_factor, top_y + 5.0 * scale_factor), Vector2(center_x + 8.0 * scale_factor, top_y + 5.0 * scale_factor), ink, line_width * 0.8)
	_draw_line(Vector2(center_x - 5.0 * scale_factor, top_y - 28.0 * scale_factor), Vector2(center_x + 5.0 * scale_factor, top_y - 28.0 * scale_factor), ink, line_width * 0.7)
	_draw_line(Vector2(center_x, mast_top), Vector2(center_x - 4.0 * scale_factor, mast_top + 12.0 * scale_factor), ink, line_width * 0.65)
	_draw_line(Vector2(center_x, mast_top), Vector2(center_x + 4.0 * scale_factor, mast_top + 12.0 * scale_factor), ink, line_width * 0.65)

	# Fale pulsują bardzo delikatnie wokół szczytu masztu.
	var pulse := 0.5 + 0.5 * sin(phase * 1.8)
	for ring in range(3):
		var radius := (34.0 + float(ring) * 22.0 + pulse * 5.0) * scale_factor
		var alpha := 0.10 - float(ring) * 0.02
		var wave_color := Color(0.36, 0.58, 0.95, alpha) if not light_theme else Color(0.18, 0.40, 0.72, alpha * 0.8)
		_draw_arc(Vector2(center_x, mast_top + 10.0 * scale_factor), radius, PI * 1.12, PI * 1.88, wave_color, 1.5 * scale_factor)

func _draw_line(from: Vector2, to: Vector2, color: Color, width: float) -> void:
	draw_line(from, to, color, width, true)

func _draw_arc(center: Vector2, radius: float, start_angle: float, end_angle: float, color: Color, width: float) -> void:
	var points := PackedVector2Array()
	for i in range(25):
		var angle := lerpf(start_angle, end_angle, float(i) / 24.0)
		points.append(center + Vector2(cos(angle), sin(angle)) * radius)
	draw_polyline(points, color, width, true)
