extends Node

const MAIN_MENU_SCENE := "res://Main.tscn"
const GAME_HOST_SCENE := "res://GameHost.tscn"

var pending_game_scene := ""

func open_game(scene_path: String) -> void:
	if scene_path.is_empty() or not ResourceLoader.exists(scene_path):
		push_error("Nie znaleziono sceny gry: " + scene_path)
		return
	pending_game_scene = scene_path
	var error := get_tree().change_scene_to_file(GAME_HOST_SCENE)
	if error != OK:
		push_error("Nie udało się otworzyć hosta gry. Kod błędu: %d" % error)

func return_to_menu() -> void:
	pending_game_scene = ""
	var error := get_tree().change_scene_to_file(MAIN_MENU_SCENE)
	if error != OK:
		push_error("Nie udało się wrócić do menu głównego. Kod błędu: %d" % error)
