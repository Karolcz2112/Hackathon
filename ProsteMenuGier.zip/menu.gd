extends Control

## Podaj ścieżki do scen startowych gier w Inspectorze, np. res://gra1/Main.tscn.
@export_file("*.tscn") var game_one_scene: String = ""
@export_file("*.tscn") var game_two_scene: String = ""
@export_file("*.tscn") var game_three_scene: String = ""

const CONFIG_PATH := "user://menu_settings.cfg"

var is_light := false
var master_volume := 0.8
var settings := ConfigFile.new()
var title_label: Label
var subtitle_label: Label
var status_label: Label
var volume_slider: HSlider
var theme_button: Button
var animated_background: Control
var game_buttons: Array[Button] = []
var surfaces: Array[Control] = []
var labels: Array[Label] = []

func _ready() -> void:
	_load_settings()
	_build_ui()
	_apply_theme()
	_apply_volume()

func _load_settings() -> void:
	if settings.load(CONFIG_PATH) == OK:
		is_light = settings.get_value("menu", "light_theme", false)
		master_volume = clampf(float(settings.get_value("menu", "volume", 0.8)), 0.0, 1.0)

func _save_settings() -> void:
	settings.set_value("menu", "light_theme", is_light)
	settings.set_value("menu", "volume", master_volume)
	settings.save(CONFIG_PATH)

func _build_ui() -> void:
	animated_background = Control.new()
	animated_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	animated_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	animated_background.set_script(load("res://animated_background.gd"))
	add_child(animated_background)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(470, 0)
	center.add_child(panel)
	surfaces.append(panel)

	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 16)
	panel.add_child(content)
	panel.add_theme_constant_override("margin_left", 34)
	panel.add_theme_constant_override("margin_right", 34)
	panel.add_theme_constant_override("margin_top", 30)
	panel.add_theme_constant_override("margin_bottom", 28)

	title_label = Label.new()
	title_label.text = "CENTRUM GIER"
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_font_size_override("font_size", 32)
	content.add_child(title_label)
	labels.append(title_label)

	subtitle_label = Label.new()
	subtitle_label.text = "Wybierz grę i dostosuj menu do siebie"
	subtitle_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle_label.add_theme_font_size_override("font_size", 14)
	content.add_child(subtitle_label)
	labels.append(subtitle_label)

	content.add_child(HSeparator.new())

	var game_one := _make_button("GLIWICE SPRINT — SZLAK RADIOSTACJI", 1)
	content.add_child(game_one)
	game_buttons.append(game_one)
	var game_two := _make_button("KIEROWCA AUTOBUSU", 2)
	content.add_child(game_two)
	game_buttons.append(game_two)
	var game_three := _make_button("RADIOSTACJA — WSPINACZKA", 3)
	content.add_child(game_three)
	game_buttons.append(game_three)

	var volume_label := Label.new()
	volume_label.text = "GŁOŚNOŚĆ"
	volume_label.add_theme_font_size_override("font_size", 13)
	content.add_child(volume_label)
	labels.append(volume_label)

	var volume_row := HBoxContainer.new()
	volume_row.add_theme_constant_override("separation", 12)
	content.add_child(volume_row)
	var volume_icon := Label.new()
	volume_icon.text = "♪"
	volume_icon.add_theme_font_size_override("font_size", 20)
	volume_row.add_child(volume_icon)
	volume_slider = HSlider.new()
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.01
	volume_slider.value = master_volume
	volume_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	volume_slider.value_changed.connect(_on_volume_changed)
	volume_row.add_child(volume_slider)
	var percent := Label.new()
	percent.name = "VolumePercent"
	percent.custom_minimum_size.x = 48
	percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	volume_row.add_child(percent)
	volume_slider.value_changed.connect(func(value: float): percent.text = "%d%%" % roundi(value * 100.0))
	percent.text = "%d%%" % roundi(master_volume * 100.0)

	theme_button = Button.new()
	theme_button.text = "☀  WŁĄCZ JASNY MOTYW" if not is_light else "☾  WŁĄCZ CIEMNY MOTYW"
	theme_button.custom_minimum_size.y = 46
	theme_button.pressed.connect(_toggle_theme)
	content.add_child(theme_button)

	status_label = Label.new()
	status_label.text = "Gotowy do gry"
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 12)
	content.add_child(status_label)
	labels.append(status_label)

func _make_button(caption: String, game_index: int) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size.y = 54
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(_launch_game.bind(game_index))
	return button

func _apply_theme() -> void:
	var bg := Color("eef2f8") if is_light else Color("101522")
	var panel_color := Color("ffffff") if is_light else Color("1b2233")
	var text_color := Color("182033") if is_light else Color("f3f6ff")
	var muted := Color("69758c") if is_light else Color("aab4c8")
	var accent := Color("526ee8") if is_light else Color("7188ff")
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = panel_color
	panel_style.corner_radius_top_left = 22
	panel_style.corner_radius_top_right = 22
	panel_style.corner_radius_bottom_left = 22
	panel_style.corner_radius_bottom_right = 22
	panel_style.content_margin_left = 28
	panel_style.content_margin_right = 28
	panel_style.content_margin_top = 24
	panel_style.content_margin_bottom = 24
	panel_style.shadow_color = Color(0, 0, 0, 0.22)
	panel_style.shadow_size = 24
	panel_style.shadow_offset = Vector2(0, 10)
	for surface in surfaces:
		surface.add_theme_stylebox_override("panel", panel_style)
	for label in labels:
		label.add_theme_color_override("font_color", text_color if label == title_label else muted)
	for button in game_buttons:
		button.add_theme_stylebox_override("normal", _button_style(accent, 15))
		button.add_theme_stylebox_override("hover", _button_style(accent.lightened(0.1), 15))
		button.add_theme_stylebox_override("pressed", _button_style(accent.darkened(0.12), 15))
		button.add_theme_color_override("font_color", Color.WHITE)
		button.add_theme_color_override("font_hover_color", Color.WHITE)
		button.add_theme_font_size_override("font_size", 15)
	var theme_style := _button_style(Color(0.45, 0.53, 0.72, 0.16) if is_light else Color(0.65, 0.72, 0.91, 0.12), 13)
	theme_button.add_theme_stylebox_override("normal", theme_style)
	theme_button.add_theme_stylebox_override("hover", _button_style(Color(0.45, 0.53, 0.72, 0.25) if is_light else Color(0.65, 0.72, 0.91, 0.22), 13))
	theme_button.add_theme_color_override("font_color", text_color)
	theme_button.add_theme_font_size_override("font_size", 13)
	volume_slider.add_theme_color_override("grabber_color", accent)
	volume_slider.add_theme_color_override("grabber_highlight_color", accent.lightened(0.15))
	RenderingServer.set_default_clear_color(bg)
	animated_background.call("set_light_theme", is_light)

func _button_style(color: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	return style

func _toggle_theme() -> void:
	is_light = not is_light
	theme_button.text = "☀  WŁĄCZ JASNY MOTYW" if not is_light else "☾  WŁĄCZ CIEMNY MOTYW"
	_apply_theme()
	_save_settings()

func _on_volume_changed(value: float) -> void:
	master_volume = value
	_apply_volume()
	_save_settings()

func _apply_volume() -> void:
	var bus_index := AudioServer.get_bus_index("Master")
	if bus_index >= 0:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(maxf(master_volume, 0.0001)))
		AudioServer.set_bus_mute(bus_index, master_volume <= 0.0)

func _launch_game(game_index: int) -> void:
	var scene_path: String
	match game_index:
		case 1:
			scene_path = game_one_scene
		case 2:
			scene_path = game_two_scene
		case 3:
			scene_path = game_three_scene
	if scene_path.is_empty():
		status_label.text = "Dodaj ścieżkę gry %d w Inspectorze menu." % game_index
		return
	if not ResourceLoader.exists(scene_path):
		status_label.text = "Nie znaleziono sceny: %s" % scene_path
		push_warning("Nie znaleziono sceny gry: " + scene_path)
		return
	GameRouter.open_game(scene_path)








