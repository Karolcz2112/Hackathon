extends Control

const GAME_SIZES := {
	"subwaysurf": Vector2i(1280, 720),
	"bus": Vector2i(320, 180),
	"timberman": Vector2i(480, 800),
}

var game_viewport: SubViewport
var game_container: SubViewportContainer

func _ready() -> void:
	var game_path: String = GameRouter.pending_game_scene
	if game_path.is_empty() or not ResourceLoader.exists(game_path):
		GameRouter.return_to_menu()
		return

	var design_size := _design_size_for(game_path)
	game_container = SubViewportContainer.new()
	game_container.stretch = false
	game_container.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(game_container)

	game_viewport = SubViewport.new()
	game_viewport.size = design_size
	game_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	game_container.add_child(game_viewport)
	var game_scene: PackedScene = load(game_path)
	game_viewport.add_child(game_scene.instantiate())

	var return_button := Button.new()
	return_button.text = "⌂  MENU GŁÓWNE"
	return_button.tooltip_text = "Wróć do wyboru gier (F10)"
	return_button.anchor_left = 1.0
	return_button.anchor_right = 1.0
	return_button.offset_left = -178.0
	return_button.offset_right = -14.0
	return_button.offset_top = 14.0
	return_button.offset_bottom = 54.0
	if game_path.contains("subwaysurf"):
		return_button.anchor_left = 0.0
		return_button.anchor_right = 0.0
		return_button.offset_left = 14.0
		return_button.offset_right = 178.0
	elif game_path.contains("bus"):
		return_button.anchor_top = 1.0
		return_button.anchor_bottom = 1.0
		return_button.offset_top = -54.0
		return_button.offset_bottom = -14.0
	return_button.z_index = 100
	return_button.focus_mode = Control.FOCUS_NONE
	var button_style := StyleBoxFlat.new()
	button_style.bg_color = Color(0.06, 0.1, 0.17, 0.9)
	button_style.border_color = Color(0.48, 0.63, 0.95, 0.8)
	button_style.set_border_width_all(1)
	button_style.set_corner_radius_all(10)
	return_button.add_theme_stylebox_override("normal", button_style)
	return_button.add_theme_stylebox_override("hover", button_style)
	return_button.add_theme_color_override("font_color", Color.WHITE)
	return_button.add_theme_color_override("font_hover_color", Color.WHITE)
	add_child(return_button)
	return_button.pressed.connect(GameRouter.return_to_menu)

	resized.connect(_layout_game_viewport)
	_layout_game_viewport()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F10 or event.keycode == KEY_HOME:
			GameRouter.return_to_menu()

func _design_size_for(game_path: String) -> Vector2i:
	for game_name in GAME_SIZES:
		if game_path.contains(game_name):
			return GAME_SIZES[game_name]
	return Vector2i(1280, 720)

func _layout_game_viewport() -> void:
	if game_container == null or game_viewport == null:
		return
	var design_size := Vector2(game_viewport.size)
	var scale_factor := minf(size.x / design_size.x, size.y / design_size.y)
	var fitted_size := design_size * scale_factor
	game_container.position = (size - fitted_size) * 0.5
	game_container.size = design_size
	game_container.scale = Vector2.ONE * scale_factor




