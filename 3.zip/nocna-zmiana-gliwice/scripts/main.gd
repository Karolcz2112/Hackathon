extends Node2D

## Nocna zmiana: a Timberman-inspired antenna maintenance arcade game.
const SEGMENT_COUNT: int = 7
const SEGMENT_GAP: float = 47.0
const TOWER_TOP: float = 135.0
const TOWER_BASE: float = 465.0
const TARGET_SCORE: int = 40

var rng := RandomNumberGenerator.new()
var font: Font
var view_size := Vector2(960.0, 600.0)
var arms: Array[int] = [] # -1 = antenna wystaje w lewo, 1 = w prawo, 0 = brak
var score: int = 0
var best_score: int = 0
var shift_time: float = 100.0
var running: bool = false
var finished: bool = false
var won: bool = false
var player_side: int = -1
var tower_x: float = 480.0
var stars: Array[Dictionary] = []

func _ready() -> void:
	rng.randomize()
	font = ThemeDB.fallback_font
	var save := ConfigFile.new()
	if save.load("user://radiostacja_wyniki.cfg") == OK:
		best_score = int(save.get_value("wyniki", "rekord", 0))
	get_viewport().size_changed.connect(_on_viewport_size_changed)
	_update_layout()
	_reset_sky()
	_reset_arms()
	queue_redraw()

func _on_viewport_size_changed() -> void:
	_update_layout()
	_reset_sky()
	queue_redraw()

func _update_layout() -> void:
	view_size = get_viewport_rect().size
	tower_x = view_size.x * 0.5

func _reset_sky() -> void:
	stars.clear()
	var count: int = int(view_size.x * view_size.y / 5200.0)
	for i in range(count):
		stars.append({"x": rng.randf_range(0.0, view_size.x), "y": rng.randf_range(0.0, view_size.y * 0.72), "r": rng.randf_range(0.7, 1.8), "a": rng.randf_range(0.25, 0.8)})

func _reset_arms() -> void:
	arms.clear()
	for i in range(SEGMENT_COUNT):
		arms.append(_random_arm())

func _random_arm() -> int:
	# A few clear sections keep the pattern readable and give the player room to react.
	var roll: int = rng.randi_range(0, 4)
	if roll == 0:
		return 0
	return -1 if rng.randi_range(0, 1) == 0 else 1

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_LEFT or event.keycode == KEY_A:
			_chop(-1)
		elif event.keycode == KEY_RIGHT or event.keycode == KEY_D:
			_chop(1)
		elif (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER) and not running:
			_start_game()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		var side: int = -1 if event.position.x < view_size.x * 0.5 else 1
		if not running:
			_start_game()
			return
		_chop(side)
	elif event is InputEventScreenTouch and event.pressed:
		var side: int = -1 if event.position.x < view_size.x * 0.5 else 1
		if not running:
			_start_game()
			return
		_chop(side)

func _start_game() -> void:
	score = 0
	shift_time = 100.0
	player_side = -1
	finished = false
	won = false
	_reset_arms()
	running = true
	queue_redraw()

func _chop(side: int) -> void:
	if not running:
		_start_game()
		return
	player_side = side
	# The lowest antenna section reaches the technician. Move to the clear side before cutting.
	if arms[arms.size() - 1] == side:
		_finish(false)
		return
	arms.pop_back()
	arms.push_front(_random_arm())
	score += 1
	shift_time = minf(100.0, shift_time + 7.2)
	if score >= TARGET_SCORE:
		_finish(true)
	queue_redraw()

func _finish(victory: bool) -> void:
	running = false
	finished = true
	won = victory
	if score > best_score:
		best_score = score
		var save := ConfigFile.new()
		save.set_value("wyniki", "rekord", best_score)
		save.save("user://radiostacja_wyniki.cfg")
	queue_redraw()

func _process(delta: float) -> void:
	if running:
		var drain: float = 10.5 + float(score) * 0.11
		shift_time -= minf(delta, 0.05) * drain
		if shift_time <= 0.0:
			shift_time = 0.0
			_finish(false)
	queue_redraw()

func _draw() -> void:
	_draw_night()
	_draw_tower()
	if running:
		_draw_player()
		_draw_hud()
	else:
		_draw_overlay()

func _draw_night() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color("#080d21"))
	var glow_center := Vector2(tower_x, view_size.y * 0.45)
	draw_circle(glow_center, view_size.y * 0.54, Color(0.16, 0.2, 0.42, 0.18))
	for star in stars:
		draw_circle(Vector2(float(star["x"]), float(star["y"])), float(star["r"]), Color(0.82, 0.9, 1.0, float(star["a"])))
	# Distant Gliwice skyline and the tower's red warning lights.
	var ground_y: float = view_size.y * 0.82
	draw_rect(Rect2(0, ground_y, view_size.x, view_size.y - ground_y), Color("#11172b"))
	for i in range(9):
		var bx: float = float(i) * view_size.x / 8.0 - 28.0
		var bh: float = 28.0 + float((i * 37) % 53)
		draw_rect(Rect2(bx, ground_y - bh, 58, bh), Color("#192039"))
		for w in range(2):
			draw_rect(Rect2(bx + 11.0 + float(w) * 23.0, ground_y - bh + 11.0, 5, 7), Color(0.94, 0.69, 0.35, 0.38))

func _draw_tower() -> void:
	# Recognizable tapering wooden lattice mast inspired by the Gliwice Radio Tower.
	var top_y: float = TOWER_TOP
	var bottom_y: float = TOWER_BASE
	var top_half: float = 24.0
	var base_half: float = minf(view_size.x * 0.19, 150.0)
	var left_top := Vector2(tower_x - top_half, top_y)
	var right_top := Vector2(tower_x + top_half, top_y)
	var left_base := Vector2(tower_x - base_half, bottom_y)
	var right_base := Vector2(tower_x + base_half, bottom_y)
	# Amber illumination behind the timber structure.
	draw_line(left_top, left_base, Color("#ad8152"), 9.0, true)
	draw_line(right_top, right_base, Color("#ad8152"), 9.0, true)
	draw_line(left_top, right_top, Color("#d1a66d"), 7.0, true)
	for i in range(SEGMENT_COUNT):
		var y: float = bottom_y - float(i) * SEGMENT_GAP
		var fraction: float = (y - top_y) / (bottom_y - top_y)
		var half_width: float = top_half + (base_half - top_half) * fraction
		var next_y: float = maxf(top_y, y - SEGMENT_GAP)
		var next_fraction: float = (next_y - top_y) / (bottom_y - top_y)
		var next_half: float = top_half + (base_half - top_half) * next_fraction
		var left := Vector2(tower_x - half_width, y)
		var right := Vector2(tower_x + half_width, y)
		var left_next := Vector2(tower_x - next_half, next_y)
		var right_next := Vector2(tower_x + next_half, next_y)
		draw_line(left, right_next, Color("#d2a66d"), 4.0, true)
		draw_line(right, left_next, Color("#d2a66d"), 4.0, true)
		draw_line(left, left_next, Color("#8e6845"), 3.0, true)
		draw_line(right, right_next, Color("#8e6845"), 3.0, true)
	# Horizontal maintenance platforms.
	for i in range(SEGMENT_COUNT + 1):
		var y: float = bottom_y - float(i) * SEGMENT_GAP
		var fraction: float = (y - top_y) / (bottom_y - top_y)
		var half_width: float = top_half + (base_half - top_half) * fraction
		draw_line(Vector2(tower_x - half_width, y), Vector2(tower_x + half_width, y), Color("#e1bb80"), 4.0, true)
	# Antenna arms are the incoming hazards. The last segment is nearest the player.
	for i in range(arms.size()):
		var y: float = bottom_y - float(arms.size() - 1 - i) * SEGMENT_GAP - SEGMENT_GAP * 0.5
		var fraction: float = (y - top_y) / (bottom_y - top_y)
		var half_width: float = top_half + (base_half - top_half) * fraction
		_draw_antenna_arm(y, half_width, arms[i])
	# Crown mast, crossbars, and red aviation lamps.
	draw_line(Vector2(tower_x, top_y), Vector2(tower_x, 61), Color("#e3bd82"), 5.0, true)
	draw_line(Vector2(tower_x - 22, 93), Vector2(tower_x + 22, 93), Color("#e3bd82"), 3.0, true)
	draw_circle(Vector2(tower_x, 59), 5, Color("#ff505d"))
	draw_circle(Vector2(tower_x, 137), 4, Color("#ff505d"))
	draw_rect(Rect2(tower_x - base_half - 17, bottom_y, base_half * 2.0 + 34, 9), Color("#d0a56c"), true)

func _draw_antenna_arm(y: float, half_width: float, direction: int) -> void:
	if direction == 0:
		return
	var reach: float = minf(128.0, 52.0 + half_width * 0.48)
	var end_x: float = tower_x + float(direction) * (half_width + reach)
	var start_x: float = tower_x + float(direction) * (half_width - 2.0)
	var arm_color := Color("#f0c77e")
	draw_line(Vector2(start_x, y), Vector2(end_x, y), arm_color, 7.0, true)
	draw_line(Vector2(end_x, y), Vector2(end_x - float(direction) * 11.0, y - 13.0), arm_color, 3.0, true)
	draw_line(Vector2(end_x - float(direction) * 11.0, y + 13.0), Vector2(end_x, y), arm_color, 3.0, true)
	draw_circle(Vector2(end_x, y), 4.0, Color("#ffe6ae"))

func _draw_player() -> void:
	var direction: float = float(player_side)
	var pos := Vector2(tower_x + direction * 112.0, TOWER_BASE - 2.0)
	# Tiny night-shift technician with hard hat and safety vest.
	_draw_ellipse(pos + Vector2(0, 22), Vector2(17, 5), Color(0, 0, 0, 0.36))
	draw_rect(Rect2(pos.x - 10, pos.y - 22, 20, 25), Color("#4fc3a1"), true)
	draw_circle(pos + Vector2(0, -29), 9, Color("#f0c9a0"))
	draw_arc(pos + Vector2(0, -31), 10, PI, TAU, 16, Color("#ffe082"), 4.0)
	draw_line(pos + Vector2(-12, 7), pos + Vector2(-22, 18), Color("#d7e3e5"), 4.0)
	draw_line(pos + Vector2(12, 7), pos + Vector2(22, 18), Color("#d7e3e5"), 4.0)
	draw_rect(Rect2(pos.x - 12, pos.y + 20, 9, 10), Color("#25324a"), true)
	draw_rect(Rect2(pos.x + 3, pos.y + 20, 9, 10), Color("#25324a"), true)

func _draw_hud() -> void:
	draw_rect(Rect2(17, 16, view_size.x - 34, 63), Color(0.025, 0.04, 0.09, 0.86), true)
	_draw_text("SEKCJE", Vector2(34, 40), 12, Color("#b9c5dd"))
	_draw_text("%02d / %02d" % [score, TARGET_SCORE], Vector2(34, 66), 21, Color("#fff1ca"))
	_draw_text("REKORD  %d" % best_score, Vector2(view_size.x - 145, 47), 15, Color("#9ee8d0"))
	_draw_text("CZAS", Vector2(view_size.x * 0.40, 39), 12, Color("#b9c5dd"))
	var bar_rect := Rect2(view_size.x * 0.40, 50, view_size.x * 0.28, 13)
	draw_rect(bar_rect, Color("#39415a"), true)
	var bar_color := Color("#71d6ae") if shift_time > 35.0 else Color("#ff6474")
	draw_rect(Rect2(bar_rect.position, Vector2(bar_rect.size.x * shift_time / 100.0, bar_rect.size.y)), bar_color, true)

func _draw_overlay() -> void:
	draw_rect(Rect2(Vector2.ZERO, view_size), Color(0.015, 0.025, 0.07, 0.76))
	var cx: float = view_size.x * 0.5
	_draw_text("RADIOSTACJA GLIWICE  •  NOCNA ZMIANA", Vector2(cx - 225, view_size.y * 0.28), 15, Color("#9ee8d0"))
	_draw_text("SERWIS MASZTU", Vector2(cx - 183, view_size.y * 0.40), 37, Color("#fff1ca"))
	if finished:
		_draw_text("ŚWIETNA ROBOTA!" if won else "KONIEC ZMIANY", Vector2(cx - 117, view_size.y * 0.49), 21, Color("#ffe082"))
		_draw_text("Zdemontowane sekcje: %d   •   Rekord: %d" % [score, best_score], Vector2(cx - 190, view_size.y * 0.56), 16, Color("#d5def0"))
	else:
		_draw_text("Demontuj maszt i omijaj wystające anteny", Vector2(cx - 214, view_size.y * 0.51), 17, Color("#d5def0"))
	_draw_text("LEWA STRONA:  ← / A / kliknij po lewej", Vector2(cx - 190, view_size.y * 0.61), 15, Color("#d5def0"))
	_draw_text("PRAWA STRONA:  → / D / kliknij po prawej", Vector2(cx - 201, view_size.y * 0.66), 15, Color("#d5def0"))
	_draw_text("Każde cięcie daje czas. Uważaj na antenę przy dole masztu!", Vector2(cx - 254, view_size.y * 0.72), 14, Color("#b9c5dd"))
	_draw_text("KLIKNIJ LUB NACIŚNIJ SPACJĘ, ABY ZACZĄĆ", Vector2(cx - 203, view_size.y * 0.81), 15, Color("#9ee8d0"))

func _draw_text(text: String, pos: Vector2, size: int, color: Color) -> void:
	if font != null:
		draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, color)

func _draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(20):
		var angle: float = TAU * float(i) / 20.0
		points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	draw_colored_polygon(points, color)
