# Serwis masztu — Nocna zmiana w Radiostacji Gliwice (Godot 4)

## Uruchomienie
1. Zainstaluj Godot 4.
2. Wybierz **Importuj** i wskaż `project.godot` w tym folderze.
3. Otwórz projekt i uruchom klawiszem **F5**.

## Zasady i sterowanie
- **← / A** — wybierz lewą stronę i wykonaj cięcie
- **→ / D** — wybierz prawą stronę i wykonaj cięcie
- **Kliknięcie/tap po lewej lub prawej stronie ekranu** — wybór strony i cięcie
- **Spacja** — rozpoczęcie lub ponowne rozpoczęcie gry

Demontuj 40 sekcji, zanim skończy się czas. Anteny wystające z najniższej sekcji są przeszkodami: jeśli stoisz po ich stronie, przegrywasz. Każde bezpieczne cięcie dodaje czas. Rekord zapisuje się lokalnie.

## Assety
Nie musisz dodawać żadnych assetów. Maszt, anteny, nocne niebo, światła, pracownik i interfejs są rysowane przez skrypt. Opcjonalnie można później dodać własny sprite pracownika, dźwięki cięcia i alarm lampy ostrzegawczej.
