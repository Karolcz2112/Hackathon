extends Node2D

const VIEW_SIZE := Vector2(480.0, 270.0)
const WORLD_SIZE := Vector2(1536.0, 1024.0)
const ROAD_ROWS := [104.0, 488.0, 872.0]
const ROAD_COLUMNS := [120.0, 768.0, 1416.0]
const START_TIME := 90.0
const STOP_DURATION := 1.0
const SAVE_PATH := "user://route_07.cfg"

enum GameState { MENU, DRIVING, RESULTS }

const VEHICLES: Array[Dictionary] = [
	{
		"name": "CITYLINER",
		"kind": "CLASSIC BUS",
		"body": Color("#e5ad35"),
		"trim": Color("#f1d46b"),
		"max_speed": 108.0,
		"acceleration": 92.0,
		"turn_rate": 2.15,
		"capacity": 42,
	},
	{
		"name": "ELECTRA",
		"kind": "ELECTRIC",
		"body": Color("#52c6a3"),
		"trim": Color("#a3efd1"),
		"max_speed": 122.0,
		"acceleration": 112.0,
		"turn_rate": 2.35,
		"capacity": 34,
	},
	{
		"name": "MINIBUS",
		"kind": "SHUTTLE",
		"body": Color("#ec7860"),
		"trim": Color("#ffc2a7"),
		"max_speed": 118.0,
		"acceleration": 104.0,
		"turn_rate": 2.7,
		"capacity": 18,
	},
]

const BUILDING_COLORS := [
	Color("#bb7555"), Color("#c8a369"), Color("#6e8d91"),
	Color("#b97879"), Color("#7d8e68"), Color("#8d7ea2"),
	Color("#ce8651"), Color("#66879b"),
]
const BUILDING_NAMES := [
	"MARKET", "HOTEL", "CLINIC", "SCHOOL",
	"CAFE", "CINEMA", "DEPOT", "LIBRARY",
]

var state: GameState = GameState.MENU
var roads: Array[Rect2] = []
var buildings: Array[Dictionary] = []
var trees: Array[Vector2] = []
var stops: Array[Dictionary] = []

var selected_vehicle: int = 0
var bus_position := Vector2(250.0, 104.0)
var bus_angle: float = 0.0
var bus_speed: float = 0.0
var camera_position := Vector2(250.0, 104.0)
var time_left: float = START_TIME
var money: int = 0
var stops_completed: int = 0
var next_stop: int = 0
var stop_progress: float = 0.0
var last_passengers: int = 0
var reward_timer: float = 0.0
var animation_time: float = 0.0
var best_route: int = 0
var random := RandomNumberGenerator.new()


func _ready() -> void:
	random.randomize()
	RenderingServer.set_default_clear_color(Color("#253c34"))
	_build_town()
	_load_record()
	_reset_route()
	queue_redraw()


func _build_town() -> void:
	roads.clear()
	buildings.clear()
	trees.clear()
	stops.clear()

	for y in ROAD_ROWS:
		roads.append(Rect2(0.0, y - 40.0, WORLD_SIZE.x, 80.0))
	for x in ROAD_COLUMNS:
		roads.append(Rect2(x - 40.0, 0.0, 80.0, WORLD_SIZE.y))

	var block_origins := [Vector2(160.0, 144.0), Vector2(808.0, 144.0),
		Vector2(160.0, 528.0), Vector2(808.0, 528.0)]
	var building_offsets := [Vector2(22.0, 20.0), Vector2(330.0, 20.0),
		Vector2(22.0, 160.0), Vector2(330.0, 160.0)]
	var building_index := 0
	for block in block_origins:
		for offset in building_offsets:
			var size := Vector2(205.0, 104.0)
			var rect := Rect2(block + offset, size)
			buildings.append({
				"rect": rect,
				"color": BUILDING_COLORS[building_index % BUILDING_COLORS.size()],
				"name": BUILDING_NAMES[building_index % BUILDING_NAMES.size()],
				"detail": Color("#eadcb9"),
			})
			building_index += 1

		for tree_offset in [Vector2(8.0, 12.0), Vector2(560.0, 12.0),
			Vector2(8.0, 286.0), Vector2(560.0, 286.0)]:
			trees.append(block + tree_offset)

	stops = [
		{"name": "CENTRAL", "pos": Vector2(365.0, 104.0)},
		{"name": "RIVERSIDE", "pos": Vector2(768.0, 334.0)},
		{"name": "MARKET", "pos": Vector2(1090.0, 488.0)},
		{"name": "EAST PARK", "pos": Vector2(1416.0, 704.0)},
		{"name": "SOUTH GATE", "pos": Vector2(990.0, 872.0)},
		{"name": "OLD TOWN", "pos": Vector2(120.0, 710.0)},
	]


func _reset_route() -> void:
	bus_position = Vector2(250.0, 104.0)
	bus_angle = 0.0
	bus_speed = 0.0
	camera_position = bus_position
	time_left = START_TIME
	money = 0
	stops_completed = 0
	next_stop = 0
	stop_progress = 0.0
	last_passengers = 0
	reward_timer = 0.0


func _load_record() -> void:
	var config := ConfigFile.new()
	if config.load(SAVE_PATH) == OK:
		best_route = int(config.get_value("route", "best_stops", 0))


func _save_record() -> void:
	var config := ConfigFile.new()
	config.set_value("route", "best_stops", best_route)
	var error := config.save(SAVE_PATH)
	if error != OK:
		push_warning("Could not save the route record (error %d)." % error)


func _start_route() -> void:
	_reset_route()
	state = GameState.DRIVING


func _finish_route() -> void:
	state = GameState.RESULTS
	bus_speed = 0.0
	if stops_completed > best_route:
		best_route = stops_completed
		_save_record()


func _process(delta: float) -> void:
	animation_time += delta
	reward_timer = maxf(0.0, reward_timer - delta)

	if state == GameState.DRIVING:
		_update_driving(delta)

	camera_position = camera_position.lerp(bus_position, 1.0 - exp(-delta * 5.0))
	queue_redraw()


func _update_driving(delta: float) -> void:
	var throttle := Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)
	var brake := Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S)
	var steering := 0.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		steering += 1.0
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		steering -= 1.0

	var vehicle: Dictionary = VEHICLES[selected_vehicle]
	var acceleration: float = vehicle["acceleration"]
	var max_speed: float = vehicle["max_speed"]
	var turn_rate: float = vehicle["turn_rate"]
	if throttle:
		bus_speed += acceleration * delta
	elif brake:
		if bus_speed > 0.0:
			bus_speed = move_toward(bus_speed, 0.0, 210.0 * delta)
		else:
			bus_speed -= acceleration * 0.55 * delta
	else:
		bus_speed = move_toward(bus_speed, 0.0, 48.0 * delta)

	if not _is_on_road(bus_position):
		max_speed *= 0.48
	bus_speed = clampf(bus_speed, -38.0, max_speed)
	bus_angle += steering * turn_rate * clampf(bus_speed / 46.0, -1.0, 1.0) * delta

	var candidate := bus_position + Vector2.from_angle(bus_angle) * bus_speed * delta
	if _hits_building(candidate):
		bus_speed = 0.0
	else:
		bus_position = candidate.clamp(Vector2(32.0, 32.0), WORLD_SIZE - Vector2(32.0, 32.0))

	time_left -= delta
	if time_left <= 0.0:
		time_left = 0.0
		_finish_route()
		return

	_update_stop(delta)


func _is_on_road(point: Vector2) -> bool:
	for road in roads:
		if road.has_point(point):
			return true
	return false


func _hits_building(point: Vector2) -> bool:
	var corners := [
		Vector2(-18.0, -11.0), Vector2(18.0, -11.0),
		Vector2(-18.0, 11.0), Vector2(18.0, 11.0),
	]
	for corner in corners:
		var sample: Vector2 = point + corner.rotated(bus_angle)
		for building in buildings:
			var bounds: Rect2 = building["rect"]
			if bounds.grow(2.0).has_point(sample):
				return true
	return false


func _update_stop(delta: float) -> void:
	var stop_position: Vector2 = stops[next_stop]["pos"]
	if bus_position.distance_to(stop_position) <= 28.0 and absf(bus_speed) < 9.0:
		stop_progress += delta
		if stop_progress >= STOP_DURATION:
			_service_stop()
	else:
		stop_progress = maxf(0.0, stop_progress - delta * 1.5)


func _service_stop() -> void:
	last_passengers = random.randi_range(4, 12)
	var capacity: int = VEHICLES[selected_vehicle]["capacity"]
	last_passengers = mini(last_passengers, capacity)
	money += last_passengers * 5
	time_left = minf(time_left + 12.0, 120.0)
	stops_completed += 1
	next_stop = (next_stop + 1) % stops.size()
	stop_progress = 0.0
	reward_timer = 2.2


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key_event := event as InputEventKey
		if not key_event.pressed or key_event.echo:
			return
		if state == GameState.MENU:
			if key_event.keycode == KEY_LEFT or key_event.keycode == KEY_A:
				selected_vehicle = posmod(selected_vehicle - 1, VEHICLES.size())
			elif key_event.keycode == KEY_RIGHT or key_event.keycode == KEY_D:
				selected_vehicle = posmod(selected_vehicle + 1, VEHICLES.size())
			elif key_event.keycode == KEY_ENTER or key_event.keycode == KEY_SPACE:
				_start_route()
		elif state == GameState.RESULTS:
			if key_event.keycode == KEY_ENTER or key_event.keycode == KEY_SPACE or key_event.keycode == KEY_R:
				_start_route()
			elif key_event.keycode == KEY_M:
				state = GameState.MENU
		return

	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if not mouse.pressed or mouse.button_index != MOUSE_BUTTON_LEFT:
			return
		if state == GameState.MENU:
			for i in range(VEHICLES.size()):
				if _vehicle_card_rect(i).has_point(mouse.position):
					selected_vehicle = i
					return
			if Rect2(150.0, 210.0, 180.0, 34.0).has_point(mouse.position):
				_start_route()
		elif state == GameState.RESULTS and Rect2(150.0, 196.0, 180.0, 34.0).has_point(mouse.position):
			_start_route()


func _vehicle_card_rect(index: int) -> Rect2:
	return Rect2(15.0 + index * 150.0, 93.0, 140.0, 104.0)


func _draw() -> void:
	_draw_town()
	if state == GameState.MENU:
		_draw_menu()
	elif state == GameState.DRIVING:
		_draw_hud()
	else:
		_draw_results()


func _draw_town() -> void:
	draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color("#496a45"))
	var origin := (VIEW_SIZE * 0.5 - camera_position).round()
	draw_set_transform(origin, 0.0, Vector2.ONE)
	draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#496a45"))

	var tile_x := floori(camera_position.x / 32.0)
	var tile_y := floori(camera_position.y / 32.0)
	for x in range(tile_x - 9, tile_x + 10):
		for y in range(tile_y - 6, tile_y + 7):
			var hash_value := absi((x * 73856093) ^ (y * 19349663))
			if hash_value % 4 == 0:
				var tuft := Vector2(float(x * 32 + 7 + hash_value % 19), float(y * 32 + 5 + (hash_value >> 4) % 20))
				draw_rect(Rect2(tuft, Vector2(2.0, 2.0)), Color("#3f6040"))

	for road in roads:
		draw_rect(road.grow(5.0), Color("#b7b49d"))
		draw_rect(road, Color("#3b4146"))
		_draw_road_markings(road)

	for tree in trees:
		_draw_tree(tree)
	for building in buildings:
		_draw_building(building)
	for i in range(stops.size()):
		_draw_stop(stops[i], i == next_stop)

	_draw_bus(origin + bus_position, bus_angle, selected_vehicle, 1.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_road_markings(road: Rect2) -> void:
	var marking_color := Color("#d9d4b5")
	if road.size.x > road.size.y:
		var center_y := road.position.y + road.size.y * 0.5
		for x in range(12, int(WORLD_SIZE.x) - 12, 30):
			draw_rect(Rect2(float(x), center_y - 1.0, 15.0, 2.0), marking_color)
	else:
		var center_x := road.position.x + road.size.x * 0.5
		for y in range(12, int(WORLD_SIZE.y) - 12, 30):
			draw_rect(Rect2(center_x - 1.0, float(y), 2.0, 15.0), marking_color)


func _draw_tree(position: Vector2) -> void:
	draw_rect(Rect2(position + Vector2(5.0, 9.0), Vector2(4.0, 8.0)), Color("#765337"))
	draw_rect(Rect2(position + Vector2(1.0, 2.0), Vector2(12.0, 11.0)), Color("#2e5941"))
	draw_rect(Rect2(position + Vector2(3.0, 0.0), Vector2(8.0, 9.0)), Color("#4c8052"))
	draw_rect(Rect2(position + Vector2(5.0, 2.0), Vector2(3.0, 3.0)), Color("#75a45b"))


func _draw_building(building: Dictionary) -> void:
	var rect: Rect2 = building["rect"]
	var base: Color = building["color"]
	draw_rect(rect.grow(7.0), Color("#c0b99f"))
	draw_rect(rect.grow(3.0), Color("#78916a"))
	draw_rect(Rect2(rect.position + Vector2(3.0, 4.0), rect.size), Color("#343d3e"))
	draw_rect(rect, base)
	draw_rect(Rect2(rect.position + Vector2(7.0, 7.0), rect.size - Vector2(14.0, 14.0)), base.lightened(0.16))
	draw_rect(Rect2(rect.position + Vector2(12.0, 11.0), Vector2(rect.size.x - 24.0, 5.0)), base.darkened(0.16))

	var window_color := Color("#a8d7cb")
	for window_x in [rect.position.x + 18.0, rect.position.x + 52.0, rect.position.x + 86.0,
		rect.position.x + 120.0, rect.position.x + 154.0, rect.position.x + 178.0]:
		draw_rect(Rect2(window_x, rect.position.y + 34.0, 13.0, 16.0), Color("#536a6b"))
		draw_rect(Rect2(window_x + 2.0, rect.position.y + 36.0, 9.0, 12.0), window_color)
		draw_rect(Rect2(window_x, rect.position.y + 60.0, 13.0, 16.0), Color("#536a6b"))
		draw_rect(Rect2(window_x + 2.0, rect.position.y + 62.0, 9.0, 12.0), window_color)
	draw_rect(Rect2(rect.position + Vector2(rect.size.x * 0.5 - 8.0, rect.size.y - 23.0), Vector2(16.0, 23.0)), Color("#514c43"))
	draw_rect(Rect2(rect.position + Vector2(rect.size.x * 0.5 - 5.0, rect.size.y - 20.0), Vector2(10.0, 12.0)), Color("#92c6be"))
	_draw_text(str(building["name"]), rect.position.x + 5.0, rect.position.y + rect.size.y - 5.0, Color("#fff1c8"), 8, 190.0)


func _draw_stop(stop: Dictionary, active: bool) -> void:
	var position: Vector2 = stop["pos"]
	var pulse := 0.5 + 0.5 * sin(animation_time * 5.0)
	var color := Color("#ffd45b") if active else Color("#9caeaa")
	draw_circle(position, 14.0 if active else 10.0, Color(color.r, color.g, color.b, 0.2 if active else 0.12))
	draw_rect(Rect2(position - Vector2(9.0, 5.0), Vector2(18.0, 10.0)), Color("#4e5655"))
	draw_rect(Rect2(position - Vector2(8.0, 4.0), Vector2(16.0, 8.0)), color)
	draw_rect(Rect2(position - Vector2(5.0, 2.0), Vector2(10.0, 4.0)), Color("#f8edca"))
	draw_rect(Rect2(position + Vector2(6.0, -15.0), Vector2(2.0, 14.0)), Color("#e6dfc4"))
	draw_rect(Rect2(position + Vector2(7.0, -15.0), Vector2(9.0, 7.0)), color)
	_draw_text(str(stop["name"]), position.x - 42.0, position.y + 23.0, Color("#fff4d4"), 7, 84.0, HORIZONTAL_ALIGNMENT_CENTER)
	if active:
		draw_circle(position + Vector2(0.0, -21.0), 2.0 + pulse, Color("#fff5c2"))


func _draw_bus(position: Vector2, angle: float, vehicle_index: int, scale: float) -> void:
	var vehicle: Dictionary = VEHICLES[vehicle_index]
	var body: Color = vehicle["body"]
	var trim: Color = vehicle["trim"]
	draw_set_transform(position, angle, Vector2.ONE * scale)
	draw_rect(Rect2(-23.0, -12.0, 48.0, 26.0), Color("#272d2c"))
	draw_rect(Rect2(-22.0, -11.0, 44.0, 22.0), body)
	draw_rect(Rect2(-17.0, -8.0, 26.0, 16.0), trim)
	draw_rect(Rect2(-13.0, -6.0, 4.0, 12.0), Color("#6e9d9e"))
	draw_rect(Rect2(-6.0, -6.0, 4.0, 12.0), Color("#6e9d9e"))
	draw_rect(Rect2(1.0, -6.0, 4.0, 12.0), Color("#6e9d9e"))
	draw_rect(Rect2(8.0, -7.0, 8.0, 14.0), Color("#395c64"))
	draw_rect(Rect2(17.0, -8.0, 4.0, 16.0), body.darkened(0.2))
	draw_rect(Rect2(19.0, -8.0, 3.0, 4.0), Color("#fff1bd"))
	draw_rect(Rect2(19.0, 4.0, 3.0, 4.0), Color("#fff1bd"))
	draw_rect(Rect2(-21.0, -9.0, 3.0, 4.0), Color("#e46c56"))
	draw_rect(Rect2(-21.0, 5.0, 3.0, 4.0), Color("#e46c56"))
	draw_rect(Rect2(-15.0, -13.0, 9.0, 3.0), Color("#1f2525"))
	draw_rect(Rect2(7.0, -13.0, 9.0, 3.0), Color("#1f2525"))
	draw_rect(Rect2(-15.0, 11.0, 9.0, 3.0), Color("#1f2525"))
	draw_rect(Rect2(7.0, 11.0, 9.0, 3.0), Color("#1f2525"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_hud() -> void:
	draw_rect(Rect2(0.0, 0.0, VIEW_SIZE.x, 33.0), Color("#182626"))
	draw_rect(Rect2(0.0, 32.0, VIEW_SIZE.x, 1.0), Color("#8aa68e"))
	_draw_text("ROUTE 07", 8.0, 14.0, Color("#ffd45b"), 10, 80.0)
	_draw_text("TIME  %02d" % ceili(time_left), 106.0, 14.0, Color.WHITE, 10, 75.0)
	_draw_text("FARE  $%03d" % money, 200.0, 14.0, Color("#a7e4c7"), 10, 80.0)
	_draw_text("STOPS  %02d" % stops_completed, 300.0, 14.0, Color.WHITE, 10, 78.0)
	_draw_minimap()

	var next_name: String = stops[next_stop]["name"]
	_draw_panel(Rect2(8.0, 228.0, 200.0, 32.0), Color("#182626"))
	_draw_text("NEXT  " + next_name, 17.0, 242.0, Color("#ffd45b"), 10, 180.0)
	_draw_text("%03d KM/H" % int(absf(bus_speed) * 0.5), 385.0, 249.0, Color.WHITE, 11, 88.0)

	if absf(bus_speed) > 4.0 and bus_position.distance_to(stops[next_stop]["pos"]) < 100.0:
		_draw_text("BRAKE AT STOP", 183.0, 217.0, Color("#f0e2c0"), 9, 130.0)
	elif stop_progress > 0.0:
		_draw_text("BOARDING...", 195.0, 217.0, Color("#ffd45b"), 9, 100.0)
		draw_rect(Rect2(190.0, 222.0, 100.0, 4.0), Color("#263333"))
		draw_rect(Rect2(190.0, 222.0, 100.0 * clampf(stop_progress / STOP_DURATION, 0.0, 1.0), 4.0), Color("#ffd45b"))
	if reward_timer > 0.0:
		_draw_text("+%d PASSENGERS   +$%d   +12 SEC" % [last_passengers, last_passengers * 5], 110.0, 57.0, Color("#ffe187"), 11, 260.0)

	_draw_text("WASD / ARROWS: DRIVE     BRAKE TO BOARD", 93.0, 264.0, Color("#e8e4ce"), 8, 294.0)


func _draw_minimap() -> void:
	var box := Rect2(388.0, 39.0, 82.0, 57.0)
	draw_rect(box.grow(2.0), Color("#b7b49d"))
	draw_rect(box, Color("#415b49"))
	var scale := Vector2(box.size.x / WORLD_SIZE.x, box.size.y / WORLD_SIZE.y)
	for road in roads:
		var scaled := Rect2(box.position + road.position * scale, road.size * scale)
		draw_rect(scaled, Color("#555b5b"))
	for i in range(stops.size()):
		var point: Vector2 = box.position + stops[i]["pos"] * scale
		draw_circle(point, 2.2 if i == next_stop else 1.5, Color("#ffd45b") if i == next_stop else Color("#d6dbcc"))
	var bus_dot := box.position + bus_position * scale
	draw_rect(Rect2(bus_dot - Vector2(2.0, 2.0), Vector2(4.0, 4.0)), Color("#f17c5b"))


func _draw_menu() -> void:
	draw_rect(Rect2(0.0, 0.0, VIEW_SIZE.x, VIEW_SIZE.y), Color(0.06, 0.1, 0.1, 0.74))
	_draw_text("SUNNY SIDE TRANSIT", 0.0, 34.0, Color("#ffe187"), 22, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("PICK YOUR BUS  /  DRIVE THE CITY  /  PICK UP PASSENGERS", 0.0, 52.0, Color("#e2e4d3"), 9, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)

	for i in range(VEHICLES.size()):
		var card := _vehicle_card_rect(i)
		var selected := i == selected_vehicle
		var panel_color := Color("#394d46") if selected else Color("#222e2e")
		_draw_panel(card, panel_color, Color("#ffd45b") if selected else Color("#61736b"))
		_draw_bus(card.position + Vector2(card.size.x * 0.5, 34.0), 0.0, i, 0.82)
		var vehicle: Dictionary = VEHICLES[i]
		_draw_text(str(vehicle["name"]), card.position.x + 5.0, card.position.y + 64.0, Color.WHITE, 11, card.size.x - 10.0, HORIZONTAL_ALIGNMENT_CENTER)
		_draw_text(str(vehicle["kind"]), card.position.x + 5.0, card.position.y + 78.0, Color("#cad6c6"), 8, card.size.x - 10.0, HORIZONTAL_ALIGNMENT_CENTER)
		_draw_text("%d KM/H   %d SEATS" % [int(vehicle["max_speed"] * 0.5), int(vehicle["capacity"])], card.position.x + 4.0, card.position.y + 94.0, Color("#ffe187") if selected else Color("#aab7aa"), 8, card.size.x - 8.0, HORIZONTAL_ALIGNMENT_CENTER)

	_draw_panel(Rect2(150.0, 210.0, 180.0, 34.0), Color("#d9a83f"), Color("#ffe187"))
	_draw_text("START ROUTE  >", 150.0, 232.0, Color("#202a28"), 14, 180.0, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("← / → SELECT     ENTER / CLICK TO START", 0.0, 261.0, Color("#e2e4d3"), 8, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)


func _draw_results() -> void:
	draw_rect(Rect2(0.0, 0.0, VIEW_SIZE.x, VIEW_SIZE.y), Color(0.06, 0.1, 0.1, 0.78))
	_draw_panel(Rect2(100.0, 49.0, 280.0, 174.0), Color("#263735"), Color("#d4b55d"))
	_draw_text("ROUTE COMPLETE", 0.0, 81.0, Color("#ffe187"), 20, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("PASSENGER STOPS  %02d" % stops_completed, 0.0, 112.0, Color.WHITE, 13, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("FARE EARNED  $%03d" % money, 0.0, 134.0, Color("#a7e4c7"), 13, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("PERSONAL BEST  %02d" % best_route, 0.0, 156.0, Color("#d9dcca"), 11, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_panel(Rect2(150.0, 180.0, 180.0, 34.0), Color("#d9a83f"), Color("#ffe187"))
	_draw_text("DRIVE AGAIN  >", 150.0, 202.0, Color("#202a28"), 14, 180.0, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_text("ENTER / R: RESTART     M: MENU", 0.0, 251.0, Color("#e2e4d3"), 9, VIEW_SIZE.x, HORIZONTAL_ALIGNMENT_CENTER)


func _draw_panel(rect: Rect2, fill: Color, border: Color = Color("#708379")) -> void:
	draw_rect(rect.grow(2.0), border)
	draw_rect(rect, fill)


func _draw_text(text: String, x: float, y: float, color: Color, size: int, width: float = -1.0, alignment: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	var font: Font = ThemeDB.fallback_font
	draw_string(font, Vector2(x + 1.0, y + 1.0), text, alignment, width, size, Color(0.0, 0.0, 0.0, 0.85))
	draw_string(font, Vector2(x, y), text, alignment, width, size, color)
