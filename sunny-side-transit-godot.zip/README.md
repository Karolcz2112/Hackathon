# Sunny Side Transit

A small, self-contained top-down pixel-style bus game made with Godot 4. The town, buildings, roads, buses, stops, and interface are drawn in GDScript; no external assets or add-ons are needed.

## Run
1. Install Godot 4.2 or newer.
2. In Godot, choose **Import** and open this folder's `project.godot`.
3. Press **F6** to run the main scene or **F5** to run the project.

## Play
- Choose the **Cityliner**, **Electra**, or **Minibus** on the start screen. Each has different speed, acceleration, steering, and passenger capacity.
- Drive to the highlighted stop, slow to a full stop, and wait for boarding to finish.
- Earn fares and 12 seconds of extra time at each stop. Complete as many stops as possible before time runs out.
- Roads are faster than grass. Buildings block the bus.

## Controls
- **W / Up** — accelerate
- **S / Down** — brake; reverse when stopped
- **A / Left**, **D / Right** — steer
- **Left / Right** or **A / D** on the menu — choose a bus
- **Enter / Space** — start or restart a route
- **M** on the results screen — return to the vehicle menu

The best number of stops is saved locally in Godot's `user://route_07.cfg`.
